"""Prospective finite NL/OH8 coordinator; no model math or scientific choice.

Launches only separately admitted fixed metadata plans, owned MATLAB wrappers
and the independently pinned saved-output checker. No resume or retries.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,sys,time

W=Path(__file__).resolve().parents[3]
N=W/'A_ARASTIRMASI/A31_NL_Eslenmis_NR_2026_10_25_v1'
PY=Path(sys.executable)
G=W/'A_ARASTIRMASI/A_v29.0_2026_10_18/08_Inceleme/a29cl_owned_launcher_v1.py'
GUARD_SHA='2c9ab9459f0ee296cec975c821d5244bc76a006910abdb5374c370fe9230b2b8'
PHASE='matched_nl_oh8_response'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve(strict=True);p.relative_to(W)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def verify(ref):
    p=Path(ref['path']).resolve(strict=True);assert pin(p)=={k:ref[k] for k in ['path','bytes','sha256']};return p
def scoped(p,roots,must_exist=False):
    p=Path(p).resolve(strict=must_exist);assert any(p.is_relative_to(r.resolve())for r in roots),str(p);return p
def clock():
    t=datetime.datetime.now(datetime.timezone.utc);return {'utc':t.isoformat(),'istanbul':t.astimezone(datetime.timezone(datetime.timedelta(hours=3))).isoformat()}
def atomic(p,value):
    b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8');assert len(b)<=4000000
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_bytes(b);os.replace(tmp,p)
def directory_bytes(paths):
    files=set()
    for p in paths:
        if p.is_file():files.add(p.resolve())
        elif p.is_dir():files.update(q.resolve()for q in p.rglob('*')if q.is_file())
    return sum(p.stat().st_size for p in files)
def ledger(title,action,result,evidence,next_step):
    sys.path.insert(0,str(W/'A_ARASTIRMASI/A_v25.0_2026_10_11/08_Inceleme'))
    from a25_log import log
    return log(title,action,result,type='A31_NL_fixed_phase_coordination',objective='Execute only independently admitted fixed source batches and propagate only accepted saved numerical caches.',reason='Candidate plans and producer completion are not saved-output acceptance; accepted jobs must not be repeated.',evidence=[str(p)for p in evidence],next_step=next_step)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase-plan',type=Path,required=True);ap.add_argument('--phase-plan-sha256',required=True);ap.add_argument('--out-dir',type=Path,required=True);a=ap.parse_args()
    assert Path(sys.executable).resolve()==PY.resolve()
    master=scoped(a.phase_plan,[N],True);assert pin(master)['sha256']==a.phase_plan_sha256
    p=read(master)
    assert p['schema']=='A31_NL_PHASE_COORDINATOR_PLAN_V1' and p['status']=='ADMITTED_EXACT_A31_NL_PHASE_COORDINATOR'
    assert p['phase']==PHASE and Path(p['workspace_root']).resolve(strict=True)==W
    assert 1<=p['phase_wall_seconds']<=7200 and 1<=p['phase_output_cap_bytes']<=8589934592 and 1<=p['max_batches']<=20
    assert verify(p['coordinator_pin'])==Path(__file__).resolve()
    builder=verify(p['prepare_script_pin']);wrapper=verify(p['wrapper_pin']);checker=verify(p['checker_pin'])
    assert verify(p['owned_job_guard_pin'])==G and pin(G)['sha256']==GUARD_SHA
    for q in [builder,wrapper,checker]:scoped(q,[N],True)
    for q in p.get('checker_dependency_pins',[])+p.get('pins',[]):verify(q)
    batches=p['batches'];assert 1<=len(batches)<=p['max_batches']
    assert [b['batch_index']for b in batches]==list(range(1,len(batches)+1))
    assert len({b['batch_id']for b in batches})==len(batches)
    ids=[j for b in batches for j in b['job_ids']];assert len(ids)==len(set(ids))
    for b in batches:
        assert 1<=len(b['job_ids'])<=70 and b['outer_fold']in range(1,6)
        assert b['family']in ['NL4','OH8'] and isinstance(b['replay'],bool)
        for k in ['freeze_path','config_path','independent_review_path']:scoped(b[k],[N])
        scoped(b['out_dir'],[N/'04_Results'])
        ad=scoped(b['audit_dir'],[N/'07_Audit'])
        scoped(b['audit_out'],[ad/'results'])
        verify(b['job_plan_pin'])
    out=scoped(a.out_dir,[N/'07_Audit']);assert not out.exists(),'No resume or automatic retry. Preserve old output and obtain a separately admitted remaining-job continuation.'
    out.mkdir(parents=True);progressp=out/'coordinator_progress_v1.json'
    started=time.monotonic();progress={'schema':'A31_NL_PHASE_PROGRESS_V1','master_plan_sha256':a.phase_plan_sha256,'phase':PHASE,'status':'PREPARED','started':clock(),'accepted_records':[]}
    atomic(progressp,progress);events=out/'coordinator_events_v1.jsonl'
    # The whole module is private scoped work: inputs, scripts, temporary
    # metadata, controls, source results and audits all count once by path.
    # Source files referenced outside N are not copied into this disk budget.
    budget_roots=[N]
    carry=p.get('prior_cumulative_budget',{})
    prior_seconds=float(carry.get('elapsed_seconds',0));assert 0<=prior_seconds<p['phase_wall_seconds']
    def used_seconds():return prior_seconds+time.monotonic()-started
    def budget(reserve=0,reserve_bytes=0):
        remaining=p['phase_wall_seconds']-used_seconds()
        assert remaining>=reserve,'Whole phase wall cap: stop before next child.'
        size=directory_bytes(budget_roots);assert size+reserve_bytes<=p['phase_output_cap_bytes'],'Whole module output cap or next-step reserve exceeded.'
        return remaining
    def update(status):
        progress['status']=status;progress['updated']=clock();progress['elapsed_current_invocation_seconds']=time.monotonic()-started
        progress['cumulative_phase_seconds']=used_seconds();progress['whole_module_bytes']=directory_bytes(budget_roots);atomic(progressp,progress)
    def emit(kind,**values):
        value={'clock':clock(),'event':kind,'phase':PHASE,**values}
        with events.open('a',encoding='utf-8')as f:f.write(json.dumps(value,ensure_ascii=False)+'\n')
        print(json.dumps(value,ensure_ascii=False),flush=True)
    def child(script,args,label,index,seconds,watched_outputs,output_cap):
        budget(seconds+2,output_cap);logp=out/f'batch_{index:03}_{label}.log';assert not logp.exists()
        flags=subprocess.CREATE_NO_WINDOW if os.name=='nt'else 0
        with logp.open('wb')as f:
            process=subprocess.Popen([str(PY),str(script),*map(str,args)],cwd=str(W),stdout=f,stderr=subprocess.STDOUT,creationflags=flags)
            deadline=time.monotonic()+seconds
            try:
                while process.poll()is None:
                    assert time.monotonic()<=deadline,f'Owned new {label} child exceeded wall cap; no retry.'
                    assert logp.stat().st_size<=2097152,f'{label} log cap exceeded.'
                    assert directory_bytes(watched_outputs+[logp])<=output_cap,f'{label} scoped output cap exceeded.'
                    budget();time.sleep(.1)
            except BaseException:
                if process.poll()is None:process.kill();process.wait(timeout=10)
                raise
        assert process.returncode==0,f'{label} failed rc={process.returncode}; preserve{logp}'
        assert logp.stat().st_size<=2097152 and directory_bytes(watched_outputs+[logp])<=output_cap
        return logp
    def audit_owned(b):
        # The exact same accepted helper enforces a fresh Python-owned Job:
        # this avoids treating a bare Popen deadline as a4GiB memory guard.
        budget(285,33554432)
        ad=Path(b['audit_dir']).resolve();assert not ad.exists()
        ao=Path(b['audit_out']).resolve();assert ao.is_relative_to(ad/'results')
        ad.mkdir(parents=True);(ad/'results').mkdir()
        receipt,rp=producer(b)
        binding={'schema':'A31_NL_DERIVED_SAVED_AUDIT_BINDING_V1','clock':clock(),
          'parent_master_pin':pin(master),'phase':PHASE,'batch_id':b['batch_id'],
          'source_producer_receipt_pin':pin(rp),'source_result_pin':receipt['result_pin'],
          'source_cache_pin':receipt['new_cache_pin'],'source_predictions_pin':receipt['predictions_pin'],
          'checker_pin':pin(checker),'checker_dependency_pins':p.get('checker_dependency_pins',[]),
          'executable':str(PY),'owned_guard_pin':pin(G),'wall_seconds':240,
          'aggregate_output_cap_bytes':33554432,'owned_job_commit_bytes':4294967296,
          'stdout_cap_bytes':2097152,'new_experimental_fits_or_experimental_query_populations':0,
          'independent_saved_numeric_recomputations':'Saved forward, gradient and Adam/checkpoint calculations are permitted for independent verification; they are not a new trained trajectory or evaluation population.',
          'legacy_guard_receipt_field_note':'The helper field named matlab stores the actual launched executable, bundledPython for this saved audit.'}
        atomic(ad/'audit_owned_binding_v1.json',binding)
        sys.path.insert(0,str(G.parent))
        from a29cl_owned_launcher_v1 import launch
        result=launch(PY,[str(checker),'--result-dir',str(Path(b['out_dir'])/'results'),'--audit-out',str(ao)],W,ad,240,33554432)
        assert result['status']=='COMPLETE'and result['normal_exit']and result['job_empty']and result['job_membership_verified'],'Saved audit owned process failed; preserve output.'
        assert directory_bytes([ad])<=33554432
        return ad/'launcher_receipt.json'
    def inspect(b):
        f=read(b['freeze_path']);cfg=read(b['config_path'])
        assert f['status']=='ADMITTED_EXACT_A31_NL_LAUNCH' and f['mode']=='source'
        assert Path(f['out_dir']).resolve()==Path(b['out_dir']).resolve()
        for ref in f['pins']:verify(ref)
        assert cfg['phase']==PHASE and cfg['batch_id']==b['batch_id']
        assert cfg['source_run_authorized'] is True and cfg['admission_token']=='A31_NL_ADMITTED_SOURCE_BATCH'
        jp=read(verify(cfg['phase_jobs_pin']));assert [j['job_id']for j in jp['jobs']]==b['job_ids']
        assert all(j['outer_fold']==b['outer_fold']and j['family']==b['family']and j['replay']==b['replay']for j in jp['jobs'])
        assert cfg['max_trajectories']<=70 and 1<=cfg['max_seconds']<=f['wall_seconds']<=240
        assert 1<=cfg['max_total_output_bytes']<=f['output_cap_bytes']<=335544320
        return f,cfg
    def producer(b):
        d=Path(b['out_dir']);launch=read(d/'launcher_receipt.json')
        assert launch['status']=='COMPLETE'and launch['normal_exit']and launch['job_empty']and launch['job_membership_verified']
        rp=d/'results/nl_batch_producer_receipt_v1.json';r=read(rp)
        assert r['schema']=='A31_NL_BATCH_PRODUCER_RECEIPT_V1'and r['complete'] is True
        assert r['status']=='PRODUCER_COMPLETE_PENDING_INDEPENDENT_AUDIT'and r['phase']==PHASE and r['batch_id']==b['batch_id']
        assert r['completed_job_ids']==b['job_ids']
        for k in ['result_pin','new_cache_pin','predictions_pin']:verify(r[k])
        assert r['counts']['trajectories']==len(b['job_ids'])and r['counts']['logical_stage_instances']==3*len(b['job_ids'])
        return r,rp
    def accepted(b):
        r,rp=producer(b);ap=Path(b['audit_out']);q=read(ap)
        assert q['schema']=='A31_NL_INDEPENDENT_SAVED_BATCH_AUDIT_V1'and q['status']=='PASS_INDEPENDENT_SAVED_BATCH_AUDIT'
        assert q['accepted'] is True and q['failed_checks']==0
        assert q['phase']==PHASE and q['batch_id']==b['batch_id']and q['completed_job_ids']==b['job_ids']
        for key in ['result_pin','producer_receipt_pin','cache_pin','csv_pin']:verify(q[key])
        assert q['result_pin']==r['result_pin']and q['producer_receipt_pin']==pin(rp)and q['cache_pin']==r['new_cache_pin']and q['csv_pin']==r['predictions_pin']
        return {'batch_index':b['batch_index'],'batch_id':b['batch_id'],'outer_fold':b['outer_fold'],'family':b['family'],'replay':b['replay'],
          'audit_pin':pin(ap),'result_pin':r['result_pin'],'producer_receipt_pin':pin(rp),'new_cache_pin':r['new_cache_pin'],'predictions_pin':r['predictions_pin'],'completed_job_ids':b['job_ids']}
    try:
        emit('phase_started',batches=len(batches),jobs=len(ids),automatic_retries=0)
        for b in batches:
            i=b['batch_index'];budget();emit('batch_started',batch_index=i,batch_id=b['batch_id'],jobs=len(b['job_ids']))
            for k in ['out_dir','audit_dir','audit_out','freeze_path','config_path','independent_review_path']:assert not Path(b[k]).exists(),'Consumed path: no automatic resume.'
            lp=child(builder,['--phase-plan',master,'--batch-index',i,'--progress',progressp],'prepare',i,60,[Path(b[k])for k in ['freeze_path','config_path','independent_review_path']],8*1024*1024)
            f,cfg=inspect(b)
            event=ledger('NL sabit batch metadata dondurması','Pinned JIT builder bound fixed literal jobs and accepted same-context cache provenance; no scientific choices or model operations.',{'batch_id':b['batch_id'],'jobs':len(b['job_ids']),'freeze_pin':pin(b['freeze_path'])},[master,Path(b['freeze_path']),lp],'Execute this exact newly owned source batch once.')
            emit('batch_prepared',batch_id=b['batch_id'],ledger=event)
            lp=child(wrapper,['--freeze',b['freeze_path']],'launch',i,float(f['wall_seconds'])+45,[Path(b['out_dir'])],int(f['output_cap_bytes'])+2097152)
            r,rp=producer(b)
            event=ledger('NL kaynak batch üreticisi normal kapandı','Owned MATLAB parent and descendants closed; exact producer artifacts verified. Independent numerical acceptance is pending.',{'batch_id':b['batch_id'],'counts':r['counts']},[Path(b['freeze_path']),rp,lp],'Audit saved outputs before exposing any cache to next batch.')
            emit('batch_producer_complete',batch_id=b['batch_id'],ledger=event)
            ap=Path(b['audit_out']);lp=audit_owned(b)
            record=accepted(b);progress['accepted_records'].append(record);update('RUNNING_ACCEPTED_BATCHES')
            event=ledger('NL kaynak batch bağımsız sayısal kabulü','Pinned independent saved-output checker passed; all four artifacts and literal job IDs bound before next-cache handoff.',{'batch_id':b['batch_id'],'accepted_jobs':len(record['completed_job_ids']),'audit_pin':record['audit_pin']},[ap,progressp,lp],'Proceed only to the next fixed batch; no retuning or repeated accepted job.')
            emit('batch_accepted',batch_id=b['batch_id'],ledger=event,accepted_batches=len(progress['accepted_records']));budget()
        assert len(progress['accepted_records'])==len(batches)
        update('COMPLETE_ALL_FIXED_BATCHES_INDEPENDENTLY_ACCEPTED')
        result={'schema':'A31_NL_PHASE_COORDINATOR_RECEIPT_V1','status':progress['status'],'complete':True,'phase':PHASE,
          'master_plan_pin':pin(master),'progress_pin':pin(progressp),'accepted_batches':len(batches),'accepted_jobs':len(ids),
          'elapsed_current_invocation_seconds':time.monotonic()-started,'cumulative_phase_seconds':used_seconds(),
          'whole_module_bytes':directory_bytes(budget_roots),'selection_performed':False,'automatic_retries':0}
        atomic(out/'coordinator_receipt_v1.json',result);emit('phase_complete',accepted_jobs=len(ids))
        ledger('NL sabit kaynak aşaması tamamlandı','All fixed source batches and saved audits passed; coordinator performed no learning math or profile selection.',result,[master,progressp,out/'coordinator_receipt_v1.json'],'Root reviews the complete accepted pool and separately authorizes reporting/integration.')
        return 0
    except BaseException as e:
        update('STOPPED_FAILURE_OR_UNMET_GATE_NO_RETRY');emit('phase_stopped',error=str(e),accepted_batches=len(progress['accepted_records']))
        failed={'schema':'A31_NL_PHASE_COORDINATOR_FAILED_RECEIPT_V1','complete':False,'status':progress['status'],'error':str(e),'master_plan_pin':pin(master),'progress_pin':pin(progressp),'automatic_retries':0}
        atomic(out/'coordinator_FAILED_receipt_v1.json',failed)
        ledger('NL sabit kaynak aşaması kapıda durdu','Failure and accepted prefix preserved; no automatic retry or accepted source job repeat.',failed,[master,progressp,out/'coordinator_FAILED_receipt_v1.json'],'Inspect the concrete failure and obtain a separately reviewed remaining-job continuation with cumulative budgets.')
        raise

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');raise SystemExit(main())
