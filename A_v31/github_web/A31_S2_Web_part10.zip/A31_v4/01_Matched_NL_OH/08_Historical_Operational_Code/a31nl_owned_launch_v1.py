"""Prospective module-specific owned MATLAB wrapper; not an admission itself.

No command is run unless a fresh exact freeze and its pinned independent
admission are supplied. The unchanged accepted Windows Job helper owns only
the newly created suspended process and its descendants.
"""
from pathlib import Path
import argparse, hashlib, json, sys

W=Path(__file__).resolve().parents[3]
N=W/'A_ARASTIRMASI/A31_NL_Eslenmis_NR_2026_10_25_v1'
G=W/'A_ARASTIRMASI/A_v29.0_2026_10_18/08_Inceleme/a29cl_owned_launcher_v1.py'
GUARD_SHA='2c9ab9459f0ee296cec975c821d5244bc76a006910abdb5374c370fe9230b2b8'
PY=Path(sys.executable)

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def scoped(p,base,must_exist=False):
    p=Path(p).resolve(strict=must_exist);p.relative_to(base.resolve(strict=True));return p
def verify(ref):
    assert isinstance(ref,dict) and all(k in ref for k in ['path','bytes','sha256'])
    p=scoped(ref['path'],W,True)
    assert p.is_file() and p.stat().st_size==ref['bytes'] and digest(p)==ref['sha256'],str(p)
    return p

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--freeze',type=Path,required=True);a=ap.parse_args()
    assert Path(sys.executable).resolve()==PY.resolve(),'Use the bundled Python runtime.'
    assert digest(G)==GUARD_SHA,'Unchanged owned Windows Job dependency required.'
    sys.path.insert(0,str(G.parent))
    from a29cl_owned_launcher_v1 import launch,atomic,now
    fp=scoped(a.freeze,N,True);f=read(fp)
    assert f['status']=='ADMITTED_EXACT_A31_NL_LAUNCH' and f['mode'] in ['control','source']
    mode=f['mode'];wallcap=180 if mode=='control' else 240
    bytecap=30000000 if mode=='control' else 335544320
    assert Path(f['workspace_root']).resolve(strict=True)==W
    assert Path(f['version_root']).resolve(strict=True)==N
    out=scoped(f['out_dir'],N/('06_Controls' if mode=='control' else '04_Results'))
    assert not out.exists(),'Consumed output path: preserve it and obtain a fresh reviewed attempt.'
    assert isinstance(f['wall_seconds'],(int,float)) and 1<=f['wall_seconds']<=wallcap
    assert isinstance(f['output_cap_bytes'],int) and 1<=f['output_cap_bytes']<=bytecap
    assert f['job_commit_limit_bytes']==4294967296 and f['stdout_cap_bytes']==2097152
    seen=set()
    for ref in f['pins']:
        p=verify(ref);assert p not in seen,'Duplicate freeze pin';seen.add(p)
    assert Path(__file__).resolve() in seen and G.resolve() in seen
    code=scoped(f['code_dir'],N/'03_MATLAB',True)
    cfgp=scoped(f['config_path'],N,True);assert cfgp in seen
    cfg=read(cfgp)
    assert cfg['mode']==mode and Path(cfg['out_dir']).resolve()==out/'results'
    reviewp=scoped(f['independent_admission'],N,True);assert reviewp in seen
    review=read(reviewp)
    assert review['admitted'] is True and review['mode']==mode
    entry='a31nl_controls_v1' if mode=='control' else 'a31nl_run_batch_v1'
    assert f['entry_point']==entry and (code/(entry+'.m')).resolve(strict=True) in seen
    protocolp=verify(cfg['protocol_pin']);assert protocolp in seen
    assert digest(protocolp)==review['protocol_pin']['sha256']
    assert verify(review['protocol_pin'])==protocolp
    if mode=='control':
        assert cfg.get('source_run_authorized') is False
        assert cfg.get('fixture_only') is True
    else:
        assert cfg['source_run_authorized'] is True
        assert cfg['admission_token']=='A31_NL_ADMITTED_SOURCE_BATCH'
        assert isinstance(cfg['max_trajectories'],int) and 1<=cfg['max_trajectories']<=70
        assert 1<=cfg['max_seconds']<=f['wall_seconds']
        assert 1<=cfg['max_total_output_bytes']<=f['output_cap_bytes']
        assert 1<=cfg['max_json_bytes']<=280000000
        resourcep=verify(cfg['resource_review_pin']);assert resourcep in seen
        rr=read(resourcep)
        assert rr['admitted'] is True and rr['mode']=='source'
        assert rr['max_trajectories']>=cfg['max_trajectories']
        assert rr['max_seconds']>=cfg['max_seconds']
        assert rr['max_total_output_bytes']>=cfg['max_total_output_bytes']
        jobp=verify(cfg['phase_jobs_pin']);assert jobp in seen
        jobs=read(jobp)
        assert jobs['batch_id']==cfg['batch_id'] and jobs['phase']==cfg['phase']
        assert 1<=len(jobs['jobs'])<=cfg['max_trajectories']
        assert len({j['job_id'] for j in jobs['jobs']})==len(jobs['jobs'])
    matlab=Path(f['matlab']).resolve(strict=True)
    assert str(matlab)==r'C:\Program Files\MATLAB\R2026a\bin\matlab.exe'
    quote=lambda p:"'"+str(p).replace("'","''")+"'"
    expr='addpath('+quote(code)+');a31cfg=jsondecode(fileread('+quote(cfgp)+'));'
    expr+=entry+'('+quote(N)+','+quote(out/'results')+',a31cfg);'
    out.mkdir(parents=True)
    atomic(out/'consumed_freeze_receipt.json',{'freeze':str(fp),'sha256':digest(fp),'consumed_at_utc':now(),'mode':mode,'pins_verified':len(seen),'only_new_owned_process':True,'historical_outputs_preserved':True})
    receipt=launch(matlab,['-singleCompThread','-batch',expr],W,out,f['wall_seconds'],f['output_cap_bytes'])
    print(json.dumps({k:receipt.get(k) for k in ['status','pid','resumed','job_membership_verified','normal_exit','job_empty','elapsed_seconds','owned_peak_job_commit_bytes']},ensure_ascii=False))
    return 0 if receipt['status']=='COMPLETE' and receipt.get('job_empty') else 1

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');raise SystemExit(main())
