"""Metadata-only JIT binding of an already admitted fixed NL/OH8 batch.

No model forward, fit, score selection, source CSV parsing or retries.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,sys

W=Path(__file__).resolve().parents[3]
N=W/'A_ARASTIRMASI/A31_NL_Eslenmis_NR_2026_10_25_v1'
PHASE='matched_nl_oh8_response'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve(strict=True);p.relative_to(W)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def verify(ref):
    p=Path(ref['path']).resolve(strict=True)
    assert pin(p)=={k:ref[k] for k in ['path','bytes','sha256']},str(p)
    return p
def clock():
    t=datetime.datetime.now(datetime.timezone.utc)
    return {'utc':t.isoformat(),'istanbul':t.astimezone(datetime.timezone(datetime.timedelta(hours=3))).isoformat()}
def save_new(p,value):
    p=Path(p).resolve();p.relative_to(N);assert not p.exists(),str(p)
    p.parent.mkdir(parents=True,exist_ok=True)
    b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    assert len(b)<=4000000,'Bound metadata before write.'
    tmp=p.with_suffix(p.suffix+'.tmp');assert not tmp.exists();tmp.write_bytes(b);os.replace(tmp,p)
def accepted_record(record):
    ap=verify(record['audit_pin']);a=read(ap)
    assert a['schema']=='A31_NL_INDEPENDENT_SAVED_BATCH_AUDIT_V1'
    assert a['accepted'] is True and a['failed_checks']==0 and a['status']=='PASS_INDEPENDENT_SAVED_BATCH_AUDIT'
    assert a['completed_job_ids']==record['completed_job_ids']
    for ak,rk in [('result_pin','result_pin'),('producer_receipt_pin','producer_receipt_pin'),('cache_pin','new_cache_pin'),('csv_pin','predictions_pin')]:
        verify(record[rk]);assert a[ak]==record[rk]
    receipt=read(record['producer_receipt_pin']['path'])
    assert receipt['schema']=='A31_NL_BATCH_PRODUCER_RECEIPT_V1' and receipt['complete'] is True
    assert receipt['phase']==PHASE and receipt['completed_job_ids']==record['completed_job_ids']
    for k in ['result_pin','new_cache_pin','predictions_pin']:assert receipt[k]==record[k]
    cache=read(record['new_cache_pin']['path'])
    assert cache['schema']=='A31_NL_EXACT_NEW_CACHE_V1'
    assert isinstance(cache['count'],int) and isinstance(cache['records'],list)
    assert cache['count']==len(cache['records'])==receipt['counts']['actual_new_stagefits']
    return None if cache['count']==0 else {**record['new_cache_pin'],'format':'A31_NL_NEW_CACHE'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase-plan',type=Path,required=True);ap.add_argument('--batch-index',type=int,required=True);ap.add_argument('--progress',type=Path,required=True);a=ap.parse_args()
    master=a.phase_plan.resolve(strict=True);master.relative_to(N);m=read(master)
    assert m['schema']=='A31_NL_PHASE_COORDINATOR_PLAN_V1' and m['status']=='ADMITTED_EXACT_A31_NL_PHASE_COORDINATOR'
    assert m['phase']==PHASE and Path(m['workspace_root']).resolve(strict=True)==W
    assert pin(__file__)==m['prepare_script_pin']
    for p in m['pins']:verify(p)
    S=m['source_contract'];MA=read(verify(S['master_admission_pin']))
    assert MA['admitted'] is True and MA['mode']=='source' and MA['phase']==PHASE
    rr=read(verify(S['resource_pin']))
    assert rr['admitted'] is True and rr['mode']=='source'
    assert rr['max_trajectories']>=70 and rr['max_seconds']>=240 and rr['max_total_output_bytes']>=335544320
    rows=[b for b in m['batches'] if b['batch_index']==a.batch_index];assert len(rows)==1
    b=rows[0];bp=verify(b['job_plan_pin']);j=read(bp)
    assert j['schema']=='A31_NL_EXACT_BATCH_PLAN_V1' and j['phase']==PHASE and j['batch_id']==b['batch_id']
    assert [v['job_id'] for v in j['jobs']]==b['job_ids'] and 1<=len(j['jobs'])<=70
    assert len(b['job_ids'])==len(set(b['job_ids']))
    assert all(v['outer_fold']==b['outer_fold'] and v['family']==b['family'] and v['replay']==b['replay'] for v in j['jobs'])
    assert pin(bp) in MA['batch_plan_pins']
    progress=a.progress.resolve();progress.relative_to(N/'07_Audit')
    records=[]
    if progress.exists():
        pr=read(progress);assert pr['phase']==PHASE and pr['master_plan_sha256']==pin(master)['sha256'];records=pr['accepted_records']
    assert {r['batch_index'] for r in records}==set(range(1,a.batch_index)),'Only fixed accepted prefix may precede the batch.'
    prior=S.get('prior_accepted_cache_records',[])
    caches=[];provenance=[];empty=[];done=[]
    for r in list(prior)+records:
        cp=accepted_record(r);done+=r['completed_job_ids']
        if r['outer_fold']==b['outer_fold'] and r['family']==b['family']:
            provenance.append(r['audit_pin'])
            if cp is None:empty.append(r['new_cache_pin'])
            else:caches.append(cp)
    assert not set(done).intersection(b['job_ids']),'No accepted current-module job may repeat.'
    # Whole historical copies and pure numeric stage caches are distinct interfaces.
    # The producer's exact reuse catalog chooses only admitted whole-payload copies.
    for p in S.get('legacy_cache_inputs',[]):
        if p['outer_fold']==b['outer_fold']:
            verify(p);assert p['format']=='A29_LEGACY_RESULT'
            caches.append({k:p[k] for k in ['path','bytes','sha256','format']})
    cross=[]
    for p in S.get('optional_exact_numeric_cache_inputs',[]):
        verify(p)
        assert p['purpose']=='NUMERICAL_STAGE_ONLY_RECOMPUTE_OH_PREDICTIONS'
        assert p['format'] in ['A31_NR_NEW_CACHE','A31_NL_NEW_CACHE']
        if p['outer_fold']==b['outer_fold'] and b['family']=='OH8':
            caches.append({k:p[k] for k in ['path','bytes','sha256','format']});cross.append(p)
    caches=list({p['path']:p for p in caches}.values())
    for k in ['protocol_pin','input_pin','job_contract_pin','controls_receipt_pin','reuse_catalog_pin','code_manifest_pin']:verify(S[k])
    cfg={
      'mode':'source','out_dir':str(Path(b['out_dir']).resolve()/'results'),
      'source_run_authorized':True,'admission_token':'A31_NL_ADMITTED_SOURCE_BATCH',
      'phase':PHASE,'batch_id':b['batch_id'],'max_seconds':240,
      'max_total_output_bytes':335544320,'max_json_bytes':S['max_json_bytes'],'max_trajectories':70,
      **{k:S[k] for k in ['protocol_pin','input_pin','job_contract_pin','controls_receipt_pin','reuse_catalog_pin','code_manifest_pin']},
      'phase_jobs_pin':pin(bp),'resource_review_pin':S['resource_pin'],'code_pins':S['code_pins'],
      'cache_inputs':caches,'completed_job_ids':sorted(set(done))}
    assert isinstance(cfg['max_json_bytes'],int) and 1<=cfg['max_json_bytes']<=280000000
    irp=Path(b['independent_review_path']).resolve();irp.relative_to(N)
    ir={'schema':'A31_NL_FIXED_BATCH_DERIVED_ADMISSION_V1','status':'PASS_FIXED_JOB_AND_ACCEPTED_CACHE_BINDING',
      'admitted':True,'mode':'source','phase':PHASE,'batch_id':b['batch_id'],'clock':clock(),
      'protocol_pin':S['protocol_pin'],'batch_plan_pin':pin(bp),'batch_plan_sha256':pin(bp)['sha256'],'parent_master_admission_pin':S['master_admission_pin'],
      'metadata_generator_pin':pin(__file__),'source_parameters_chosen_here':False,
      'cache_pins':caches,'accepted_cache_audit_pins':provenance,'accepted_empty_cache_pins':empty,
      'optional_numeric_stage_cache_only':cross,'whole_payload_reuse_catalog_pin':S['reuse_catalog_pin']}
    cfgp=Path(b['config_path']).resolve();cfgp.relative_to(N)
    fp=Path(b['freeze_path']).resolve();fp.relative_to(N)
    out=Path(b['out_dir']).resolve();out.relative_to(N/'04_Results')
    assert not any(p.exists() for p in [irp,cfgp,fp,out]),'No overwrite, resume or automatic retry.'
    save_new(irp,ir);cfg['independent_review_pin']=pin(irp);save_new(cfgp,cfg)
    paths=[Path(p['path']) for p in m['pins']]+[master,Path(__file__).resolve(),irp,cfgp,bp]
    paths+=[Path(p['path']) for p in caches+provenance+empty]
    f={'status':'ADMITTED_EXACT_A31_NL_LAUNCH','mode':'source','clock':clock(),
      'workspace_root':str(W),'version_root':str(N),'out_dir':str(out),'code_dir':str(N/'03_MATLAB'),
      'entry_point':'a31nl_run_batch_v1','config_path':str(cfgp),'independent_admission':str(irp),
      'matlab':r'C:\Program Files\MATLAB\R2026a\bin\matlab.exe',
      'wall_seconds':240,'output_cap_bytes':335544320,'job_commit_limit_bytes':4294967296,'stdout_cap_bytes':2097152,
      'pins':[pin(p) for p in dict.fromkeys(paths)]}
    save_new(fp,f)
    print(json.dumps({'status':'FIXED_BATCH_METADATA_PREPARED','phase':PHASE,'batch_id':b['batch_id'],'freeze_pin':pin(fp),'new_model_operations':0},ensure_ascii=False))

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');main()
