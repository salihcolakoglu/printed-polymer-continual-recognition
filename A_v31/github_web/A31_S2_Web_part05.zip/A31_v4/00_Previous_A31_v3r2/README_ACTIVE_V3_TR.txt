A31 hesaplama eki v3 — aktif yerel inceleme rehberi

Bu yerel inceleme ZIPi, ayrı teslim edilen kabul edilmiş ana makale ve S2 ekini destekler. Dört Word/PDF dosyasının adı, SHA değeri ve kabul kanıtı DOCUMENT_BINDINGS_v3.json içinde kayıtlıdır. Makale dosyaları ayrıca teslim edilir.

Üç mod ve yedi profil vardır. NR, her gerçek görevin 600 güncellemesi boyunca sabittir. Üç görev için artan dizi [0, 0.5, 1], azalan dizi [1, 0.5, 0] olur. Beş sabit profil ise 0, 0.25, 0.5, 0.75 veya 1 değerini bütün görevlerde aynı tutar. Bir tam koşu, üç görevin tamamının öğrenilmesini ve değerlendirilmesini kapsar. T > 1 gerçek görev için artış kuralı alpha_t = (t-1)/(T-1), azalış kuralı bunun 1-alpha_t tersidir. NR hedef karışım katsayısıdır; Adam öğrenme oranı 0.02 olarak korunur.

İncelemeye şu gerçek ZIP üyelerinden başlanabilir:
A31_Taskwise_Seven_Profile_v3/02_Reading/NR5_uc_mod_yedi_profil_tanim_ve_sonuc_TR_v2.txt
A31_Taskwise_Seven_Profile_v3/01_Saved_Tables/NR5_taskwise_seven_profiles_summary_v1.csv
A31_Taskwise_Seven_Profile_v3/02_Reading/A31_EN_TR_Terim_Sozlugu_v4_Taskwise.txt
A31_Taskwise_Seven_Profile_v3/03_Provenance/TASKWISE700_ACTUAL_PORTABLE_MODEL_MEMBER_INDEX_v1.json
A31_Taskwise_Seven_Profile_v3/04_Independent_Audit/NR5_taskwise700_independent_saved_reaggregation_audit_portable_v1.json

Altı CSV, özgün başlıkları ve seçili satırların bayt içeriklerini korur. Dosyalarda 28 özet, 140 başlangıç düzeyinde son sonuç, 420 aşama OOF, 2.100 bölme-aşama, 560 son sınıf satırı ve 38.220 kaydedilmiş karar bulunur. Bağımsız kayıtlı-sonuç denetimi 317.366 kontrol ve sıfır hata ile geçmiştir.

700 yörünge ve 2.100 aşama kaydı, kabul edilmiş 800 yörüngeli ailede zaten bulunmaktadır. Model indeksi, eski çekirdekte gerçekten bulunan bilimsel JSON dosyasını, dosyanın kendi SHA değerini ve iş sırasını gösterir. Özgün kaynak dosyanın SHA değeri ile portatif türevin SHA değeri ayrı tutulur. Bu birleştirmede yeni eğitim, öğretmen hesabı, model sorgusu, optimizer güncellemesi veya Simulink doğrulaması yapılmamıştır.

A31_Analiz_Eki_v2 altındaki eski 192 üye, aynı yollar ve aynı bayt içerikleriyle tarihsel çekirdek olarak korunur. Eski README ve manifestler o sürümlerin kapsamını açıklar. Ana yedili özet, yalnız ek sabit NR = 0.9 ayarını ayrı tutar. NR = 0.9 dahil bütün 800 model ve sonuç ile geniş kapsamlı S8–S9 şekilleri korunur. Yeni bilimsel şekil üretilmemiştir. Eski 800 ailenin 1.470 aşama eğitimi ve 882.000 güncellemesi bu birleştirmenin yeni maliyeti sayılmaz. Önceki 856 yörüngeli iç seçim analizi ayrı kalır.

Bilimsel kapsam; daha önce incelenmiş 104 yayımlanmış ortalama, 26 grup, beş grup bölmesi, beş sayısal başlangıç, iki öğrenme akışı ve iki replay durumu olarak korunur. Mekanik girdiler ve normalizasyon değişmemiştir. TaskIL için 156 son karar görünümü aynı 104 kaydı tekrar kullanır. ClassIL için 104 son kaydın 78'i eski sınıflara, 26'sı yeni sınıfa aittir. Sayısal başlangıçlar fiziksel numune değildir. Yeni kör test, fiziksel doğrulama veya ek NR Simulink doğrulaması eklenmemiştir.

Özgün kod MIT; yazarların yetkisi kapsamındaki bilimsel materyal, belgeler ve model durumları CC BY 4.0 lisansı ile paylaşılır. Kaynak, yöntem ve üçüncü taraf bildirimleri korunur. Güncel kapsam LICENSE_SCOPE_v3.json içindedir.

https://doi.org/10.5281/zenodo.23474663
Bu DOI önceki kamuya açık v30 arşivine aittir. Yerel A31 ZIPi için yeni bir depo kaydı veya DOI iddia edilmez.

06_Historical_Source_Code altındaki betik, tarihsel kaynak kodu olarak korunmuştur. İçindeki özgün araştırma yolları bu ZIP için aktif çalıştırma talimatı değildir. 05_Historical_Reference_Repair altındaki durum alanları önceki kaynakça sırası onarımının tarihçesidir. Güncel ayrı Word/PDF dosyalarının kabul kimliği DOCUMENT_BINDINGS_v3.json ile belirlenir.
