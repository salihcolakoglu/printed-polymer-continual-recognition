A31 COMPUTATIONAL EXTENSION v2 — COMPLETE LOCAL REVIEW HANDOFF

This handoff preserves all 181 immutable files of A31_Analiz_Eki_v2 and adds nine portable independent-acceptance records. README_HANDOFF_v2.txt explains the wrapper; MANIFEST_HANDOFF_v2.json inventories every member except itself. The original core PUBLIC_FILE_MANIFEST_v2.json describes its original 181-file scope, not the additional wrapper records.

Start with README_LOCAL_REVIEW_V2_EN.txt or README_YEREL_INCELEME_V2_TR.txt in the core. The closed-interval NR acceptance note is 04_NR_closed_interval/ACCEPTANCE_SCOPE_v1.json. All 114 files from the earlier extension v1 retain their exact bytes. New fixed-response evidence covers 800 logical trajectories, 2,400 logical stages and all 43,680 final/stage query decisions. Exact historical copies and stage aliases are identified; 1,470 newly fitted stages used 882,000 Adam updates. These numerical trajectories are not independent physical specimens. The separate 856-trajectory inner-development selection procedure is retained, not replaced or relabelled.

The nine files in 05_Independent_Audit_Addenda are portable derivatives of existing accepted audits, not new audit executions. Their source content identities, original SHA-256 values and path-only transfer proof distinguish portable metadata from original workspace records. No credentials or private runtime configuration is supplied.

New closed-NR models have saved numerical checks, not additional Simulink verification. Original archived Simulink evidence remains scoped to the original frozen M2 bank. Existing v30.0 GitHub/Zenodo links are historical public archives; this A31 addition is a local review handoff, not a newly published DOI.

Original code uses MIT. Source-derived scientific data/results/models/figures/docs use CC BY 4.0 within the retained notices and rights. Consult the original LICENSE/SCOPE/third-party notices before reuse.

Türkçe: Bu dış teslim ZIP'i, 181 dosyalık kapalı v2 hesaplama ekini aynen korur ve 9 taşınabilir bağımsız kabul/denetim kaydı ekler. Yeni baştan eğitim veya denetim yapılmamıştır. Çalışma kayıt ortalamaları üzerindeki keşifsel karşılaştırmadır; yeni fiziksel numune/kör test/NR Simulink doğrulaması iddia edilmez.
