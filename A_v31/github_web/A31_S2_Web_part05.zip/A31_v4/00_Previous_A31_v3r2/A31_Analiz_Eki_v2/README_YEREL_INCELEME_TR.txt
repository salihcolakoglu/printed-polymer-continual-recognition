A31 yerel analiz eki

Bu klasör Hoca değerlendirmesine sunulacak ayrı Word/PDF dosyalarını destekler; A31 için yeni kamu yayını veya DOI değildir. Önceki kamu DOI 10.5281/zenodo.23474663 eski v30 arşivini tanımlar.

01_P1 kabul edilmiş şekil/tablo/kaynak sayımları;02_P2 baskı girdileriyle NN1/PROTO verisi, sabit bölme/ölçekleme, kod ve kayıtlı sonuçlar;03_NR tamamlanan sonlu negotiation taraması için seçilmiş100dış model yörüngesi/300aşama/5460tahmin, güvenli104kayıt/30bölme verisi, protokol/kod, bütün geliştirme sayımları ve5başlangıç sonuçlarını içerir. İç756yörüngenin büyük ham durum/önbellekleri araştırma alanında kalır; bunların tam DEVsayım tabloları ve tasarım/kodları burada vardır.

Bu derleme yeni eğitim, tahmin, render veya Simulink doğrulaması yapmaz. Yeni NRmodellerinin ayrıca Simulink’te doğrulandığı söylenmez. Özgün26dosyalık seçilmiş model bankası aynen korunmuştur; rootbağımsız aktarım kabulü SD10585tir. Kaynak104yayımlanmış ortalama/26grup sınırı ve previouslyexposed durumu değişmedi. TaskIL156karar104kaydı ikili görevlerde yeniden kullanır; bağımsız fiziksel numune değildir.

Kişisel mutlak dosya yolları, iç koşu/config/alındılar, özel makale PDFleri ve runtime/lisans anahtarları pakete alınmadı. Kod MIT, bilimsel materyal yetki kapsamında CC BY4.0dır; mevcut kaynak/yöntem bildirimleri korunur. Tam bağımsız koşu için ayrıca uygun ortam ve gözden geçirilmiş çalıştırma yapılandırması gerekir. Dosya kimlikleri PUBLIC_FILE_MANIFEST_v1.json içindedir. Bağımsız seçki incelemesinden önce ZIP oluşturulmaz. Ayrı Word/PDF ekleri burada yinelenmez.
