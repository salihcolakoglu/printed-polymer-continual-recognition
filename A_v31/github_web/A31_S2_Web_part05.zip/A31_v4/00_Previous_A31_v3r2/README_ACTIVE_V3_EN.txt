A31 computational wrapper v3 — active local review guide

This local review ZIP accompanies the separately delivered, accepted main manuscript and Supplement S2. DOCUMENT_BINDINGS_v3.json records the four Word/PDF filenames, content hashes and QA evidence. The manuscripts are delivered separately.

The primary comparison has three modes and seven profiles. NR stays constant throughout all 600 updates of each genuine task. With three tasks, the increasing profile is [0, 0.5, 1] and the decreasing profile is [1, 0.5, 0]. The five constant profiles use 0, 0.25, 0.5, 0.75 or 1 in every task. One complete trajectory learns and evaluates all three tasks. For any task count T > 1, the increasing rule is alpha_t = (t-1)/(T-1), and the decreasing rule is 1-alpha_t. NR mixes targets; the Adam learning rate remains 0.02.

Start with these actual ZIP members:
A31_Taskwise_Seven_Profile_v3/01_Saved_Tables/NR5_taskwise_seven_profiles_summary_v1.csv
A31_Taskwise_Seven_Profile_v3/02_Reading/NR5_uc_mod_yedi_profil_tanim_ve_sonuc_TR_v2.txt
A31_Taskwise_Seven_Profile_v3/02_Reading/A31_EN_TR_Terim_Sozlugu_v4_Taskwise.txt
A31_Taskwise_Seven_Profile_v3/03_Provenance/TASKWISE700_ACTUAL_PORTABLE_MODEL_MEMBER_INDEX_v1.json
A31_Taskwise_Seven_Profile_v3/04_Independent_Audit/NR5_taskwise700_independent_saved_reaggregation_audit_portable_v1.json

The six new CSVs retain the original headers and selected row bytes. They contain 28 summary rows, 140 seed-level final rows, 420 stage OOF rows, 2,100 fold-stage rows, 560 final-class rows and 38,220 saved decisions. The independent saved-result audit passed 317,366 checks with zero failures.

All 700 trajectories and 2,100 stage payloads already existed in the accepted 800-trajectory family. The model index points to actual scientific JSON members under A31_Analiz_Eki_v2/04_NR_closed_interval, with each member hash and job index. Original source-file hashes and derived portable-file hashes are recorded separately. This curation performed no new fit, teacher forward, query prediction, optimizer update or Simulink validation.

The 192 members under A31_Analiz_Eki_v2 are retained byte for byte as the historical core. Its earlier README files and manifests describe those earlier versions. The primary seven-profile table excludes only the additional constant NR = 0.9 setting. All 800 models and outcomes, including NR = 0.9, remain available. The existing broader Figures S8–S9 also remain unchanged. No new scientific figure was rendered. The historical 800-family work of 1,470 new stage fits and 882,000 updates is not a new cost for this consolidation. The earlier selected-NR analysis of 856 trajectories remains separate.

The scientific scope remains 104 previously examined published averages in 26 groups, five whole-group folds, five numerical starts, two streams and two replay settings. The original mechanical inputs and normalizers are preserved. TaskIL has 156 final decision views reusing 104 parents. ClassIL has 104 final views: 78 earlier-class and 26 newest-class views. Numerical starts are not physical specimens. New blind testing, physical validation and additional NR Simulink validation were not added.

Original software uses MIT. Authored scientific outputs, documentation and model states use CC BY 4.0 within the authors' rights. The original method and third-party notices remain applicable. See LICENSE_SCOPE_v3.json and the five retained notice files.

Public links retain their earlier meaning:
https://doi.org/10.5281/zenodo.23474663
The DOI above identifies the earlier public v30 archive. This local A31 ZIP has not been newly deposited and is not assigned that DOI.
https://doi.org/10.17632/zd6td6svd6.2
https://doi.org/10.3390/mi17070859
These identify the original source dataset and article, whose attribution and terms remain.
https://github.com/salihcolakoglu/printed-polymer-continual-recognition
This is the existing repository; this curation makes no claim that it has been updated.

The script under 06_Historical_Source_Code is a preserved provenance copy. Its original workspace paths describe the earlier research environment; they are not an active launch instruction for this ZIP. The records under 05_Historical_Reference_Repair retain the statuses of that earlier reference-order repair. Current separate-document acceptance is recorded in DOCUMENT_BINDINGS_v3.json.
