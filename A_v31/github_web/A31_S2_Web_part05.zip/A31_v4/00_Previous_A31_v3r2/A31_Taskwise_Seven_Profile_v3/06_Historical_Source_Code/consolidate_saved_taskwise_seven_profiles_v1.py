"""Saved-only seven-profile consolidation. No model, optimizer or decoder imports."""
from pathlib import Path
import collections,csv,hashlib,io,json,shutil,sys
W=Path(r'C:\Springer ve Tübitak Ulakbilim Tr Dizin Çalışmaları');F=Path(__file__).parent;N=W/'A_ARASTIRMASI/A31_NR_Tam_Aralik_2026_10_24_v1';R=N/'06_Report/ACCEPTED_REPORT_RUN_01'
sys.path.insert(0,str(W/'A_ARASTIRMASI/A_v25.0_2026_10_11/08_Inceleme'));from a25_log import log
PROFILES=[('F00_STATIC',[0,0,0],'Sabit'),('F25',[.25,.25,.25],'Sabit'),('F50',[.5,.5,.5],'Sabit'),('F75',[.75,.75,.75],'Sabit'),('F100_SELF_TARGET',[1,1,1],'Sabit'),('UP_CLOSED_LINEAR',[0,.5,1],'Artan'),('DOWN_CLOSED_LINEAR',[1,.5,0],'Azalan')]
ALLOWED={p[0]:p for p in PROFILES}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def verify(q):p=Path(q['path']);z=pin(p);assert(z['bytes'],z['sha256'])==(q['bytes'],q['sha256']);return p
def save(p,j):assert not p.exists();p.write_text(json.dumps(j,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def digest(j):return hashlib.sha256(json.dumps(j,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()
def filtered_csv(source,dest,expected):
 raw=source.read_bytes();lines=raw.splitlines(keepends=True);header=next(csv.reader([lines[0].decode('utf-8-sig')]))
 assert 'schedule_id'in header;ix=header.index('schedule_id');kept=[];rows=[]
 for line in lines[1:]:
  if not line.strip():continue
  row=next(csv.reader([line.decode('utf-8')]))
  if row[ix]in ALLOWED:kept.append(line);rows.append(dict(zip(header,row)))
 assert len(rows)==expected;assert not dest.exists();dest.write_bytes(lines[0]+b''.join(kept))
 with dest.open(encoding='utf-8-sig',newline='')as h:assert list(csv.DictReader(h))==rows
 return rows,dict(source_pin=pin(source),output_pin=pin(dest),source_row_bytes_preserved=True,selected_rows=len(rows),excluded_profile_only='F90',header_columns=header)
def main():
 prp=N/'05_Audit/FR_SOURCE_COMPOSITE_RUN_01/composite_progress_v1.json';pr=read(prp);poolp=N/'05_Review/FR_complete800_independent_pool_v2.json';pool=read(poolp)
 assert pool['accepted']and pool['failed_checks']==0 and pool['trajectories']==800 and pin(poolp)['sha256']=='17d01fcc2bc62bef8927ab643839f2c83992aa0202c962e5efe4ab9e4090810f'
 reportaudit=N/'05_Denetim/FR_complete800_independent_report_v1.json';ra=read(reportaudit);assert ra['accepted']and ra['failed_checks']==0
 catalog=[];sourcepins=[];rawdecision={};old_counts=collections.Counter();modelhashes=[]
 for br in pr['accepted_records']:
  src=verify(br['result_pin']);ap=Path(br['audit_path']);assert pin(ap)['sha256']==br['audit_sha256'];audit=read(ap);assert audit['accepted']and audit['failed_checks']==0 and audit['result_pin']['sha256']==br['result_pin']['sha256']
  b=read(src);assert b['counts']['trajectories']==80
  sourcepins.append(dict(result_pin=pin(src),audit_pin=pin(ap),producer_pin=br['producer_receipt_pin'],original_predictions_pin=br['predictions_pin'],batch_id=br['batch_id']))
  for index,saved in enumerate(b['jobs'],1):
   job=saved['job'];sid=job['schedule_id']
   if sid not in ALLOWED:assert sid=='F90';continue
   alpha=ALLOWED[sid][1];assert job['alpha']==alpha and len(saved['stages'])==3 and len(saved['predictions'])>0
   assert not saved['source_free_control']and saved['all_updates_per_stage']==600
   for stage in range(1,4):assert saved['stages'][stage-1]['alpha']==alpha[stage-1]
   payload={k:saved[k]for k in ['normalizer','initial_state','stages','predictions','metrics']};h=digest(payload);modelhashes.append(h)
   original_activity={k:saved[k]for k in ['actual_new_stagefits','actual_optimizer_updates','source_training_stages','source_optimizer_updates','new_source_prediction_rows','historical_prediction_rows_reused']}
   old_counts.update(original_activity)
   catalog.append(dict(source_job_id=job['job_id'],source_job_index1=index,source_result_pin=pin(src),source_audit_pin=pin(ap),source_producer_pin=br['producer_receipt_pin'],source_prediction_CSV_pin=br['predictions_pin'],profile_id=sid,mode=ALLOWED[sid][2],alpha_by_task=alpha,outer_fold=job['outer_fold'],seed=job['seed'],replay=job['replay'],stream=job['stream'],logical_stages=3,saved_prediction_rows=len(saved['predictions']),source_fit_SHA256=[q['fit_reference']['job_sha256']for q in saved['stages']],canonical_saved_scientific_payload_SHA256=h,canonical_hash_definition='UTF8sortedkeycompactJSON of originalnormalizer/initial_state/stages/predictions/metrics; not originalfilehash.',historical_execution_fields_verbatim=original_activity,current_consolidation_work=dict(new_fits=0,new_optimizer_updates=0,new_teacher_forwards=0,new_query_forwards=0),all_original_states_and_predictions_reused_by_reference=True))
   for p in saved['predictions']:
    key=(job['job_id'],int(p['stage']),int(p['task']),p['parentrow']);assert key not in rawdecision
    rawdecision[key]=(int(p['truth']),int(p['label']),bool(p['valid']),bool(p['tie']),job['outer_fold'],job['stream'],sid,alpha,bool(job['replay']),job['seed'])
  del b
 assert len(catalog)==700 and len(rawdecision)==38220 and len(set(q['source_job_id']for q in catalog))==700
 profilecounts=collections.Counter(q['profile_id']for q in catalog);assert profilecounts==dict.fromkeys(ALLOWED,100)
 outputs=[];tables={}
 specs=[('summary',28),('all_seed_final',140),('all_stage',420),('fold_stage',2100),('final_class',560),('saved_decisions',38220)]
 for stem,count in specs:
  rows,proof=filtered_csv(R/('NR_closed_interval_'+stem+'_v1.csv'),F/('NR5_taskwise_seven_profiles_'+stem+'_v1.csv'),count);outputs.append(proof);tables[stem]=rows
 for row in tables['saved_decisions']:
  key=(row['job_id'],int(row['stage']),int(row['task']),row['parentrow']);v=rawdecision[key]
  got=(int(row['truth']),int(row['label']),row['valid']=='True',row['tie']=='True',int(row['outer_fold']),row['stream'],row['schedule_id'],[float(row['alpha1']),float(row['alpha2']),float(row['alpha3'])],row['replay']=='True',int(row['seed']))
  assert got==v
 copies=[]
 for srcname,dstname in [('NR_closed_interval_batch_activity_v1.csv','NR5_full800_historical_batch_activity_verbatim_v1.csv'),('NR_closed_interval_actual_activity_v1.json','NR5_full800_historical_actual_activity_verbatim_v1.json')]:
  src=R/srcname;dst=F/dstname;assert not dst.exists();shutil.copyfile(src,dst);assert pin(src)['sha256']==pin(dst)['sha256'];copies.append(dict(source_pin=pin(src),output_pin=pin(dst),scope='FULL_ACCEPTED800_SOURCE_RUN_ACTIVITY_NOT_NEW700_COST'))
 cp=F/'NR5_taskwise_700_subset_catalog_v1.json';save(cp,dict(schema='A31_NR5_TASKWISE700_SAVED_SUBSET_CATALOG_V1',status='READ_SAVED_ONLY_EXISTING700_REUSED_NO_NEW_SOURCE_EXECUTION',source_canonical_event='SD-10721',accepted_pool_pin=pin(poolp),accepted_report_audit_pin=pin(reportaudit),accepted_composite_progress_pin=pin(prp),profiles=[dict(profile_id=s,mode=m,alpha_by_task=a)for s,a,m in PROFILES],entries=catalog,source_batches=sourcepins,counts=dict(logical_trajectories=700,logical_stages=2100,saved_prediction_rows=38220,source_models_reused=700,new_training=0,new_predictions=0)))
 text=['A31 NR: gerçek görev başına sabit üç mod ve yedi profil','', 'Her deney, tanımlı gerçek görevlerin tamamının sırayla öğrenilmesi ve her aşamadan sonra değerlendirilmesidir. Mevcut çalışmada üç gerçek görev/aşama vardır. NR aynı görevin600Adamgüncellemesi boyunca sabittir; değişim yalnız gerçek görevler arasındadır. NR hedef karışım katsayısıdır, Adamöğrenmeoranı0.02den ayrıdır.','', '1. Sabitmod: seçilenNR bütün görevlerde aynıdır. Beşayrıayar0,0.25,0.5,0.75,1 ile beşayrı tamamlanmış deneyprofili vardır.','2. Artanmod: gerçekgörevsayısıT için alpha_t=(t-1)/(T-1). MevcutT=3için[0,0.5,1] kullanılır.','3. Azalanmod: alpha_t=1-(t-1)/(T-1). MevcutT=3için[1,0.5,0] kullanılır.','', 'Beşbasamak örneği beşgerçekgörev varsa[0,0.25,0.5,0.75,1]olur. Üçgerçekgörevden beşgörev icat edilmez ve tek görev içinde NR değiştirilmez. T=1olursa artış/azalış tanımı ayrıca belirlenmelidir; bu çalışmadaT=3tür.','', 'Yedi profilin tamamı önceki kabul edilmiş800ailesinde zaten vardır. Bu düzenleme yalnızF90ekayarını yedili anaözetten ayırır; eski800sonucu, F90dahil, arşivde aynen korur. Yeni eğitim, öğretmenhesabı, sınıflandırma veya tahmin yapılmadı. Artan/azalan üçgörev dizileri yeniupdateblokları değildir.','', 'Aynı104yayımlanmış ortalama/26grup, beşgrupfold, beşbaşlangıç, ikireplaydurumu ve ikiakış korunur. Herprofil100tamyörüngeye karşılık gelir:5fold×5seed×2replay×2akış. Toplam700yörünge/2100aşama/38220kaydedilmişkarar yeniden kullanılır. SonTaskIL156karargörünümü104kaydı tekrar kullanır; ClassIL104kayıttır. Başlangıçlar bağımsız fizikselnumune değildir.','', 'Aşağıdaki değerler beşbaşlangıç medyanı[min–maks]doğruluk yüzdesidir; herbaşlangıçta beşdeğişmeyen grupfold birleştirilmiştir.','', 'Profil | NRgörev1/2/3 | TaskILbelleksiz | TaskILreplay | ClassILbelleksiz | ClassILreplay']
 summary={(r['schedule_id'],r['stream'],r['replay']):r for r in tables['summary']}
 for sid,aa,mode in PROFILES:
  vals=[]
  for stream,replay in [('TaskIL','False'),('TaskIL','True'),('ClassIL','False'),('ClassIL','True')]:
   r=summary[(sid,stream,replay)];vals.append(f"{float(r['median_percent']):.2f}[{float(r['min_percent']):.2f}–{float(r['max_percent']):.2f}]")
  text.append(mode+' '+sid+' | '+ '/'.join(str(a)for a in aa)+' | '+' | '.join(vals))
 text+=['', 'Özgünmodeller, incoming/finalAdamdurumları, hedefönbellekleri ve tahminler700kataloggirdisinin kaynakSHA/jobindexbağlarıyla korunur. Önceki hesaplamaekiv2tüm800ailesinimodel/veri/kodolarak içerir; bu yedili özet özgün arşivin üstüne yazmaz. Herkataloggirdisinin özgüntarihsel işsayısı ayrıalanlarda kalır. Eski800koşusunun1470yeniaşama/882000güncelleme kaydı yeniüretim veya700ayrıkoşunun maliyeti sayılmaz.','', 'Sonuçlar kayıtözelindedir. Kaynakortalamalar dahaönceden incelendiği için yeni körtest veya fizikseldoğrulama iddia edilmez. YeniSimulinkdoğrulaması eklenmedi. SabitNR1ClassILreplaydurumunda yeni sınıfın başarıları sıfırdır; belleksizNR1de[1,9,1,0,5]/26 olduğundan bunu bütünkoşullara yaymayız. Artanmodun ClassILyeni sınıfı iki replaydurumunda da sıfırdır. TaskILyeni görev52kararlıPLA+/PLA-CFikilisidir ve tek26kayıtlıyeni sınıfla karıştırılmaz.','', 'Bu çalışma yalnızAaraştırmasıdır; ASOCveya başka projelere dokunulmadı.']
 tr=F/'NR5_uc_mod_yedi_profil_tanim_ve_sonuc_TR_v1.txt';assert not tr.exists();tr.write_text('\n'.join(text)+'\n',encoding='utf-8')
 proof=F/'NR5_taskwise_saved_subset_identity_proof_v1.json';save(proof,dict(schema='A31_NR5_TASKWISE_SAVED_SUBSET_IDENTITY_PROOF_V1',status='PASS_700_EXISTING_JOB_IDENTITIES_AND38220_SAVED_DECISIONS_NO_NEW_MODEL_CALLS',catalog_pin=pin(cp),source_pool_pin=pin(poolp),source_report_audit_pin=pin(reportaudit),source_batches=sourcepins,filtered_tables=outputs,historical_activity_copies=copies,profile_job_counts=dict(profilecounts),saved_query_identity_comparisons=38220,scientific_payload_canonical_hashes=700,historical_original_job_execution_contribution=dict(old_counts),historical_counter_warning='These are original-order execution fields retained from selected job records. They are not new700training and not intrinsicstandalonecost. Full800history is copiedseparately.',current_consolidation_work=dict(new_training=0,new_teacher_forwards=0,new_query_forwards=0,new_optimizer_updates=0,new_Simulink=0),source_payloads_modified=False,global_block_design_not_adopted=True,raw_models_referenced_exactly_not_reexecuted=True,definition_TR_pin=pin(tr)))
 allfiles=[p for p in sorted(F.iterdir())if p.is_file()];manifest=F/'NR5_taskwise_consolidation_manifest_v1.json';save(manifest,dict(schema='A31_NR5_TASKWISE_CONSOLIDATION_MANIFEST_V1',manifest_self_excluded=True,files=[pin(p)for p in allfiles]))
 e=log('A31 gerçekgörevde sabitNR üçmod/yediprofil mevcut sonuçlardan birleştirildi','SonkullanıcıanlamıgerçekgöreviçindesabitNR/yalnızgörevsınırındadeğişimdir. MevcutT3içinartan0,.5,1veazalan1,.5,0 ilebeşsabitayarFR800kabulünde zatenmevcuttur. Saltkaydedilmiş10result/audit/reportokunup700iş/2100aşama/38220tahminkimliği doğrulandı;28/140/420/2100/560/38220satır6CSVözgünheader+satırbaytlarıkorunarakF90hariçtüretildi.700model/statedataSHAindexkataloğu ve3modyedilitabloTRyazıldı. Eski800işmaliyetiverbatim/tarihselayrı; yeniöğrenme/tahmin0. Kullanılmamışglobalbloktaslaklarına/ASOCadokunulmadı.',{'profiles':7,'existing_reused_jobs':700,'saved_decisions':38220,'new_training':0,'new_predictions':0,'filtered_tables':6},type='A31_NR5_TASKWISE_SEVEN_PROFILE_SAVED_CONSOLIDATION',objective='Kullanıcıistemini mevcut gerçekgörevsemantiğinde tamamlanmışkanıtlaeşleştirmek; gereksizyenidenkoşuyuönlemek',reason='Beşbasamak kullanıcıörneğidir; T3görevdeuniformartış0,.5,1olur. İstenenüçmodun bütün7profili zatenacceptedFR800içindedir; yenihipotezişletmişgibi sunulmaz.',evidence=[str(cp),str(proof),str(tr),str(manifest)],uncertainty='Yeniikincisavedaggregationauditroot/numericagenttarafındanyapılacak; buaktarımıindependentkabulühenüziddiaetmez. Sonuçlarpreviouslyexposedyayımlanmışortalamaevreniylesınırlıdır.',next_step='Bağımsızajan yediliprofillerin hamkaydedilmiş700sonucundan tümözetleritekraraggregateedip karşılaştırır; rootmetin/şekil/e-posta/yerelteslimi buanlamagörebirleştirir. Yenikaynakeğitimi/tahminiyapılmaz.')
 print(json.dumps(dict(event=e,catalog_pin=pin(cp),identity_pin=pin(proof),manifest_pin=pin(manifest),TR_definition_pin=pin(tr),counts=dict(jobs=700,stages=2100,predictions=38220),current_model_calls=0),ensure_ascii=False,indent=2))
if __name__=='__main__':sys.stdout.reconfigure(encoding='utf-8');main()
