function spec=a31nl_terms_v1(cur,memory,target,family,updates,control_only)
% Original objective ordering/weights with one immutable negotiated current term.
D=target.D;assert(any(D==[4 8])&&strcmp(target.family,family),'A31NL:Family','Target family/width mismatch.');
assert((~control_only&&updates==600)||(control_only&&ismember(updates,[1 2 3 600])), ...
 'A31NL:Budget','Production requires600updates. A short stage is artificial-only.');
assert(isequal(target.current_parentindex,cur.parentindex),'A31NL:Current','Target does not belong to this current TRAIN.');
if D==4
 if target.alpha==0,terms=term('ce',cur.Z,cur.y,cur.eligible,1,1);
 else,terms=term('softce',cur.Z,target.q,cur.eligible,1,1);end
else,terms=term('bce',cur.Z,target.q,[],1,1);end
if ~isempty(memory)&&~isempty(memory.y)
 assert(all(isfield(memory,{'Z','y','parentindex','firsttask'}))&& ...
  size(memory.Z,1)==numel(memory.y)&&isempty(intersect(memory.parentindex,cur.parentindex)), ...
  'A31NL:Replay','Replay must be aligned historical rows excluding all current parent IDs.');
 terms(1).weight=.5;
 if D==8
  C=[eye(4),zeros(4,4)];terms(2)=term('bce',memory.Z,C(memory.y,:),[],1,.5);
 elseif strcmp(cur.stream,'TaskIL')
  for task=reshape(unique(double(memory.firsttask)),1,[])
   idx=double(memory.firsttask)==task;
   terms(end+1)=term('ce',memory.Z(idx,:),memory.y(idx),[1,task+1],1,.5*sum(idx)/numel(memory.y)); %#ok<AGROW>
  end
 else,terms(2)=term('ce',memory.Z,memory.y,1:cur.stage+1,1,.5);end
end
spec=struct('D',D,'terms',terms,'anchors',struct('theta',{},'F',{}), ...
 'ewc_lambda',0,'updates',double(updates),'control_only',logical(control_only));
end
function t=term(kind,Z,target,mask,T,weight)
t=struct('kind',kind,'Z',Z,'target',target,'mask',mask,'T',double(T),'weight',double(weight));
end
