function out=a31nl_targets_v1(theta,cur,family,alpha)
% One detached CURRENT TRAIN target cache. No file/evaluator/replay access.
assert(ischar(family)&&any(strcmp(family,{'NL4','OH8'})), ...
 'A31NL:Family','Only NL4 and OH8 target families are supported.');
D=4;if strcmp(family,'OH8'),D=8;end
assert(isa(alpha,'double')&&isscalar(alpha)&&isreal(alpha)&&isfinite(alpha)&&alpha>=0&&alpha<=1, ...
 'A31NL:Alpha','A finite scalar binary64 alpha in [0,1] is required.');
assert(isa(theta,'double')&&iscolumn(theta)&&numel(theta)==12+5*D&&isreal(theta)&&all(isfinite(theta)), ...
 'A31NL:State','Incoming theta width or values are invalid.');
assert(isstruct(cur)&&isscalar(cur)&&all(isfield(cur,{'kind','Z','y','eligible','parentindex','parentrow'}))&& ...
 strcmp(cur.kind,'CURRENT_TRAIN'),'A31NL:Current','Only a current TRAIN batch may construct a target.');
Z=cur.Z;y=cur.y;N=size(Z,1);
assert(isa(Z,'double')&&isreal(Z)&&ismatrix(Z)&&N>=1&&size(Z,2)==2&&all(isfinite(Z),'all')&& ...
 isnumeric(y)&&isreal(y)&&isvector(y)&&numel(y)==N&&all(isfinite(y))&&all(y==fix(y))&&all(ismember(y,1:4)), ...
 'A31NL:Rows','Z and global hard labels must be aligned finite rows.');
ids=cur.parentindex;
assert(isnumeric(ids)&&isreal(ids)&&isvector(ids)&&numel(ids)==N&&all(isfinite(double(ids)))&& ...
 all(double(ids)>=1&double(ids)==fix(double(ids)))&&numel(unique(ids))==N, ...
 'A31NL:ParentIDs','One unique positive finite integer parent ID per current row is required.');
rows=cur.parentrow;
assert((iscellstr(rows)||isstring(rows))&&numel(rows)==N&&all(strlength(string(rows(:)))>0), ...
 'A31NL:ParentRows','Current parent-row names must be aligned nonempty text.'); %#ok<ISCLSTR>
mask=double(cur.eligible(:)');
assert(isvector(mask)&&numel(mask)>=2&&numel(mask)<=4&&all(isfinite(mask))&& ...
 isequal(mask,sort(unique(mask)))&&all(ismember(mask,1:4))&&all(ismember(y,mask)), ...
 'A31NL:Mask','Current mask must be ascending eligible global labels containing every current target.');
if D==4
 hard=zeros(N,numel(mask));[~,local]=ismember(double(y(:)),mask);
 hard(sub2ind(size(hard),(1:N)',local))=1;
else
 C=[eye(4),zeros(4,4)];hard=C(double(y(:)),:);
end
teacher=[];logits=[];prob=[];q=hard;
if alpha>0
 teacher=theta;logits=a29cl_math('forward',teacher,Z,D);
 if D==4
  a=logits(:,mask);z=a-max(a,[],2);logp=z-log(sum(exp(z),2));prob=exp(logp);
 else
  prob=zeros(size(logits));pos=logits>=0;prob(pos)=1./(1+exp(-logits(pos)));
  e=exp(logits(~pos));prob(~pos)=e./(1+e);
 end
 q=(1-alpha)*hard+alpha*prob;
end
assert(all(isfinite(q),'all')&&all(q(:)>=0&q(:)<=1),'A31NL:Target','Nonfinite or out-of-range cached target.');
if D==4,assert(all(abs(sum(q,2)-1)<=1e-12),'A31NL:TargetMass','Unmodified target row mass failed its declared tolerance.');end
out=struct('schema','A31_NL_DETACHED_TARGET_CACHE_V1','family',family,'D',D,'alpha',alpha,'mask',mask, ...
 'teacher',teacher,'teacher_logits',logits,'teacher_probabilities',prob,'hard_targets',hard,'q',q, ...
 'current_parentindex',ids,'current_parentrow',{rows},'teacher_forward_rows',double(alpha>0)*N, ...
 'own_stage_start_detached',true,'recomputed_during_updates',false,'zero_alpha_skips_teacher',alpha==0, ...
 'scope','CURRENT_TRAIN_ONLY');
end
