function [bundle,splits]=a31nr_fixture_v1(options)
% Explicit arithmetic fixture; no physical population or source-row access.
if nargin==0,options=struct;end
C=repmat(struct('index1',0,'parentrow','','group','','group_order',0,'label',0,'outer_fold',0,'X',zeros(1,2)),104,1);
for g=0:25
 for y=1:4
  j=4*g+y;xx=[g/7+y/3,(-1)^y*(g+1)/9+y/5];
  if isfield(options,'future_shift')&&y==4,xx=xx+options.future_shift;end
  if isfield(options,'heldout_shift')&&mod(g,5)==0,xx=xx+options.heldout_shift;end
  C(j)=struct('index1',j,'parentrow',sprintf('ARTIFICIAL_G%02d_Y%d',g,y), ...
   'group',sprintf('ARTIFICIAL_GROUP_%02d',g),'group_order',g,'label',y, ...
   'outer_fold',1+mod(g,5),'X',xx);
 end
end
N=struct([]);splits=struct([]);X=vertcat(C.X);
for f=1:5
 tr=find([C.outer_fold]'~=f);dv=find([C.outer_fold]'==f);fit=tr([C(tr).label]<=2);
 n=struct('fold',f,'mean',mean(X(fit,:),1),'sd',std(X(fit,:),0,1), ...
  'n',numel(fit),'train_row_ids',{{C(fit).parentrow}});N=append(N,n);
 s=struct('split_id',sprintf('ART_O%02d_outer_I00',f),'outer_fold',f, ...
  'inner_design','outer','inner_fold',0,'train_indices1',tr, ...
  'dev_indices1',dv,'outer_test_indices1',dv,'normalizer_fit_indices1',fit);splits=append(splits,s);
end
bundle=struct('records',C,'outer_normalizers',N,'codebook_WH8', ...
 [0 1 0 1 0 1 0 1;0 0 1 1 0 0 1 1;0 1 1 0 0 1 1 0;0 0 0 0 1 1 1 1], ...
 'source','SOURCE_FREE_ARTIFICIAL_FIXTURE');
end
function a=append(a,r),if isempty(a),a=r;else,a(end+1)=r;end,end
