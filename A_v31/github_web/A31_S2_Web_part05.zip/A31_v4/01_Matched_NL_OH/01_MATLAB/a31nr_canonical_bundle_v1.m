function bundle=a31nr_canonical_bundle_v1(bundle)
% JSON vectors may become columns. Shape-only canonicalization, no imputation.
R=bundle.records;if iscell(R),R=[R{:}];end
assert(numel(R)==104,'A31NR:JSONRecords','Exactly104 metadata records required.');
for i=1:numel(R)
 assert(isnumeric(R(i).X)&&isreal(R(i).X)&&numel(R(i).X)==2, ...
  'A31NR:JSONFeatureShape','Eachrecord has exactly two numeric coordinates.');
 R(i).X=reshape(double(R(i).X),1,2);
end
bundle.records=R;
end
