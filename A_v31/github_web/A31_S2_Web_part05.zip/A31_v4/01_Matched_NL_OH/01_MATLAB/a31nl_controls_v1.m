function receipt=a31nl_controls_v1(versionRoot,outDir,config)
% Finite artificial implementation proof only. No CSV/source-model loader.
versionRoot=canonical(versionRoot);outDir=canonical(outDir);
assert(strcmp(config.mode,'control')&&~isfield(config,'input_pin')&&~isfield(config,'cache_inputs')&& ...
 startsWith(lower(outDir),lower([versionRoot filesep '06_Controls' filesep])), ...
 'A31NL:ControlScope','Artificial control output only; real-input pins are forbidden.');
if isfolder(outDir),d=dir(outDir);assert(~any(~ismember({d.name},{'.','..'})),'A31NL:NoOverwrite','Existing control evidence is preserved.');else,mkdir(outDir);end
clock=tic;checks={};gradientCases={};objectiveCases={};aliasCases={};parityCases={};endpoints={};continuity={};counter={};rejections={};allP={};
try
 pins=config.code_pins;if iscell(pins),pins=[pins{:}];end
 for i=1:numel(pins),verify(pins(i));end
 assert(isfield(config,'protocol_pin')&&isfield(config,'code_manifest_pin'),'A31NL:ControlPins','Protocol/code manifest pins required.');verify(config.protocol_pin);verify(config.code_manifest_pin);
 protocol=jsondecode(fileread(config.protocol_pin.path));assert(strcmp(protocol.schema,'A31_MATCHED_NL_OH8_NR_PROTOCOL_V2'),'A31NL:ControlProtocol','P2 mathematics required.');
 [bundle,splits]=a31nr_fixture_v1();data=a31nr_data_v1(bundle,splits(1));families={'NL4','OH8'};alphas=[0 .25 .5 .75 1];
 % Detached target derivatives use fixed q during every central difference.
 for fi=1:2
  family=families{fi};D=4;if fi==2,D=8;end;init=a29cl_math('init',D,911);Z=[-.7 .2;.3 .4;.5 -.8];
  masks={[1 3],[1 2 3 4]};
  for mi=1:2
   mask=masks{mi};y=[mask(1);mask(end);mask(1)];cur=small_current(Z,y,mask);
   for alpha=alphas
    q=a31nl_targets_v1(init.theta,cur,family,alpha);
    [loss,g]=data_gradient(init.theta,Z,q.q,mask,D);
    fd=zeros(size(g));step=1e-6;
    for k=1:numel(g)
     tp=init.theta;tm=tp;tp(k)=tp(k)+step;tm(k)=tm(k)-step;
     lp=data_gradient(tp,Z,q.q,mask,D);lm=data_gradient(tm,Z,q.q,mask,D);fd(k)=(lp-lm)/(2*step);
    end
    err=max(abs(fd-g));check(sprintf('DETACHED_GRAD_%s_M%d_A%.2f',family,mi,alpha),err<2e-6);
    check(sprintf('TARGET_MIX_%s_M%d_A%.2f',family,mi,alpha),isequal(q.q,(1-alpha)*q.hard_targets+alpha*prob_or_hard(q)));
    check(sprintf('ZERO_ALPHA_NO_TEACHER_%s_M%d_A%.2f',family,mi,alpha),alpha>0||(isempty(q.teacher)&&q.teacher_forward_rows==0));
    gradientCases{end+1,1}=struct('family',family,'D',D,'mask',mask,'alpha',alpha,'theta',init.theta,'incoming_state',init,'Z',Z,'y',y,'q',q, ...
     'spec',gradient_spec(Z,q.q,mask,D),'gradient_includes_L2',false, ...
     'loss',loss,'gradient',g,'finite_difference',fd,'max_error',err); %#ok<AGROW>
   end
  end
 end
 % Independent old-style hard-target pipelines establish NR0 parity.
 for fi=1:2
  for stream={'TaskIL','ClassIL'}
   for use=[false true]
    job=toy_job(families{fi},stream{1},use,[0 0 0]);old=reference_legacy(data,job,3);
    cache=a31nl_cache_v1('new');[new,~]=a31nl_trajectory_v1(data,job,3,true,cache);
    L=cells(old.logical_stages);F=cells(old.unique_fits);S=cells(new.stages);
    check(['NR0_INITIAL_' job.job_id],isequaln(new.initial_state,typed(old.initial_states{1}.state)));
    for s=1:3
     r=F{L{s}.job_id};check(sprintf('NR0_FULL_STATE_%s_S%d',job.job_id,s),isequaln(new.stages{s}.final_state,typed(r.final_state)));
     check(sprintf('NR0_SPEC_%s_S%d',job.job_id,s),isequaln(S{s}.spec,r.spec));
     for name={'first','last'}
      a=S{s}.stage_receipt.(name{1});b=r.receipt.(name{1});check(sprintf('NR0_CHECKPOINT_%s_S%d_%s',job.job_id,s,name{1}),isequaln(a,b));
     end
    end
    for k=1:numel(new.predictions)
     a=new.predictions{k};b=old.predictions{k};check(sprintf('NR0_DECISION_%s_%d',job.job_id,k),isequaln(a.label,b.label)&&isequaln(a.gap,b.gap)&&isequaln(a.outputs,b.outputs)&&isequaln(a.logits,b.logits)&&isequaln(a.scores,b.scores)&&isequaln(a.distances,b.distances));
    end
    cache=a31nl_cache_v1('new');[cache,imp]=a31nl_cache_v1('import',cache,old.unique_fits,'ARTIFICIAL_REFERENCE_NOT_A_SOURCE_FILE');
    entry=toy_entry(job,old);[copied,after]=a31nl_reuse_static_v1(data,job,old,entry.source_result_pin,entry,cache,3,true);
    check(['FULL_COPY_ZERO_WORK_' job.job_id],copied.actual_new_stagefits==0&&copied.new_teacher_forward_rows==0&&copied.new_source_prediction_rows==0&&isempty(after.new_indices));
    for s=1:3,check(sprintf('FULL_COPY_STATE_%s_S%d',job.job_id,s),isequaln(copied.stages{s}.final_state,new.stages{s}.final_state));end
    for k=1:numel(copied.predictions),check(sprintf('FULL_COPY_DECISION_%s_%d',job.job_id,k),isequaln(copied.predictions{k}.outputs,new.predictions{k}.outputs)&&isequaln(copied.predictions{k}.scores,new.predictions{k}.scores));end
    a31nl_output_v1('guard_trajectory',new);a31nl_output_v1('guard_trajectory',copied);
    parityCases{end+1,1}=struct('job',job,'reference_legacy',old,'new_trajectory',new,'full_copy',copied,'cache_import_receipt',imp); %#ok<AGROW>
    allP=[allP;new.predictions]; %#ok<AGROW>
   end
  end
 end
 for fi=1:2
  family=families{fi};D=4;if fi==2,D=8;end;init=a29cl_math('init',D,177);cur=data.current('ClassIL',1);
  q=a31nl_targets_v1(init.theta,cur,family,1);[loss,g]=data_gradient(init.theta,cur.Z,q.q,cur.eligible,D);
  spec=a31nl_terms_v1(cur,[],q,family,3,true);[fullLoss,fullg,components]=a29cl_math('objective',init.theta,spec.terms,D,spec.anchors,0);
  check(['NR1_CURRENT_GRAD_' family],max(abs(g))<1e-12);check(['NR1_ENTROPY_LOSS_' family],loss>0);
  check(['NR1_L2_ACTIVE_' family],norm(fullg)>1e-12&&components.L2>0);
  momentum=init;momentum.m(:)=.01;momentum.v(:)=.001;momentum.t=uint64(7);moved=a29cl_math('step',momentum,fullg);
  check(['NR1_MOMENTUM_ACTIVE_' family],moved.t==8&&norm(moved.theta-init.theta)>0);
  prior=data.current('ClassIL',1);post=a29cl_data('replay_commit',a29cl_data('replay_empty'),prior,1,1);nextcur=data.current('ClassIL',2);memory=a29cl_data('replay_view',post.buffer,nextcur);
  q2=a31nl_targets_v1(init.theta,nextcur,family,.5);sp2=a31nl_terms_v1(nextcur,memory,q2,family,3,true);
  [obj,og]=a29cl_math('objective',init.theta,sp2.terms,D,sp2.anchors,0);ofd=zeros(size(og));
  for k=1:numel(og)
   tp=init.theta;tm=tp;tp(k)=tp(k)+1e-6;tm(k)=tm(k)-1e-6;
   lp=a29cl_math('objective',tp,sp2.terms,D,sp2.anchors,0);lm=a29cl_math('objective',tm,sp2.terms,D,sp2.anchors,0);ofd(k)=(lp-lm)/2e-6;
  end
  check(['FULL_OBJECTIVE_REPLAY_L2_GRAD_' family],max(abs(ofd-og))<2e-6);
  objectiveCases{end+1,1}=struct('family',family,'D',D,'theta',init.theta,'current',nextcur,'memory',memory,'target',q2,'spec',sp2,'loss',obj,'gradient',og,'finite_difference',ofd); %#ok<AGROW>
  self=a31nl_targets_v1(init.theta,nextcur,family,1);selfSpec=a31nl_terms_v1(nextcur,memory,self,family,3,true);replayG=zeros(size(g));
  for k=2:numel(selfSpec.terms)
   t=selfSpec.terms(k);if D==4,[~,rg]=a29cl_math('ce',init.theta,t.Z,t.target,t.mask,D);else,[~,rg]=a29cl_math('bce',init.theta,t.Z,t.target,D);end
   replayG=replayG+t.weight*rg;
  end
  [~,selfFullG]=a29cl_math('objective',init.theta,selfSpec.terms,D,selfSpec.anchors,0);check(['NR1_HARD_REPLAY_ACTIVE_' family],norm(replayG)>1e-10);
  endpoints{end+1,1}=struct('family',family,'D',D,'incoming_state',init,'target_cache',q,'current_gradient',g,'full_gradient',fullg,'loss',loss,'full_loss',fullLoss,'components',components,'momentum_state',momentum,'step_with_carried_momentum',moved,'momentum_step',struct('before',momentum,'gradient',fullg,'after',moved),'self_with_replay_target',self,'self_with_replay_spec',selfSpec,'replay_only_gradient',replayG,'self_with_replay_gradient',selfFullG); %#ok<AGROW>
  job=toy_job(family,'ClassIL',true,[.25 .5 1]);[r,~]=a31nl_trajectory_v1(data,job,600,true,a31nl_cache_v1('new'));
  for s=1:3
   st=r.stages{s};check(sprintf('CONTINUOUS_T_%s_S%d',family,s),double(st.incoming_state.t)==600*(s-1)&&double(st.final_state.t)==600*s);
   check(sprintf('FIXED_TEACHER_%s_S%d',family,s),isequaln(st.target_cache.teacher,st.incoming_state.theta)&&isequaln(st.spec.terms(1).target,st.target_cache.q)&&isequaln(st.stage_receipt.terms,st.spec.terms));
   for k=1:numel(r.predictions),p=r.predictions{k};if p.stage==s,check(sprintf('CLASSIL_NO_TASK_ID_%s_S%d_Q%d',family,s,k),p.task==0&&isequal(p.eligible,1:s+1));end,end
  end
  continuity{end+1,1}=r; %#ok<AGROW>
  job=toy_job(family,'ClassIL',true,[.25 .5 .75]);[base,~]=a31nl_trajectory_v1(data,job,3,true,a31nl_cache_v1('new'));
  [hb,hs]=a31nr_fixture_v1(struct('heldout_shift',91));[fb,fs]=a31nr_fixture_v1(struct('future_shift',113));
  hd=a31nr_data_v1(hb,hs(1));fd=a31nr_data_v1(fb,fs(1));
  [held,~]=a31nl_trajectory_v1(hd,job,3,true,a31nl_cache_v1('new'));[future,~]=a31nl_trajectory_v1(fd,job,3,true,a31nl_cache_v1('new'));
  for s=1:3
   check(sprintf('EVAL_ISOLATED_%s_S%d',family,s),isequaln(base.stages{s}.final_state,held.stages{s}.final_state)&&isequaln(base.stages{s}.target_cache,held.stages{s}.target_cache));
   if s<3,check(sprintf('FUTURE_ISOLATED_%s_S%d',family,s),isequaln(base.stages{s}.final_state,future.stages{s}.final_state)&&isequaln(base.stages{s}.target_cache,future.stages{s}.target_cache));end
  end
  check(['HELD_QUERY_ACTUALLY_CHANGED_' family],~isequaln(base.predictions{1}.Z,held.predictions{1}.Z));
  counter{end+1,1}=struct('family',family,'base',base,'heldout',held,'future',future,'heldout_fixture_bundle',hb,'heldout_fixture_split',hs(1),'future_fixture_bundle',fb,'future_fixture_split',fs(1)); %#ok<AGROW>
 end
 % A prospective job key binds identities, masks, detached target and all Adam state.
 a=parityCases{1}.reference_legacy.unique_fits{1};baseKey=a.job_sha256;
 for kind={'parent','mask','target','theta','moment','counter','width'}
  b=a;
  switch kind{1}
   case 'parent',b.current_parentindex(1)=uint64(999);
   case 'mask',b.spec.terms(1).mask=[1 3];
   case 'target',b.spec.terms(1).target(1)=2;
   case 'theta',b.incoming_state.theta(1)=b.incoming_state.theta(1)+.01;
   case 'moment',b.incoming_state.m(1)=b.incoming_state.m(1)+.01;
   case 'counter',b.incoming_state.t=b.incoming_state.t+uint64(1);
   case 'width',b.spec.D=8;
  end
  changed=a31nl_cache_v1('key',b.fold,b.seed,b.current_parentindex,b.memory_parentindex,b.incoming_state,b.spec);
  check(['CACHE_NO_APPROXIMATE_ALIAS_' kind{1}],~strcmp(baseKey,changed));aliasCases{end+1,1}=struct('kind',kind{1},'original_record',a,'changed_record',b,'original_key',baseKey,'changed_key',changed); %#ok<AGROW>
 end
 init=a29cl_math('init',4,101);cur=data.current('TaskIL',1);
 reject('ALPHA_NAN',@()a31nl_targets_v1(init.theta,cur,'NL4',NaN),'A31NL:Alpha');
 reject('ALPHA_ABOVE1',@()a31nl_targets_v1(init.theta,cur,'NL4',1.01),'A31NL:Alpha');
 reject('ALPHA_BELOW0',@()a31nl_targets_v1(init.theta,cur,'NL4',-.01),'A31NL:Alpha');
 reject('BAD_FAMILY',@()a31nl_targets_v1(init.theta,cur,'WH8',.5),'A31NL:Family');
 bad=cur;bad.kind='EVALUATION_ONLY';reject('EVALUATOR_INPUT',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:Current');
 bad=cur;bad.parentindex=[bad.parentindex;bad.parentindex(1)];reject('EXTRA_PARENT_ID',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:ParentIDs');
 bad=cur;bad.parentindex(2)=bad.parentindex(1);reject('DUP_PARENT_ID',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:ParentIDs');
 bad=cur;bad.parentrow=bad.parentrow(1:end-1);reject('MISSING_PARENTROW',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:ParentRows');
 bad=cur;bad.parentrow{1}='';reject('EMPTY_PARENTROW',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:ParentRows');
 bad=cur;bad.Z(1)=NaN;reject('NONFINITE_CURRENT',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:Rows');
 bad=cur;bad.eligible=[2 1];reject('UNSORTED_MASK',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:Mask');
 bad=cur;bad.eligible=[1 1];reject('DUPLICATE_MASK',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:Mask');
 bad=cur;bad.y(1)=4;reject('LABEL_OUTSIDE_MASK',@()a31nl_targets_v1(init.theta,bad,'NL4',.5),'A31NL:Mask');
 bad=bundle;bad.outer_normalizers(1).sd(1)=0;reject('ZERO_SD',@()a31nr_data_v1(bad,splits(1)),'A31NR:OuterScaler');
 % Same JSON adapter shapes and missing masks as saved scientific outputs.
 roundtrips={};
 for fi=1:2
  r=continuity{fi};decoded=jsondecode(jsonencode(r,'ConvertInfAndNaN',true));
  check(sprintf('JSON_STATE_FAMILY%d',fi),isequaln(typed(decoded.initial_state),r.initial_state)&&isequaln(typed(decoded.stages(3).final_state),r.stages{3}.final_state));
  roundtrips{end+1,1}=struct('family',r.family,'initial_state',decoded.initial_state,'final_state',decoded.stages(3).final_state); %#ok<AGROW>
 end
 csv=fullfile(outDir,'nl_controls_predictions_v1.csv');a31nl_output_v1('writecsv',csv,allP);
 test=struct('ascii','quote" and slash\','unicode','Türkçe İstanbul Ω','values',[NaN realmax realmin -realmax],'logical',[true false]);
 upper=a31nl_output_v1('bound',test);actual=numel(unicode2native(jsonencode(test,'ConvertInfAndNaN',true),'UTF-8'));check('STRUCTURAL_UTF8_BOUND',actual<=upper);
 E=struct('schema','A31_NL_SOURCE_FREE_CONTROLS_EVIDENCE_V1','kind','ARTIFICIAL_FIXTURE_ONLY_NOT_SCIENTIFIC_RESULT', ...
  'fixture_bundle',bundle,'fixture_split',splits(1),'gradient_cases',{gradientCases},'full_objective_cases',{objectiveCases},'alias_key_cases',{aliasCases},'parity_cases',{parityCases},'endpoint_cases',{endpoints},'continuity_runs',{continuity}, ...
  'counterfactual_cases',{counter},'input_rejections',{rejections},'serializer',struct('predictions_csv_path',csv,'roundtrip_states',{roundtrips},'unicode_fixture',test,'structural_upper_bytes',upper,'encoded_bytes',actual),'checks',{checks});
 a31nl_output_v1('writejson',fullfile(outDir,'nl_controls_evidence_v1.json'),E,20000000);
 receipt=struct('schema','A31_NL_SOURCE_FREE_CONTROLS_RECEIPT_V1','status','PASS_SOURCE_FREE_NL_CONTROLS','complete',true, ...
  'checks',numel(checks),'failed_checks',0,'source_rows_read',0,'source_training',0,'source_predictions',0, ...
  'artificial_optimizer_updates',3800,'artificial_stage_optimizer_updates',3798,'standalone_optimizer_step_checks',2,'artificial_600_update_trajectories',2,'artificial_3_update_parity_pairs',8, ...
  'elapsed_seconds',toc(clock),'evidence_pin',pin(fullfile(outDir,'nl_controls_evidence_v1.json')),'csv_pin',pin(csv),'code_pins',pins);
 a31nl_output_v1('writejson',fullfile(outDir,'nl_controls_receipt_v1.json'),receipt,1000000);
 for i=1:numel(pins),verify(pins(i));end
 d=dir(outDir);assert(sum([d(~[d.isdir]).bytes])<=30000000,'A31NL:ControlCap','Artificial output cap exceeded.');
catch err
 failure=struct('schema','A31_NL_FAILED_CONTROLS_RECEIPT_V1','status','FAILED_ARTIFICIAL_ATTEMPT_PRESERVED','complete',false,'identifier',err.identifier,'message',err.message,'stack',err.stack,'checks',{checks},'source_rows_read',0,'source_training',0,'source_predictions',0);
 a31nl_output_v1('writejson',fullfile(outDir,'nl_controls_FAILED_receipt_v1.json'),failure,1000000);rethrow(err);
end
 function check(id,ok)
  checks{end+1,1}=struct('id',id,'passed',isequal(ok,true));assert(isequal(ok,true),'A31NL:ControlFailure','Artificial control failed: %s',id);
 end
 function reject(id,fn,expected)
  actual='NO_ERROR';try,fn();catch e,actual=e.identifier;end
  rejections{end+1,1}=struct('id',id,'expected_identifier',expected,'actual_identifier',actual);check(id,strcmp(actual,expected));
 end
end
function s=gradient_spec(Z,q,mask,D)
kind='softce';if D==8,kind='bce';mask=[];end
t=struct('kind',kind,'Z',Z,'target',q,'mask',mask,'T',1,'weight',1);
s=struct('D',D,'terms',t,'anchors',struct('theta',{},'F',{}),'ewc_lambda',0,'updates',3,'control_only',true);
end
function q=prob_or_hard(t),if t.alpha==0,q=t.hard_targets;else,q=t.teacher_probabilities;end,end
function [loss,g]=data_gradient(theta,Z,q,mask,D)
if D==4,[loss,g]=a29cl_math('softce',theta,Z,q,mask,1,D);else,[loss,g]=a29cl_math('bce',theta,Z,q,D);end
end
function c=small_current(Z,y,mask)
c=struct('Z',Z,'y',y,'eligible',mask,'parentindex',uint64((1:numel(y))'),'parentrow',{{'ART_1';'ART_2';'ART_3'}},'kind','CURRENT_TRAIN','stream','TaskIL','stage',1);
end
function j=toy_job(family,stream,replay,alpha)
D=4;if strcmp(family,'OH8'),D=8;end
j=struct('job_id',sprintf('ART_%s_%s_R%d',family,stream,replay),'phase','matched_nl_oh8_response','family',family,'D',D,'outer_fold',1,'seed',101,'replay',logical(replay),'stream',stream,'schedule_id','ARTIFICIAL','alpha',alpha,'split_id','ART_O01_outer_I00','inner_design','outer','inner_fold',0,'stages',3,'updates_per_stage',600);
end
function old=reference_legacy(data,j,u)
% Independent transcription of original hard CE/BCE term construction only.
D=j.D;state=a29cl_math('init',D,j.seed);old=struct('codebooks',struct('OH8',[eye(4),zeros(4,4)]),'initial_states',{{struct('fold',1,'seed',j.seed,'D',D,'state',state)}},'unique_fits',{{}},'logical_stages',{{}},'predictions',{{}});B=a29cl_data('replay_empty');
arm='MLP_NAIVE';if D==4&&j.replay,arm='MLP_ER';elseif D==8,arm='OH8_STATIC_NOREPLAY';if j.replay,arm='OH8_STATIC_REPLAY';end,end
for s=1:3
 cur=data.current(j.stream,s);view=a29cl_data('replay_view',B,cur);incoming=state;
 if D==4,terms=term('ce',cur.Z,cur.y,cur.eligible,1);else,C=[eye(4),zeros(4,4)];terms=term('bce',cur.Z,C(cur.y,:),[],1);end
 if j.replay&&~isempty(view.y)
  terms.weight=.5;
  if D==8,terms(2)=term('bce',view.Z,C(view.y,:),[],.5);
  elseif strcmp(j.stream,'TaskIL')
   for task=reshape(unique(double(view.firsttask)),1,[]),idx=double(view.firsttask)==task;terms(end+1)=term('ce',view.Z(idx,:),view.y(idx),[1 task+1],.5*sum(idx)/numel(view.y));end %#ok<AGROW>
  else,terms(2)=term('ce',view.Z,view.y,1:s+1,.5);end
 end
 spec=struct('D',D,'terms',terms,'anchors',struct('theta',{},'F',{}),'ewc_lambda',0,'updates',u,'control_only',true);
 [state,receipt]=a29cl_stage(incoming,spec);mm=zeros(0,1,'uint64');if j.replay,mm=view.parentindex;end
 key=a29cl_data('hash',jsonencode(struct('fold',1,'seed',j.seed,'current_parentindex',cur.parentindex,'memory_parentindex',mm,'incoming',incoming,'spec',spec)));
 old.unique_fits{end+1}=struct('job_id',s,'fold',1,'seed',j.seed,'D',D,'job_sha256',key,'current_parentindex',cur.parentindex,'memory_parentindex',mm,'incoming_state',incoming,'final_state',state,'spec',spec,'receipt',receipt);
 before=B;if j.replay,post=a29cl_data('replay_commit',B,cur,1,s);B=post.buffer;end
 old.logical_stages{end+1}=struct('id',s,'fold',1,'seed',j.seed,'arm',arm,'stream',j.stream,'stage',s,'job_id',s,'current_parentindex',cur.parentindex,'teacher',[],'qcache',{{}},'replay_before',before,'replay_after',B,'effective_replay',view);
 query=data.query(j.stream,s);tasks=0;if strcmp(j.stream,'TaskIL'),tasks=1:s;end
 for task=tasks
  rows=(1:numel(query.y))';eligible=1:s+1;if task>0,rows=find(query.task==task);eligible=[1 task+1];end;C=[];if D==8,C=[eye(4),zeros(4,4)];end
  decoded=a29cl_math('decode',state.theta,query.Z(rows,:),D,eligible,C);
  for k=1:numel(rows)
   i=rows(k);old.predictions{end+1,1}=struct('fold',1,'seed',j.seed,'arm',arm,'stream',j.stream,'stage',s,'task',task,'job_id',s,'parentindex',query.parentindex(i),'parentrow',query.parentrow{i},'truth',query.y(i),'eligible',eligible,'Z',query.Z(i,:),'label',decoded.label(k),'gap',decoded.gap(k),'tie',decoded.tie(k),'valid',decoded.valid(k),'failure',decoded.failure(k),'failure_reason',decoded.failure_reason{k},'scores',decoded.scores(k,:),'distances',decoded.distances(k,:),'outputs',decoded.outputs(k,:),'logits',decoded.logits(k,:));
  end
 end
end
end
function t=term(kind,Z,target,mask,weight),t=struct('kind',kind,'Z',Z,'target',target,'mask',mask,'T',1,'weight',double(weight));end
function e=toy_entry(j,old)
e=struct('job_id',j.job_id,'D',j.D,'source_arm',old.logical_stages{1}.arm,'source_result_pin',struct('path','ARTIFICIAL_REFERENCE_NO_FILE','bytes',0,'sha256',repmat('0',1,64)),'source_initial_position',1,'source_logical_positions',[1 2 3],'source_fit_SHA256',{{old.unique_fits{1}.job_sha256,old.unique_fits{2}.job_sha256,old.unique_fits{3}.job_sha256}},'source_prediction_positions',(1:numel(old.predictions))');
end
function s=typed(s),s=struct('theta',double(s.theta(:)),'m',double(s.m(:)),'v',double(s.v(:)),'t',uint64(s.t));end
function c=cells(x),if iscell(x),c=x;elseif isempty(x),c={};else,c=num2cell(x);end,end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function p=pin(p),d=dir(p);p=struct('path',p,'bytes',d.bytes,'sha256',sha(p));end
function verify(p),d=dir(p.path);assert(isscalar(d)&&d.bytes==p.bytes&&strcmp(sha(p.path),p.sha256),'A31NL:ControlPin','Pinned code/protocol changed.');end
function h=sha(p),f=fopen(p,'rb');assert(f>=0,'A31NL:Read','Cannot read pin.');c=onCleanup(@()fclose(f));b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));end %#ok<NASGU>
