function [R,cache]=a31nl_reuse_static_v1(data,job,old,originPin,entry,cache,updates,control_only)
% Transfer one complete accepted alpha0 CE32/OH8 trajectory. No model forward.
assert(isequal(double(job.alpha(:)'),[0 0 0])&&strcmp(job.inner_design,'outer'),'A31NL:ReuseScope','Only exact STATIC outer trajectories may transfer.');
assert((~control_only&&updates==600)||(control_only&&updates==3),'A31NL:ReuseBudget','Separate production600 or artificial3 provenance required.');
family=char(job.family);D=double(job.D);assert((strcmp(family,'NL4')&&D==4)||(strcmp(family,'OH8')&&D==8),'A31NL:Family','Invalid family/width.');
if D==4,arm='MLP_NAIVE';if job.replay,arm='MLP_ER';end
else,arm='OH8_STATIC_NOREPLAY';if job.replay,arm='OH8_STATIC_REPLAY';end;assert(isequal(double(old.codebooks.OH8),[eye(4),zeros(4,4)]),'A31NL:Codebook','Historical OH8 differs.');end
assert(strcmp(entry.job_id,job.job_id)&&strcmp(entry.source_arm,arm)&&entry.D==D&& ...
 strcmp(entry.source_result_pin.sha256,originPin.sha256),'A31NL:ReuseCatalog','Full transfer is not the pinned catalog tuple.');
L=cells(old.logical_stages);fits=cells(old.unique_fits);preds=cells(old.predictions);initials=cells(old.initial_states);
ii=entry.source_initial_position;assert(ii>=1&&ii<=numel(initials),'A31NL:ReuseInitial','Invalid initial position.');init=initials{ii};
assert(init.fold==job.outer_fold&&init.seed==job.seed&&init.D==D,'A31NL:ReuseInitial','Historical initializer tuple differs.');
state=typed(init.state,D);initial=state;B=a29cl_data('replay_empty');stages=cell(3,1);P={};metrics=cell(3,1);clock=tic;beforeCount=numel(cache.new_indices);
for s=1:3
 ix=entry.source_logical_positions(s);assert(ix>=1&&ix<=numel(L),'A31NL:ReuseStage','Missing historical logical stage.');ls=L{ix};
 assert(ls.fold==job.outer_fold&&ls.seed==job.seed&&strcmp(ls.arm,arm)&&strcmp(ls.stream,job.stream)&&ls.stage==s,'A31NL:ReuseStage','Historical stage tuple differs.');
 fit=fits{ls.job_id};cur=data.current(char(job.stream),s);view=a29cl_data('replay_view',B,cur);memory=[];if job.replay,memory=view;end
 incoming=state;q=a31nl_targets_v1(incoming.theta,cur,family,0);spec=a31nl_terms_v1(cur,memory,q,family,updates,control_only);
 assert(isequal(uint64(ls.current_parentindex(:)),cur.parentindex)&&isempty(ls.teacher),'A31NL:ReuseCurrent','Static historical current/teacher differs.');
 mm=zeros(0,1,'uint64');if job.replay,mm=view.parentindex;end
 key=a31nl_cache_v1('key',double(job.outer_fold),double(job.seed),cur.parentindex,mm,incoming,spec);
 assert(strcmp(key,fit.job_sha256)&&strcmp(key,entry.source_fit_SHA256{s})&&isKey(cache.map,key),'A31NL:ReuseExact','Historical exact key unavailable. Fallback retraining is forbidden.');
 [state,receipt,cache,ref]=a31nl_cache_v1('resolve',cache,double(job.outer_fold),double(job.seed),cur,memory,incoming,spec,char(job.job_id));
 assert(ref.aliased&&isequaln(state,typed(fit.final_state,D)),'A31NL:ReuseState','Historical final state differs.');
 before=B;admission=[];if job.replay,post=a29cl_data('replay_commit',B,cur,double(job.outer_fold),s);B=post.buffer;admission=post.receipt;end
 assert(eqn(ls.replay_before,before)&&eqn(ls.replay_after,B)&&eqn(ls.effective_replay,view),'A31NL:ReuseReplay','Historical raw/effective memory differs.');
 q.scope='REUSED_ACCEPTED_CURRENT_TRAIN_CACHE';
 stages{s}=struct('stage',s,'alpha',0,'current_parentindex',cur.parentindex,'current_parentrow',{cur.parentrow}, ...
  'incoming_state',incoming,'final_state',state,'target_cache',q,'replay_before',before,'effective_replay',memory, ...
  'replay_after',B,'replay_admission',admission,'spec',spec,'stage_receipt',receipt,'fit_reference',ref, ...
  'historical_payload_reused',true,'legacy_source_pin',originPin,'legacy_logical_stage_id',ls.id);
 query=data.query(char(job.stream),s);tasks=0;if strcmp(job.stream,'TaskIL'),tasks=1:s;end;stageP={};
 for task=tasks
  rr=(1:numel(query.y))';eligible=1:s+1;if task>0,rr=find(query.task==task);eligible=[1 task+1];end
  for j=1:numel(rr)
   k=rr(j);positions=double(entry.source_prediction_positions(:));pp=positions(cellfun(@(z)z.stage==s&&z.task==task&&double(z.parentindex)==double(query.parentindex(k)),preds(positions)));
   assert(isscalar(pp),'A31NL:ReuseQuery','Historical query is missing or duplicated.');p=preds{pp};
   assert(p.fold==job.outer_fold&&p.seed==job.seed&&strcmp(p.arm,arm)&&strcmp(p.stream,job.stream)&&p.job_id==ls.job_id&& ...
    isequal(double(p.Z(:)'),query.Z(k,:))&&isequal(double(p.eligible(:)'),eligible)&&strcmp(p.parentrow,query.parentrow{k})&& ...
    p.truth==query.y(k)&&p.valid&&~p.failure,'A31NL:ReuseQuery','Historical fit/query/target/scaler identity differs.');
   loss='masked_softmax_cross_entropy';kind='not_defined_softmax';if D==8,loss='eight_bit_binary_cross_entropy';kind='mean_squared_code_distance';end
   r=struct('job_id',char(job.job_id),'phase',char(job.phase),'family',family,'D',D,'loss',loss, ...
    'split_id',char(job.split_id),'outer_fold',double(job.outer_fold),'seed',double(job.seed),'replay',logical(job.replay), ...
    'stream',char(job.stream),'schedule_id',char(job.schedule_id),'stage',s,'task',task,'parentindex',query.parentindex(k), ...
    'parentrow',query.parentrow{k},'group_order',query.group_order(k),'truth',query.y(k),'eligible',eligible,'Z',query.Z(k,:), ...
    'label',p.label,'gap',p.gap,'tie',logical(p.tie),'valid',logical(p.valid),'failure',logical(p.failure), ...
    'failure_reason',text(p.failure_reason),'scores',double(p.scores(:)'),'distances',double(p.distances(:)'), ...
    'outputs',double(p.outputs(:)'),'logits',double(p.logits(:)'),'distance_kind',kind,'fit_sha256',key, ...
    'historical_payload_reused',true,'legacy_source_sha256',originPin.sha256,'legacy_prediction_position',pp);
   P{end+1,1}=r;stageP{end+1,1}=r; %#ok<AGROW>
  end
 end
 metrics{s}=struct('stage',s,'N',numel(stageP),'correct',sum(cellfun(@(r)r.valid&&r.label==r.truth,stageP)), ...
  'failure',0,'tie',sum(cellfun(@(r)r.tie,stageP)));metrics{s}.accuracy=metrics{s}.correct/metrics{s}.N;
end
assert(numel(cache.new_indices)==beforeCount&&numel(P)==numel(entry.source_prediction_positions),'A31NL:ReuseNoWork','A full-copy trajectory cannot fit or add/remove a prediction.');
loss='masked_softmax_cross_entropy';if D==8,loss='eight_bit_binary_cross_entropy';end
R=struct('schema','A31_NL_TRAJECTORY_V1','job',job,'family',family,'D',D,'loss',loss,'normalizer',data.normalizer, ...
 'initial_state',initial,'stages',{stages},'predictions',{P},'metrics',{metrics},'elapsed_seconds',toc(clock), ...
 'source_free_control',logical(control_only),'logical_stage_instances',3,'actual_new_stagefits',0,'actual_optimizer_updates',0, ...
 'source_training_stages',0,'source_optimizer_updates',0,'new_teacher_forward_rows',0,'new_source_prediction_rows',0, ...
 'historical_prediction_rows_reused',numel(P),'historical_full_trajectory_reused',true,'physical_validation',0, ...
 'all_updates_per_stage',updates,'legacy_source_pin',originPin,'source_transfer_catalog_entry',entry, ...
 'historical_work_scope','Source stage_receipt/checkpoints are preserved evidence, never counted as new work.');
end
function c=cells(x),if iscell(x),c=x;elseif isempty(x),c={};else,c=num2cell(x);end,end
function s=typed(s,D)
s=struct('theta',double(s.theta(:)),'m',double(s.m(:)),'v',double(s.v(:)),'t',uint64(s.t));assert(numel(s.theta)==12+5*D,'A31NL:State','State width differs.');
end
function x=text(x),if isempty(x),x='';else,x=char(x);end,end
function ok=eqn(a,b)
if isempty(a)&&isempty(b),ok=true;return;end
if isstruct(a)&&isstruct(b)
 fa=sort(fieldnames(a));fb=sort(fieldnames(b));ok=isequal(fa,fb)&&numel(a)==numel(b);if ok,for j=1:numel(a),for k=1:numel(fa),ok=ok&&eqn(a(j).(fa{k}),b(j).(fa{k}));end,end,end
elseif iscell(a)||iscell(b)
 if ~iscell(a),a=num2cell(a);end;if ~iscell(b),b=num2cell(b);end;ok=numel(a)==numel(b);if ok,for j=1:numel(a),ok=ok&&eqn(a{j},b{j});end,end
elseif (isnumeric(a)||islogical(a))&&(isnumeric(b)||islogical(b)),ok=isequaln(double(a(:)),double(b(:)));
else,ok=isequaln(a,b);end
end
