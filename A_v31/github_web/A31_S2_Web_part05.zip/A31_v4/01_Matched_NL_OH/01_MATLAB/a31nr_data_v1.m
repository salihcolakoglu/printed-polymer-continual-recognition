function out=a31nr_data_v1(bundle,split)
% Frozen explicit split -> scoped current TRAIN / post-stage evaluator handles.
% No file access. Only E_MPa and Hardness_ShoreD enter model Z.
C=bundle.records;if iscell(C),C=[C{:}];end
assert(numel(C)==104&&isequal([C.index1],1:104)&& ...
 isequal([C.group_order],repelem(0:25,4))&&isequal([C.label],repmat(1:4,1,26)), ...
 'A31NR:Catalog','Exact source-order 104-parent catalog required.');
assert(numel(unique(string({C.parentrow})))==104&&numel(unique(string({C.group})))==26, ...
 'A31NR:Catalog','Parent/group identity must be unique as declared.');
X=vertcat(C.X);assert(isa(X,'double')&&isequal(size(X),[104 2])&&all(isfinite(X),'all'), ...
 'A31NR:Input','Only finite two-feature inputs accepted.');
tr=double(split.train_indices1(:));dv=double(split.dev_indices1(:));ot=double(split.outer_test_indices1(:));
assert(all(ismember([tr;dv;ot],1:104))&&numel(unique(tr))==numel(tr)&& ...
 numel(unique(dv))==numel(dv)&&isempty(intersect(tr,dv))&&isempty(intersect(tr,ot)), ...
 'A31NR:Split','Invalid split membership or TRAIN/evaluation overlap.');
assert(isequal(tr,sort(tr))&&isequal(dv,sort(dv))&&isequal(ot,sort(ot)), ...
 'A31NR:Canonical','Split row indices must be canonical ascending source order.');
f=double(split.outer_fold);assert(isscalar(f)&&ismember(f,1:5)&& ...
 all([C(tr).outer_fold]~=f)&&all([C(ot).outer_fold]==f), ...
 'A31NR:Outer','Outer held-out parent entered TRAIN.');
if ~strcmp(split.inner_design,'outer')
 assert(isempty(intersect(dv,ot))&&all([C(dv).outer_fold]~=f), ...
  'A31NR:Inner','Outer TEST entered inner DEV.');
else,assert(isequal(dv,ot),'A31NR:Outer','Outer evaluator must be exact outer TEST.');end
for rows={tr,dv,ot}
 rr=rows{1};groups=unique([C(rr).group_order]);
 for g=groups,ix=rr([C(rr).group_order]==g);assert(numel(ix)==4&&isequal([C(ix).label],1:4),'A31NR:WholeGroup','A group was split.');end
end
fit=tr([C(tr).label]<=2);assert(isequal(double(split.normalizer_fit_indices1(:)),fit), ...
 'A31NR:NormalizerMembership','Scaler must fit initial-stage TRAIN classes only.');
mu=mean(X(fit,:),1);sd=std(X(fit,:),0,1);saved=false;
if strcmp(split.inner_design,'outer')
 ns=bundle.outer_normalizers;if iscell(ns),ns=[ns{:}];end;n=ns([ns.fold]==f);
 assert(isscalar(n)&&n.n==numel(fit)&& ...
  isequal(string(n.train_row_ids(:)),string({C(fit).parentrow})'), ...
  'A31NR:OuterScaler','Accepted outer scaler identity mismatch.');
 sm=reshape(double(n.mean),1,2);ss=reshape(double(n.sd),1,2);
 assert(all(abs(mu-sm)<=1e-12*max(1,abs(sm)))&&all(abs(sd-ss)<=1e-12*max(1,abs(ss))), ...
  'A31NR:OuterScaler','Accepted scaler values mismatch.');mu=sm;sd=ss;saved=true;
end
assert(all(isfinite(mu))&&all(isfinite(sd))&&all(sd>0),'A31NR:ScalerSTOP','No invalid/zero-SD replacement.');
normalizer=struct('mean',mu,'sd',sd,'n',numel(fit), ...
 'train_parentindex',uint64(fit),'train_row_ids',{{C(fit).parentrow}}, ...
 'saved_outer_values_used',saved,'split_id',char(split.split_id));
catalog=rmfield(C,'X');out=struct('catalog',catalog,'normalizer',normalizer, ...
 'split',split,'current',@current,'query',@query);
 function b=current(stream,s)
  check(stream,s);labs=s+1;if s==1,labs=[1 2];elseif strcmp(stream,'TaskIL'),labs=[1 s+1];end
  rows=tr(ismember([C(tr).label],labs));b=batch(rows);b.current_labels=labs; ...
   b.stage=s;b.stream=char(stream);b.eligible=1:s+1;
  if strcmp(stream,'TaskIL'),b.eligible=[1 s+1];end
  b.kind='CURRENT_TRAIN';
 end
 function b=query(stream,s)
  check(stream,s);rows=[];tasks=[];
  if strcmp(stream,'TaskIL')
   for task=1:s,rr=dv(ismember([C(dv).label],[1 task+1]));rows=[rows;rr];tasks=[tasks;repmat(task,numel(rr),1)];end %#ok<AGROW>
  else,rows=dv([C(dv).label]<=s+1);tasks=zeros(numel(rows),1);end
  b=batch(rows);b.task=tasks;b.stage=s;b.stream=char(stream);b.kind='EVALUATION_ONLY';
 end
 function b=batch(rows)
  rows=rows(:);b=struct('Z',(X(rows,:)-mu)./sd,'y',[C(rows).label]', ...
   'parentindex',uint64(rows),'parentrow',{{C(rows).parentrow}}, ...
   'group_order',[C(rows).group_order]','outer_fold',[C(rows).outer_fold]');
 end
end
function check(stream,s)
assert(ismember(s,1:3)&&isscalar(s)&&any(strcmp(stream,{'TaskIL','ClassIL'})), ...
 'A31NR:StreamStage','Invalid arrival/evaluation stream or stage.');
end
