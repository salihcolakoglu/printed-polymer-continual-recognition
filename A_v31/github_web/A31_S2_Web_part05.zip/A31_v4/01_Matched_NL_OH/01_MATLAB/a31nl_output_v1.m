function varargout=a31nl_output_v1(action,varargin)
% Finite native-width payload validation and lossless JSON / padded CSV output.
switch char(action)
 case 'bound',varargout{1}=bound(varargin{1});
 case 'guard_trajectory',varargout{1}=guard_trajectory(varargin{:});
 case 'guard_cache_record',r=varargin{1};assert(r.D==r.spec.D&&numel(r.current_parentindex)<=42&&numel(r.memory_parentindex)<=8,'A31NL:Structure','Cache record population exceeds protocol.');n=bound(r);assert(n<=950000,'A31NL:RecordByteCap','Cache structural byte cap failed before encoding.');varargout{1}=n;
 case 'writejson',writejson(varargin{:});
 case 'writecsv',writecsv(varargin{:});
 otherwise,error('A31NL:OutputAction','Unknown output action.');
end
end
function b=guard_trajectory(r)
D=r.D;assert(any(D==[4 8])&&numel(r.stages)==3&&numel(r.predictions)<=72,'A31NL:Structure','Trajectory dimension/stage/prediction bound exceeded.');
assert(numel(r.job.job_id)<=128&&~isempty(regexp(r.job.job_id,'^[A-Za-z0-9_]+$','once')),'A31NL:Identifier','Bounded ASCII job ID required.');
S=cells(r.stages);P=cells(r.predictions);state(r.initial_state,D);
for i=1:3
 s=S{i};state(s.incoming_state,D);state(s.final_state,D);
 assert(numel(s.current_parentindex)<=42&&numel(s.spec.terms)<=3,'A31NL:Structure','TRAIN rows or objective term count exceeds protocol.');
 if ~isempty(s.effective_replay),assert(numel(s.effective_replay.y)<=8,'A31NL:Structure','Replay row cap exceeded.');end
 assert(all(strlength(string(s.current_parentrow))<=128),'A31NL:Identifier','Parent-row identifier exceeds128characters.');
 q=s.target_cache;assert(q.D==D&&size(q.q,1)==numel(s.current_parentindex)&&size(q.q,2)<=8&&all(isfinite(q.q),'all'),'A31NL:Structure','Invalid bounded target cache.');
 if ~isempty(q.teacher),assert(numel(q.teacher)==12+5*D&&all(isfinite(q.teacher))&&all(isfinite(q.teacher_logits),'all')&&all(isfinite(q.teacher_probabilities),'all'),'A31NL:Structure','Invalid teacher cache.');end
 for name={'first','last'},k=s.stage_receipt.(name{1});state(k.pre_state,D);assert(all(isfinite(k.gradient))&&numel(k.gradient)==12+5*D&&isfinite(k.loss),'A31NL:Structure','Invalid first/last update evidence.');end
end
for i=1:numel(P)
 p=P{i};eligible=double(p.eligible(:)');assert(numel(eligible)>=2&&numel(eligible)<=4&&isequal(eligible,sort(unique(eligible)))&&all(ismember(eligible,1:4))&&numel(p.outputs)==D&&numel(p.logits)==D&&numel(p.Z)==2&&numel(p.scores)==numel(eligible)&&numel(p.distances)==numel(eligible),'A31NL:PredictionShape','Invalid native-width prediction shape.');
 assert(numel(p.parentrow)<=128&&numel(p.failure_reason)<=256,'A31NL:Identifier','Prediction text bound exceeded.');
 if p.valid&&~p.failure
  assert(all(isfinite(p.logits))&&all(isfinite(p.scores))&&isfinite(p.label)&&isfinite(p.gap),'A31NL:PredictionValues','Valid decision has missing logits/scores/label/gap.');
  if D==4
   missing=~ismember(1:4,eligible);assert(all(isfinite(p.outputs(eligible)))&&all(isnan(p.outputs(missing)))&&all(isnan(p.distances))&&strcmp(p.distance_kind,'not_defined_softmax'),'A31NL:ExpectedMissing','NL4 outputs outside mask and all distances must remain undefined.');
  else,assert(all(isfinite(p.outputs))&&all(isfinite(p.distances))&&strcmp(p.distance_kind,'mean_squared_code_distance'),'A31NL:PredictionValues','OH8 output or distance is missing.');end
 else,assert(p.failure,'A31NL:PredictionStatus','Invalid row must explicitly report failure.');end
end
b=bound(r);assert(b<=1200000,'A31NL:RecordByteCap','Trajectory structural byte cap failed before encoding.');
end
function state(s,D)
P=12+5*D;assert(numel(s.theta)==P&&numel(s.m)==P&&numel(s.v)==P&&all(isfinite([s.theta(:);s.m(:);s.v(:)]))&&all(s.v>=0)&&isscalar(s.t)&&double(s.t)<=1800,'A31NL:Structure','State width/finite/budget cap failed.');
end
function b=encoded(r,cap)
n=bound(r);assert(n<=cap,'A31NL:StructuralByteCap','Structural bound exceeds cap before jsonencode.');
b=unicode2native(jsonencode(r,'ConvertInfAndNaN',true),'UTF-8');assert(numel(b)<=n&&numel(b)<=cap,'A31NL:RecordByteCap','Encoded bytes exceeded independent structural bound.');
end
function n=bound(v)
% No jsonencode. IEEE binary64/uint64 leaves use26ASCIIbytes maximum.
% Every UTF16 code unit needs at most6JSON bytes (including escape forms).
% Brackets, commas, field names and colons are counted recursively.
if ischar(v),assert(isrow(v)||isempty(v),'A31NL:TextShape','Only character rows are serialized.');n=2+6*numel(v);return;end
if isstring(v),if isscalar(v),n=bound(char(v));else,n=bound(cellstr(v));end;return;end
if isnumeric(v)||islogical(v)
 assert(isreal(v)&&ndims(v)<=2,'A31NL:NumberDomain','Real scalar/vector/matrix required.');N=numel(v);if N==0,n=2;return;end
 width=26;if islogical(v),width=5;end
 if isscalar(v),n=width;elseif isvector(v),n=2+width*N+(N-1);else,r=size(v,1);n=2+2*r+width*N+(N-r)+(r-1);end;return
end
if iscell(v)
 assert(isvector(v)||isempty(v),'A31NL:CellShape','Only cell vectors are serialized.');n=2+max(0,numel(v)-1);for j=1:numel(v),n=n+bound(v{j});end;return
end
if isstruct(v)
 if isempty(v),n=2;return;end;assert(isvector(v),'A31NL:StructShape','Only struct vectors are serialized.');
 if ~isscalar(v),n=2+numel(v)-1;for j=1:numel(v),n=n+bound(v(j));end;return;end
 keys=fieldnames(v);n=2+max(0,numel(keys)-1);for j=1:numel(keys),n=n+bound(keys{j})+1+bound(v.(keys{j}));end;return
end
error('A31NL:SerializationType','Unsupported serialization type.');
end
function writejson(p,value,cap)
assert(~isfile(p),'A31NL:NoOverwrite','Existing artifact is preserved.');b=encoded(value,cap);f=fopen(p,'wb');assert(f>=0,'A31NL:Write','Cannot create JSON.');cl=onCleanup(@()fclose(f));assert(fwrite(f,b,'uint8')==numel(b),'A31NL:Write','Short JSON write.'); %#ok<NASGU>
end
function writecsv(p,P)
assert(~isfile(p),'A31NL:NoOverwrite','Existing CSV is preserved.');f=fopen(p,'wb');assert(f>=0,'A31NL:Write','Cannot create prediction CSV.');cl=onCleanup(@()fclose(f)); %#ok<NASGU>
headers={'job_id','phase','family','D','loss','split_id','outer_fold','seed','replay','stream','schedule_id','stage','task','parentindex','parentrow','group_order','truth','eligible1','eligible2','eligible3','eligible4','label','gap','tie','valid','failure','failure_reason','distance_kind','score1','score2','score3','score4','distance1','distance2','distance3','distance4','Z1','Z2','output1','output2','output3','output4','output5','output6','output7','output8','logit1','logit2','logit3','logit4','logit5','logit6','logit7','logit8','fit_sha256','historical_payload_reused'};
fwrite(f,unicode2native([strjoin(headers,',') newline],'UTF-8'),'uint8');
P=cells(P);
for i=1:numel(P)
 r=P{i};v={quote(r.job_id),quote(r.phase),quote(r.family),num(r.D),quote(r.loss),quote(r.split_id),num(r.outer_fold),num(r.seed),num(r.replay),quote(r.stream),quote(r.schedule_id),num(r.stage),num(r.task),num(r.parentindex),quote(r.parentrow),num(r.group_order),num(r.truth)};
 for a=double(ismember(1:4,r.eligible)),v{end+1}=num(a);end %#ok<AGROW>
 v=[v,{num(r.label),num(r.gap),num(r.tie),num(r.valid),num(r.failure),quote(r.failure_reason),quote(r.distance_kind)}];
 score=nan(1,4);dist=score;score(r.eligible)=r.scores;dist(r.eligible)=r.distances;
 outputs=nan(1,8);logits=outputs;outputs(1:r.D)=r.outputs;logits(1:r.D)=r.logits;
 for a=[score dist r.Z outputs logits],v{end+1}=num(a);end %#ok<AGROW>
 v=[v,{quote(r.fit_sha256),num(r.historical_payload_reused)}];row=unicode2native([strjoin(v,',') newline],'UTF-8');
 assert(numel(row)<=4500,'A31NL:CSVRowCap','Serialized prediction row exceeds4500bytes.');assert(fwrite(f,row,'uint8')==numel(row),'A31NL:Write','Short CSV write.');
end
end
function s=num(x),if isnan(x),s='';else,assert(isfinite(x),'A31NL:CSVFinite','Unexpected infinite CSV value.');s=sprintf('%.17g',double(x));end,end
function s=quote(x),s=['"' strrep(char(x),'"','""') '"'];end
function c=cells(x),if iscell(x),c=x;elseif isempty(x),c={};else,c=num2cell(x);end,end
