function varargout=a31nl_cache_v1(action,varargin)
% Exact A29 numerical-key cache for CE32 and BCE52. No I/O or approximate alias.
switch char(action)
 case 'new',varargout{1}=struct('records',{{}},'origins',{{}},'new_indices',zeros(0,1),'map',containers.Map('KeyType','char','ValueType','double'));
 case 'import',[varargout{1:nargout}]=import_records(varargin{:});
 case 'resolve',[varargout{1:nargout}]=resolve(varargin{:});
 case 'key',varargout{1}=jobhash(varargin{:});
 otherwise,error('A31NL:CacheAction','Unknown cache action.');
end
end
function [cache,report]=import_records(cache,records,origin)
if isempty(records),records={};elseif isstruct(records),records=num2cell(records);end
assert(iscell(records)&&numel(records)<=10000,'A31NL:CacheBound','Imported cache exceeds bounded record count.');
added=0;duplicates=0;skipped=0;
for i=1:numel(records)
 r=records{i};sp=r.spec;ts=sp.terms;if iscell(ts),ts=[ts{:}];end
 compatible=any(r.D==[4 8])&&isempty(sp.anchors)&&sp.ewc_lambda==0;
 if r.D==4,compatible=compatible&&all(ismember({ts.kind},{'ce','softce'}))&&all([ts.T]==1);
 elseif r.D==8,compatible=compatible&&all(strcmp({ts.kind},'bce'));end
 if ~compatible,skipped=skipped+1;continue;end
 r=canonical_record(r);h=jobhash(r.fold,r.seed,r.current_parentindex,r.memory_parentindex,r.incoming_state,r.spec);
 assert(strcmp(h,r.job_sha256),'A31NL:ImportedKey','Imported exact numerical job failed canonical JSON key roundtrip.');
 if isKey(cache.map,h)
  k=cache.map(h);same_job(cache.records{k},r);assert(isequaln(cache.records{k}.final_state,r.final_state),'A31NL:ImportedState','Identical jobs disagree on final optimizer state.');duplicates=duplicates+1;
 else
  k=numel(cache.records)+1;cache.map(h)=k;cache.records{k}=r;cache.origins{k}=origin;added=added+1;
 end
end
assert(numel(cache.records)<=10000,'A31NL:CacheBound','Total cache exceeds bounded record count.');
report=struct('records_added',added,'duplicates_verified',duplicates,'incompatible_records_skipped',skipped,'origin',origin);
end
function [state,receipt,cache,ref]=resolve(cache,fold,seed,cur,memory,incoming,spec,origin)
ids=zeros(0,1,'uint64');if ~isempty(memory),ids=memory.parentindex;end
h=jobhash(fold,seed,cur.parentindex,ids,incoming,spec);
r=struct('job_id',0,'fold',fold,'seed',seed,'D',spec.D,'job_sha256',h,'current_parentindex',cur.parentindex, ...
 'memory_parentindex',ids,'incoming_state',incoming,'final_state',struct(),'spec',spec,'receipt',struct());
aliased=isKey(cache.map,h);
if aliased
 k=cache.map(h);saved=cache.records{k};same_job(saved,r);state=saved.final_state;receipt=saved.receipt;
else
 [state,receipt]=a29cl_stage(incoming,spec);k=numel(cache.records)+1;r.job_id=k;r.final_state=state;r.receipt=receipt;
 cache.records{k}=r;cache.origins{k}=origin;cache.map(h)=k;cache.new_indices(end+1,1)=k;
end
ref=struct('job_sha256',h,'cache_index',k,'aliased',aliased,'origin',cache.origins{k});
end
function h=jobhash(fold,seed,current,memory,incoming,spec)
h=a29cl_data('hash',jsonencode(struct('fold',fold,'seed',seed,'current_parentindex',current, ...
 'memory_parentindex',memory,'incoming',incoming,'spec',spec)));
end
function same_job(a,b)
assert(a.fold==b.fold&&a.seed==b.seed&&a.D==b.D&&isequal(a.current_parentindex,b.current_parentindex)&& ...
 isequal(a.memory_parentindex,b.memory_parentindex)&&isequaln(a.incoming_state,b.incoming_state)&&isequaln(a.spec,b.spec), ...
 'A31NL:ExactAlias','Hash equality without exact objective/data/state equality is rejected.');
end
function r=canonical_record(r)
r.D=double(r.D);r.fold=double(r.fold);r.seed=double(r.seed);
r.current_parentindex=uint64(r.current_parentindex(:));r.memory_parentindex=uint64(r.memory_parentindex(:));
r.incoming_state=state(r.incoming_state,r.D);r.final_state=state(r.final_state,r.D);
sp=r.spec;ts=sp.terms;if iscell(ts),ts=[ts{:}];end
for j=1:numel(ts)
 ts(j).Z=double(ts(j).Z);ts(j).target=double(ts(j).target);
 if strcmp(ts(j).kind,'ce'),ts(j).target=ts(j).target(:);end
 if isempty(ts(j).mask),ts(j).mask=[];else,ts(j).mask=double(ts(j).mask(:)');end
 ts(j).T=double(ts(j).T);ts(j).weight=double(ts(j).weight);
end
sp.terms=reshape(ts,1,[]);if isempty(sp.anchors),sp.anchors=struct('theta',{},'F',{});end
sp.D=double(sp.D);sp.updates=double(sp.updates);sp.ewc_lambda=double(sp.ewc_lambda);sp.control_only=logical(sp.control_only);
assert(sp.D==r.D&&any(sp.D==[4 8])&&isempty(sp.anchors)&&sp.ewc_lambda==0&&all([ts.T]==1), ...
 'A31NL:ImportedMethod','Only unchanged CE/softCE-T1 or codedBCE with no EWC penalty may enter cache.');
r.spec=sp;
end
function s=state(s,D)
s=struct('theta',double(s.theta(:)),'m',double(s.m(:)),'v',double(s.v(:)),'t',uint64(s.t));P=12+5*D;
assert(isequal(size(s.theta),[P 1])&&isequal(size(s.m),[P 1])&&isequal(size(s.v),[P 1])&& ...
 all(isfinite([s.theta;s.m;s.v]))&&all(s.v>=0),'A31NL:State','Invalid imported32/52parameter optimizer state.');
end
