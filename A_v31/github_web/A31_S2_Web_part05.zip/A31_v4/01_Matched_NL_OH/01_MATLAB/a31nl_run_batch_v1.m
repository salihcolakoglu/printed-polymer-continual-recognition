function result=a31nl_run_batch_v1(versionRoot,outDir,config)
% Fixed70-job source worker. Source execution remains closed until exact freeze.
versionRoot=canonical(versionRoot);outDir=canonical(outDir);clock=tic;
assert(startsWith(lower(outDir),lower([versionRoot filesep '04_Results' filesep])),'A31NL:OutputScope','A new version04_Results child is required.');
assert(strcmp(config.mode,'source')&&isequal(config.source_run_authorized,true)&&strcmp(config.admission_token,'A31_NL_ADMITTED_SOURCE_BATCH'),'A31NL:Admission','Exact independently admitted source config required.');
assert(config.max_seconds>0&&config.max_seconds<=240&&config.max_total_output_bytes>0&&config.max_total_output_bytes<=335544320&& ...
 config.max_json_bytes>0&&config.max_json_bytes<=250000000&&config.max_trajectories>=1&&config.max_trajectories<=70,'A31NL:Budget','Finite admitted source worker budget required.');
if isfolder(outDir),d=dir(outDir);assert(~any(~ismember({d.name},{'.','..'})),'A31NL:NoOverwrite','Existing attempt preserved.');else,mkdir(outDir);end
names={'protocol_pin','input_pin','job_contract_pin','phase_jobs_pin','controls_receipt_pin','independent_review_pin','resource_review_pin','reuse_catalog_pin','code_manifest_pin'};
allpins=struct([]);jobs={};completed={};cache=a31nl_cache_v1('new');results={};started=times();
try
 for i=1:numel(names),assert(isfield(config,names{i}),'A31NL:Pin','Missing required config pin.');p=config.(names{i});verify(p);allpins=append(allpins,p);end
 manifest=read(config.code_manifest_pin.path);codes=config.code_pins;if iscell(codes),codes=[codes{:}];end
 assert(strcmp(manifest.schema,'A31_NL_CODE_AUTHORING_MANIFEST_V1')&&numel(codes)==numel(manifest.code_pins)&&numel(codes)>=14,'A31NL:CodeManifest','Complete exact implementation manifest required.');
 addpath(fullfile(versionRoot,'03_MATLAB'));
 for i=1:numel(codes)
  p=codes(i);verify(p);[~,name]=fileparts(p.path);assert(strcmp(canonical(which(name)),canonical(p.path)),'A31NL:Resolution','Unexpected MATLAB function resolution.');
  m=find(strcmp({manifest.code_pins.path},p.path));assert(isscalar(m)&&strcmp(manifest.code_pins(m).sha256,p.sha256),'A31NL:CodeManifest','Runtime code differs from exact manifest.');allpins=append(allpins,p);
 end
 assert(strcmp(canonical([mfilename('fullpath') '.m']),canonical(fullfile(versionRoot,'03_MATLAB/a31nl_run_batch_v1.m'))),'A31NL:Self','Unexpected producer path.');
 protocol=read(config.protocol_pin.path);assert(strcmp(protocol.schema,'A31_MATCHED_NL_OH8_NR_PROTOCOL_V2')&&protocol.NR_semantics.fixed_within_task&&protocol.training.updates_per_stage==600,'A31NL:Protocol','Taskwise P2 source protocol differs.');
 assert(strcmp(config.protocol_pin.sha256,'f23644fcbfd0f9ca6442147f38e25c5b0db93c05d45e4cf4b771bf53331532de'),'A31NL:ProtocolPin','Exact prospective P2 protocol differs.');
 verify(protocol.output_contract.artifact_interface_pin);assert(strcmp(protocol.output_contract.artifact_interface_pin.sha256,'abf25f4e2504d8f8a79d0a7c7ad15ab2df707befc8fd4b61372b9ae5040e3121'),'A31NL:ArtifactContract','Structured D4/D8 artifact contract differs.');allpins=append(allpins,protocol.output_contract.artifact_interface_pin);
 ctr=read(config.controls_receipt_pin.path);assert(ctr.complete&&strcmp(ctr.status,'PASS_SOURCE_FREE_NL_CONTROLS')&&ctr.failed_checks==0&&ctr.source_rows_read==0&&ctr.source_training==0&&ctr.source_predictions==0,'A31NL:Controls','Actual pinned source-free controls must pass first.');
 IR=read(config.independent_review_pin.path);assert(IR.admitted&&strcmp(IR.mode,'source')&&strcmp(IR.phase,config.phase)&&strcmp(IR.batch_plan_sha256,config.phase_jobs_pin.sha256),'A31NL:IndependentReview','Review does not bind this exact batch.');
 RR=read(config.resource_review_pin.path);assert(RR.admitted&&strcmp(RR.mode,'source')&&RR.max_seconds>=config.max_seconds&&RR.max_total_output_bytes>=config.max_total_output_bytes&&RR.max_trajectories>=config.max_trajectories,'A31NL:Resources','Measured resource admission missing.');
 plan=read(config.phase_jobs_pin.path);assert(strcmp(plan.schema,'A31_NL_EXACT_BATCH_PLAN_V1')&&strcmp(plan.phase,config.phase)&&strcmp(plan.batch_id,config.batch_id),'A31NL:Plan','Exact batch identity differs.');jobs=cells(plan.jobs);
 assert(~isempty(jobs)&&numel(jobs)<=70&&numel(jobs)<=config.max_trajectories,'A31NL:Jobs','Fixed job count exceeds cap.');
 ids=cellfun(@(j)j.job_id,jobs,'UniformOutput',false);assert(numel(unique(string(ids)))==numel(ids),'A31NL:Duplicate','Repeated job.');
 if isfield(config,'completed_job_ids'),assert(~any(ismember(string(ids),string(config.completed_job_ids))),'A31NL:AlreadyAccepted','Accepted jobs cannot repeat.');end
 bundle=a31nr_canonical_bundle_v1(read(config.input_pin.path));contract=read(config.job_contract_pin.path);catalog=read(config.reuse_catalog_pin.path);
 assert(strcmp(contract.schema,'A31_NL_FIXED_JOB_CONTRACT_V1')&&contract.job_count==1400&&numel(contract.jobs)==1400&&strcmp(contract.phase,'matched_nl_oh8_response')&&strcmp(config.phase,contract.phase),'A31NL:Contract','Literal1400job contract required.');
 assert(strcmp(contract.input_bundle_pin.sha256,config.input_pin.sha256)&&strcmp(contract.full_reuse_catalog_pin.sha256,config.reuse_catalog_pin.sha256),'A31NL:ContractPins','Input/catalog differ from fixed contract.');
 assert(strcmp(catalog.schema,'A31_NL_STATIC_FULL_REUSE_CATALOG_V1')&&numel(catalog.catalog)==200,'A31NL:Catalog','Exactly200historical STATIC candidates required.');
 allowed=cells(contract.jobs);entries=cells(catalog.catalog);splits=cells(bundle.splits);legacy=containers.Map('KeyType','double','ValueType','any');imports={};fold0=jobs{1}.outer_fold;
 if isfield(config,'cache_inputs')&&~isempty(config.cache_inputs)
  cp=cells(config.cache_inputs);
  for i=1:numel(cp)
   budget(clock,config);p=cp{i};verify(p);allpins=append(allpins,p);old=read(p.path);
   if strcmp(p.format,'A29_LEGACY_RESULT')
    assert(strcmp(old.schema,'A29_MATCHED_CL_RESULT_V1')&&old.failure_count==0,'A31NL:Legacy','Invalid accepted A29 source result.');
    [cache,ir]=a31nl_cache_v1('import',cache,old.unique_fits,p.path);f=double(old.folds);assert(isscalar(f)&&f==fold0&&~isKey(legacy,f),'A31NL:Legacy','Duplicate or unrelated historical fold.');legacy(f)=struct('result',old,'pin',p);
   elseif strcmp(p.format,'A31_NL_NEW_CACHE')
    assert(strcmp(old.schema,'A31_NL_EXACT_NEW_CACHE_V1')&&old.count==numel(old.records),'A31NL:Cache','Malformed accepted new cache.');[cache,ir]=a31nl_cache_v1('import',cache,old.records,p.path);
   elseif strcmp(p.format,'A31_NR_NEW_CACHE')
    assert(strcmp(old.schema,'A31_NR_EXACT_NEW_CACHE_V1')&&old.count==numel(old.records)&&isfield(p,'purpose')&&strcmp(p.purpose,'NUMERICAL_STAGE_ONLY_RECOMPUTE_OH_PREDICTIONS'),'A31NL:Cache','Invalid WH numerical-stage cache contract.');[cache,ir]=a31nl_cache_v1('import',cache,old.records,p.path);
   else,error('A31NL:CacheFormat','Unknown cache format.');end
   imports{end+1,1}=struct('pin',p,'format',p.format,'receipt',ir); %#ok<AGROW>
  end
 end
 assert(all(cellfun(@(r)r.fold==fold0,cache.records)),'A31NL:CacheFold','Only the current outer-fold cache may be imported.');family0=jobs{1}.family;replay0=jobs{1}.replay;
 for i=1:numel(jobs)
  budget(clock,config);job=jobs{i};ix=find(cellfun(@(j)strcmp(j.job_id,job.job_id),allowed));
  assert(isscalar(ix)&&isequaln(orderfields(allowed{ix}),orderfields(job)),'A31NL:LiteralJob','Job differs from immutable1400literal contract.');
  assert(job.outer_fold==fold0&&strcmp(job.family,family0)&&job.replay==replay0&&strcmp(job.inner_design,'outer')&&job.inner_fold==0,'A31NL:Context','One source batch must keep family/fold/replay context fixed.');
  si=find(cellfun(@(s)strcmp(s.split_id,job.split_id),splits));assert(isscalar(si),'A31NL:Split','Unknown split.');data=a31nr_data_v1(bundle,splits{si});
  ci=find(cellfun(@(r)strcmp(r.job_id,job.job_id),entries));
  if ~isempty(ci)
   assert(isscalar(ci)&&isKey(legacy,double(job.outer_fold)),'A31NL:FullCopy','Missing exact old STATIC source.');entry=entries{ci};verify(entry.source_result_pin);ll=legacy(double(job.outer_fold));
   assert(strcmp(ll.pin.sha256,entry.source_result_pin.sha256),'A31NL:FullCopy','Historical source pin differs.');
   [r,cache]=a31nl_reuse_static_v1(data,job,ll.result,ll.pin,entry,cache,600,false);
  else,[r,cache]=a31nl_trajectory_v1(data,job,600,false,cache);end
  a31nl_output_v1('guard_trajectory',r);results{end+1,1}=r;completed{end+1,1}=job.job_id; %#ok<AGROW>
 end
 newrecords=cache.records(cache.new_indices);P={};for i=1:numel(results),P=[P;results{i}.predictions];end %#ok<AGROW>
 assert(numel(newrecords)<=3*numel(jobs)&&numel(P)<=72*numel(jobs),'A31NL:Structure','Aggregate structural cap failed.');
 for i=1:numel(newrecords),a31nl_output_v1('guard_cache_record',newrecords{i});end
 counts=struct('trajectories',numel(results),'logical_stage_instances',3*numel(results),'actual_new_stagefits',numel(newrecords), ...
  'actual_optimizer_updates',600*numel(newrecords),'logical_prediction_rows',numel(P),'new_source_prediction_rows',sum(cellfun(@(r)r.new_source_prediction_rows,results)), ...
  'historical_prediction_rows_reused',sum(cellfun(@(r)r.historical_prediction_rows_reused,results)), ...
  'new_teacher_forward_rows',sum(cellfun(@(r)r.new_teacher_forward_rows,results)), ...
  'historical_full_trajectories',sum(cellfun(@(r)r.historical_full_trajectory_reused,results)),'new_fisher_jobs',0,'physical_validation',0);
 assert(counts.actual_new_stagefits==sum(cellfun(@(r)r.actual_new_stagefits,results))&&counts.logical_prediction_rows==counts.new_source_prediction_rows+counts.historical_prediction_rows_reused,'A31NL:Counts','Actual work/copy counts differ.');
 failureCount=sum(cellfun(@(p)p.failure||~p.valid,P));status='PRODUCER_COMPLETE_PENDING_INDEPENDENT_AUDIT';if failureCount>0,status='TECHNICAL_HOLD_PREDICTIONS_RETAINED';end
 result=struct('schema','A31_NL_BATCH_RESULT_V1','status',status,'phase',config.phase,'batch_id',config.batch_id,'started',started,'completed',times(), ...
  'config',config,'counts',counts,'cache_imports',{imports},'jobs',{results},'source_previously_exposed',true,'new_blind_test',false,'selection_performed',false,'failure_count',failureCount,'elapsed_before_serialization_seconds',toc(clock));
 meta=rmfield(result,'jobs');assert(encoded_size(meta)<=2000000,'A31NL:MetadataCap','Result metadata exceeds2MB.');
 newcache=struct('schema','A31_NL_EXACT_NEW_CACHE_V1','batch_id',config.batch_id,'phase',config.phase,'status','PENDING_INDEPENDENT_SAVED_AUDIT','records',{newrecords},'count',numel(newrecords),'inherited_records_not_recopied',numel(cache.records)-numel(newrecords));
 assert(encoded_size(rmfield(newcache,'records'))<=2000000,'A31NL:MetadataCap','Cache metadata exceeds2MB.');
 a31nl_output_v1('writejson',fullfile(outDir,'nl_batch_result_v1.json'),result,min(config.max_json_bytes,2000000+1200000*numel(jobs)+1000));
 a31nl_output_v1('writejson',fullfile(outDir,'nl_batch_new_fit_cache_v1.json'),newcache,min(config.max_json_bytes,2000000+950000*numel(newrecords)+1000));
 a31nl_output_v1('writecsv',fullfile(outDir,'nl_batch_predictions_v1.csv'),P);
 for i=1:numel(allpins),verify(allpins(i));end
 assert(failureCount==0,'A31NL:PredictionHold','Every failed decision was preserved; source acceptance stops.');budget(clock,config);
 receipt=struct('schema','A31_NL_BATCH_PRODUCER_RECEIPT_V1','status',status,'complete',true,'phase',config.phase,'batch_id',config.batch_id, ...
  'completed_job_ids',{completed},'counts',counts,'elapsed_seconds',toc(clock),'result_pin',pin(fullfile(outDir,'nl_batch_result_v1.json')), ...
  'new_cache_pin',pin(fullfile(outDir,'nl_batch_new_fit_cache_v1.json')),'predictions_pin',pin(fullfile(outDir,'nl_batch_predictions_v1.csv')),'config',config);
 a31nl_output_v1('writejson',fullfile(outDir,'nl_batch_producer_receipt_v1.json'),receipt,1000000);
 assert(bytes(outDir)<=config.max_total_output_bytes,'A31NL:OutputCap','Aggregate artifact cap exceeded.');
catch err
 failed=struct('schema','A31_NL_FAILED_BATCH_RECEIPT_V1','status','FAILED_ATTEMPT_NOT_ACCEPTED','complete',false,'identifier',err.identifier,'message',err.message, ...
  'stack',err.stack,'started',started,'finished',times(),'completed_job_ids',{completed},'complete_trajectories_in_memory',numel(results),'new_stagefits_in_memory',numel(cache.new_indices),'source_acceptance',false);
 a31nl_output_v1('writejson',fullfile(outDir,'nl_batch_FAILED_receipt_v1.json'),failed,262144);rethrow(err);
end
end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function x=read(p),x=jsondecode(fileread(p));end
function c=cells(x),if iscell(x),c=x;elseif isempty(x),c={};else,c=num2cell(x);end,end
function a=append(a,r),r=struct('path',r.path,'bytes',r.bytes,'sha256',r.sha256);if isempty(a),a=r;else,a(end+1)=r;end,end
function verify(p),d=dir(p.path);assert(isscalar(d)&&d.bytes==p.bytes&&strcmp(sha(p.path),p.sha256),'A31NL:Pin','Pinned file differs: %s',p.path);end
function p=pin(p),d=dir(p);p=struct('path',p,'bytes',d.bytes,'sha256',sha(p));end
function h=sha(p)
f=fopen(p,'rb');assert(f>=0,'A31NL:Read','Cannot read pinned file.');cl=onCleanup(@()fclose(f));b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])); %#ok<NASGU>
end
function n=encoded_size(x),n=a31nl_output_v1('bound',x);end
function n=bytes(p),d=dir(p);n=sum([d(~[d.isdir]).bytes]);end
function budget(t,c),assert(toc(t)<=c.max_seconds,'A31NL:TimeCap','Bounded source worker time exceeded.');end
function t=times(),t=struct('utc',char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSSXXX')),'istanbul',char(datetime('now','TimeZone','Europe/Istanbul','Format','yyyy-MM-dd''T''HH:mm:ss.SSSXXX')));end
