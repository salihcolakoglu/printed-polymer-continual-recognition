function a31_nr_report_plots_v2(reportDir,outDir)
% Saved-table graphics only. No model, optimizer, selection or simulation.
assert(~isfolder(outDir),'Preserve prior plot attempt.');mkdir(outDir);
p=fullfile(reportDir,'NR_final_all_seed_metrics_v1.csv');o=detectImportOptions(p,'TextType','string');o=setvartype(o,{'method','replay','stream'},'string');T=readtable(p,o);
methods=["WH8_STATIC","WH8_LEGACY_NR","WH8_SELECTED_NR"];labels={'STATIC','Legacy NR','Selected NR'};colors=[.33 .33 .33;.14 .41 .63;.77 .42 .13];marks={'o','s','^','d','v'};seeds=[101 211 307 401 503];streams=["ClassIL","TaskIL"];
fg=figure('Visible','off','Color','white','Position',[100 100 780 720]);tl=tiledlayout(fg,2,2,'TileSpacing','compact','Padding','compact');
for i=1:2
 for j=1:2
  ax=nexttile(tl);hold(ax,'on');rp="False";if j==2,rp="True";end
  for k=1:3
   q=T(T.method==methods(k)&T.stream==streams(i)&strcmpi(T.replay,rp),:);q=sortrows(q,'seed');assert(height(q)==5&&isequal(q.seed(:)',seeds));v=q.accuracy_percent;
   plot(ax,[k k],[min(v) max(v)],'-','Color',colors(k,:),'LineWidth',1.5);plot(ax,[k-.16 k+.16],[median(v) median(v)],'-','Color',colors(k,:),'LineWidth',2.2);
   for n=1:5,plot(ax,k+(n-3)*.065,v(n),marks{n},'MarkerSize',6,'MarkerEdgeColor',colors(k,:),'MarkerFaceColor',colors(k,:));end
  end
  baseline=63.46153846153846;if i==2,baseline=88.46153846153846;end
  yline(ax,baseline,'--','Color',[.21 .48 .28],'LineWidth',1.2);ylim(ax,[0 100]);xlim(ax,[.5 3.5]);xticks(ax,1:3);xticklabels(ax,labels);grid(ax,'on');ax.GridAlpha=.14;ax.FontSize=12;
  word='no replay';if j==2,word='replay';end;title(ax,char(streams(i)+"; "+word));if j==1,ylabel(ax,'Final accuracy (%)');end
 end
end
ax=nexttile(tl,1);h=gobjects(6,1);h(1)=plot(ax,nan,nan,'--','Color',[.21 .48 .28],'LineWidth',1.2);for n=1:5,h(n+1)=plot(ax,nan,nan,marks{n},'Color',[.3 .3 .3],'MarkerFaceColor',[.3 .3 .3]);end
lg=legend(ax,h,{'NN1 (full archive)','101','211','307','401','503'},'Orientation','horizontal','FontSize',11,'Box','off');lg.Layout.Tile='south';
savefigs(fg,outDir,'NR_final_accuracy_all_seeds_v2');close(fg);
p=fullfile(reportDir,'NR_DEV_complete_pooled_counts_v1.csv');o=detectImportOptions(p,'TextType','string');o=setvartype(o,{'phase','replay','schedule_id'},'string');D=readtable(p,o);D=D(D.phase=="coarse",:);
ids=["F00_STATIC","F25","F50","F75","F90","UP_NR_LEGACY","UP_LINEAR","DOWN_LINEAR","HARD_FIRST_THEN_NR","PEAK","VALLEY"];
names={'0','.25','.50','.75','.90','Legacy up','Linear up','Linear down','Hard first','Peak','Valley'};
fg=figure('Visible','off','Color','white','Position',[100 100 780 800]);tl=tiledlayout(fg,2,1,'TileSpacing','compact','Padding','compact');
for j=1:2
 ax=nexttile(tl);rp="False";word='no replay';if j==2,rp="True";word='replay';end;M=zeros(5,11);
 for fold=1:5
  for k=1:11
   q=D(D.outer_fold==fold&strcmpi(D.replay,rp)&D.schedule_id==ids(k),:);assert(height(q)==2);M(fold,k)=100*median(q.correct./q.N);
  end
 end
 imagesc(ax,M,[0 100]);colormap(ax,parula(256));c=colorbar(ax);c.Label.String='Two-seed median accuracy (%)';
 for fold=1:5,for k=1:11,color='white';if M(fold,k)>55,color='black';end;text(ax,k,fold,sprintf('%.1f',M(fold,k)),'HorizontalAlignment','center','Color',color,'FontSize',11);end,end
 xticks(ax,1:11);xticklabels(ax,names);xtickangle(ax,40);yticks(ax,1:5);ylabel(ax,'Outer fold');title(ax,['Inner DEV: ' word]);ax.FontSize=12;
end
savefigs(fg,outDir,'NR_coarse_inner_DEV_heatmaps_v2');close(fg);
receipt=struct('status','PLOTS_EXPORTED_FROM_ACCEPTED_TABLES','model_calls',0,'training',0,'simulation',0,'selection',0,'seed_values_preserved',true,'coarse_heatmap_only_innerDEV',true);
fid=fopen(fullfile(outDir,'plot_receipt_v2.json'),'w','n','UTF-8');fwrite(fid,jsonencode(receipt),'char');fclose(fid);
end
function savefigs(fg,outDir,name)
set(fg,'Color','white');
axesList=findall(fg,'Type','axes');
for kk=1:numel(axesList)
 ax=axesList(kk);set(ax,'Color','white','XColor','black','YColor','black','GridColor',[.7 .7 .7]);
 ax.Title.Color='black';ax.XLabel.Color='black';ax.YLabel.Color='black';
end
legends=findall(fg,'Type','legend');for kk=1:numel(legends),legends(kk).TextColor='black';legends(kk).Color='white';end
bars=findall(fg,'Type','colorbar');for kk=1:numel(bars),bars(kk).Color='black';bars(kk).Label.Color='black';end
exportgraphics(fg,fullfile(outDir,[name '.png']),'Resolution',300);
exportgraphics(fg,fullfile(outDir,[name '.pdf']),'ContentType','vector');
print(fg,fullfile(outDir,[name '.svg']),'-dsvg');
end
