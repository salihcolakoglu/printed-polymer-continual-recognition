"""Frozen, source-free schedule ranking/generation rules. No model/data fit API."""
from itertools import combinations
from statistics import median
import math

COARSE = [
    dict(id='F00_STATIC', family='constant', alpha=[0., 0., 0.]),
    dict(id='F25', family='constant', alpha=[.25, .25, .25]),
    dict(id='F50', family='constant', alpha=[.5, .5, .5]),
    dict(id='F75', family='constant', alpha=[.75, .75, .75]),
    dict(id='F90', family='constant', alpha=[.9, .9, .9]),
    dict(id='UP_NR_LEGACY', family='increasing', alpha=[.5, 2/3, .75]),
    dict(id='UP_LINEAR', family='increasing', alpha=[.25, .5, .75]),
    dict(id='DOWN_LINEAR', family='decreasing', alpha=[.75, .5, .25]),
    dict(id='HARD_FIRST_THEN_NR', family='hard_first', alpha=[0., 2/3, .75]),
    dict(id='PEAK', family='increasing_then_decreasing', alpha=[.25, .75, .25]),
    dict(id='VALLEY', family='decreasing_then_increasing', alpha=[.75, .25, .75]),
]

def vector_key(alpha):
    if len(alpha) != 3 or not all(math.isfinite(x) and 0 <= x <= .9 for x in alpha):
        raise ValueError('Expected three finite alpha coordinates in [0,.9].')
    return tuple(float(x).hex() for x in alpha)

def is_constant(alpha):
    return alpha[0] == alpha[1] == alpha[2]

def rank_candidates(candidates, pooled, seeds, expected_n):
    """pooled: {candidate_id:{seed:{correct_by_class:[4],total_by_class:[4]}}}.

    Every seed must pool all inner folds once. Balanced class support makes total
    correct an exact primary ranking statistic. All required records mandatory.
    """
    if len(seeds) not in (2, 5) or expected_n % 4:
        raise ValueError('Only declared 2/5 seeds and balanced complete groups.')
    if len({c['id'] for c in candidates}) != len(candidates):
        raise ValueError('Duplicate candidate ID.')
    if len({vector_key(c['alpha']) for c in candidates}) != len(candidates):
        raise ValueError('Duplicate candidate vector.')
    rows = []
    for c in candidates:
        vals = []
        for seed in seeds:
            r = pooled[c['id']][str(seed)] if str(seed) in pooled[c['id']] else pooled[c['id']][seed]
            cc, nn = r['correct_by_class'], r['total_by_class']
            if len(cc) != 4 or nn != [expected_n//4]*4:
                raise ValueError('All four class denominators must match complete source groups.')
            if any(type(a) is not int or not 0 <= a <= b for a,b in zip(cc,nn)):
                raise ValueError('Invalid or incomplete class counts. HOLD; no row omission.')
            vals.append(sum(cc))
        # Doubled median remains an integer for both two and five seeds.
        median2 = int(2*median(vals))
        key = (-median2, -min(vals), int(not is_constant(c['alpha'])), sum(c['alpha'])/3, c['id'])
        rows.append(dict(candidate=c, correct_per_seed=vals, median2_correct=median2,
                         minimum_correct=min(vals), n=expected_n, ranking_key=key,
                         balanced_accuracy_per_seed=[v/expected_n for v in vals]))
    return sorted(rows, key=lambda r:r['ranking_key'])

def refinement(candidates, pooled, seeds, expected_n):
    """At most two new vectors, decided only from complete coarse inner DEV.

    R1: adjacent constant midpoint. R2: first novel nonconstant midpoint of a
    deterministic ranked pair. No recursive refinement or outer result input.
    """
    if list(seeds) != [101,211]:
        raise ValueError('Refinement trigger requires the two fixed screen seeds.')
    ranked = rank_candidates(candidates, pooled, seeds, expected_n)
    winners, margins = [], []
    for j in range(2):
        ordered = sorted(ranked, key=lambda r:(-r['correct_per_seed'][j], r['candidate']['id']))
        winners.append(ordered[0]['candidate']['id'])
        margins.append(ordered[0]['correct_per_seed'][j]-ordered[1]['correct_per_seed'][j])
    enabled = winners[0] == winners[1] and all(m >= 2 for m in margins)
    receipt = dict(enabled=enabled, winners=winners, margins_correct=margins,
                   rule='same unique winner and >=2 pooled correct-decision lead in BOTH screen seeds',
                   generated=[], excluded_duplicates=[])
    if not enabled:
        return receipt
    seen = {vector_key(c['alpha']) for c in candidates}
    rank = {r['candidate']['id']:i for i,r in enumerate(ranked)}
    constants = sorted((c for c in candidates if is_constant(c['alpha'])), key=lambda c:c['alpha'][0])
    best = min(constants, key=lambda c:rank[c['id']])
    k = constants.index(best)
    neighbors = [constants[j] for j in (k-1,k+1) if 0 <= j < len(constants)]
    neighbors.sort(key=lambda c:(rank[c['id']], c['alpha'][0], c['id']))
    for neighbor in neighbors:
        x = (best['alpha'][0]+neighbor['alpha'][0])/2
        v = [x,x,x]
        if vector_key(v) not in seen:
            c = dict(id='R1_CONST',family='refined_constant',alpha=v,
                     parents=[best['id'],neighbor['id']])
            receipt['generated'].append(c);seen.add(vector_key(v));break
        receipt['excluded_duplicates'].append(v)
    pairs = sorted(combinations(range(len(ranked)),2), key=lambda ij:(sum(ij),max(ij),ij[0],ij[1]))
    for i,j in pairs:
        a,b = ranked[i]['candidate'],ranked[j]['candidate']
        if is_constant(a['alpha']) and is_constant(b['alpha']):
            continue
        v = [(x+y)/2 for x,y in zip(a['alpha'],b['alpha'])]
        if is_constant(v) or vector_key(v) in seen:
            continue
        c = dict(id='R2_MIX',family='refined_stage_vector',alpha=v,parents=[a['id'],b['id']])
        receipt['generated'].append(c);seen.add(vector_key(v));break
    assert len(receipt['generated']) <= 2
    return receipt

def finalist_ids(candidates, pooled, seeds, expected_n):
    return [r['candidate']['id'] for r in rank_candidates(candidates,pooled,seeds,expected_n)[:2]]

def synthetic_rule_checks():
    """Artificial count fixtures only. Not experimental results."""
    def fixture(ties=False):
        out={}
        for i,c in enumerate(COARSE):
            out[c['id']]={}
            for s in (101,211):
                cc=[10]*4 if ties else [19-i]*4
                out[c['id']][str(s)]=dict(correct_by_class=cc,total_by_class=[20]*4)
        return out
    tied=fixture(True);strong=fixture(False)
    assert rank_candidates(COARSE,tied,[101,211],80)[0]['candidate']['id']=='F00_STATIC'
    assert not refinement(COARSE,tied,[101,211],80)['enabled']
    r=refinement(COARSE,strong,[101,211],80)
    assert r['enabled'] and len(r['generated'])==2
    assert r['generated'][0]['alpha']==[.125]*3
    assert len({vector_key(c['alpha']) for c in COARSE+r['generated']})==13
    bad=fixture(False);bad['F00_STATIC']['101']['total_by_class']=[19,20,20,21]
    try:rank_candidates(COARSE,bad,[101,211],80)
    except ValueError:pass
    else:raise AssertionError('Unbalanced support was silently accepted.')
    return dict(status='PASS',artificial_only=True,checks=6,new_training=0,new_inference=0)
