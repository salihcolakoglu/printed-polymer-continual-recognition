function receipt=a31nr_source_adapter_controls_v2(outDir,config)
% Additional source-free parser/reuse controls. No new600-update fit or source.
% The previously accepted synthetic benchmark supplies numerical states; only
% control_only metadata is changed for an explicitly artificial legacy-format
% emulation. This flag has no term/gradient/Adam effect. It is not oldsource.
outDir=canonical(outDir);root=fileparts(fileparts(mfilename('fullpath')));
assert(startsWith(lower(outDir),lower([root filesep '05_Audit' filesep])), ...
 'A31NR:ControlScope','Adapter controls output must be a new audit child.');
if isfolder(outDir),d=dir(outDir);assert(~any(~ismember({d.name},{'.','..'})),'A31NR:ExistingOutput','Preserve prior output.');else,mkdir(outDir);end
p=config.benchmark_result_pin;assert(strcmp(sha(p.path),p.sha256)&&dirbytes(p.path)==p.bytes,'A31NR:BenchmarkPin','Pinned artificial benchmark changed.');
br=jsondecode(fileread(p.path));assert(br.source_free_control&&br.source_training_stages==0&&br.all_updates_per_stage==600, ...
 'A31NR:SyntheticOnly','Only source-free600-update benchmark may supply these states.');
[bundle,splits]=a31nr_fixture_v1();bundle.splits=splits;raw=jsondecode(jsonencode(bundle));fixed=a31nr_canonical_bundle_v1(raw);
checks=struct('id',{},'pass',{});C=bundle.codebook_WH8;
check(isequal(vertcat(fixed.records.X),vertcat(bundle.records.X)),'JSON_X_ROW_SHAPE_VALUES_UNCHANGED');
for f=[1 2]
 original=a31nr_data_v1(bundle,splits(f));sp=fixed.splits(f);parsed=a31nr_data_v1(fixed,sp);
 check(isequaln(original.normalizer,parsed.normalizer),sprintf('JSON_SCALER_EXACT_f%d',f));
 for stream={'TaskIL','ClassIL'}
  for s=1:3
   check(isequaln(original.current(stream{1},s),parsed.current(stream{1},s)),sprintf('JSON_CURRENT_%s_f%d_s%d',stream{1},f,s));
   check(isequaln(original.query(stream{1},s),parsed.query(stream{1},s)),sprintf('JSON_QUERY_%s_f%d_s%d',stream{1},f,s));
  end
 end
end
% Nested split roundtrip also preserves actual TRAIN-only normalization.
sp=splits(1);gg=unique([bundle.records(sp.train_indices1).group_order]);
allTrain=sp.train_indices1;devG=gg(1:10);sp.dev_indices1=allTrain(ismember([bundle.records(allTrain).group_order],devG));
sp.train_indices1=allTrain(~ismember([bundle.records(allTrain).group_order],devG));
sp.normalizer_fit_indices1=sp.train_indices1([bundle.records(sp.train_indices1).label]<=2);
sp.inner_design='screen2';sp.inner_fold=1;sp.split_id='ART_INNER_JSON';
a=a31nr_data_v1(bundle,sp);b=a31nr_data_v1(fixed,jsondecode(jsonencode(sp)));
check(isequaln(a.normalizer,b.normalizer),'JSON_INNER_SCALER_EXACT');
for s=1:3
 check(isequaln(a.current('ClassIL',s),b.current('ClassIL',s)),sprintf('JSON_INNER_CURRENT_s%d',s));
 check(isequaln(a.query('ClassIL',s),b.query('ClassIL',s)),sprintf('JSON_INNER_QUERY_s%d',s));
end
% Emulate exactly the accepted legacy result's field layout using benchmark
% numerical values. No optimization/forward/decode is performed in this test.
S=cells(br.stages);records=cell(3,1);logicalStages=cell(3,1);
for s=1:3
 st=S{s};spec=st.spec;spec.control_only=false;incoming=typedstate(st.incoming_state);final=typedstate(st.final_state);
 current=uint64(st.current_parentindex(:));memory=zeros(0,1,'uint64');if ~isempty(st.effective_replay),memory=uint64(st.effective_replay.parentindex(:));end
 key=a29cl_data('hash',jsonencode(struct('fold',2,'seed',101,'current_parentindex',current,'memory_parentindex',memory,'incoming',incoming,'spec',spec)));
 rr=st.stage_receipt;rr.control_only=false;
 records{s}=struct('job_id',s,'fold',2,'seed',101,'D',8,'job_sha256',key, ...
  'current_parentindex',current,'memory_parentindex',memory,'incoming_state',incoming, ...
  'final_state',final,'spec',spec,'receipt',rr);
 logicalStages{s}=struct('id',s,'fold',2,'seed',101,'arm','WH8_NEG_REPLAY','stream','ClassIL', ...
  'stage',s,'job_id',s,'current_parentindex',current,'teacher',st.target_cache.teacher,'qcache',{{st.target_cache.q}});
end
P=cells(br.predictions);oldP=cell(size(P));
for i=1:numel(P)
 r=P{i};r.fold=2;r.arm='WH8_NEG_REPLAY';r.job_id=r.stage;oldP{i}=r;
end
old=struct('schema','A29_MATCHED_CL_RESULT_V1','codebooks',struct('WH8',C), ...
 'initial_states',{{struct('fold',2,'seed',101,'D',8,'state',br.initial_state)}}, ...
 'unique_fits',{records},'logical_stages',{logicalStages},'predictions',{oldP});
old=jsondecode(jsonencode(old));cache=a31nr_cache_v1('new');[cache,imported]=a31nr_cache_v1('import',cache,old.unique_fits,'SYNTHETIC_SOURCE_FORMAT_EMULATION_NOT_SOURCE');
check(imported.records_added==3,'ARTIFICIAL_LEGACY_FORMAT_CACHE_IMPORT');
data=a31nr_data_v1(fixed,fixed.splits(2));job=struct('job_id','ARTIFICIAL_FULL_OUTER_REUSE', ...
 'phase','outer_selected','split_id',fixed.splits(2).split_id,'outer_fold',2,'inner_design','outer', ...
 'inner_fold',0,'seed',101,'replay',true,'stream','ClassIL','schedule_id','UP_NR_LEGACY','alpha',[.5 2/3 .75]);
origin=struct('path','SOURCE_FREE_BENCHMARK_FORMAT_EMULATION','bytes',0,'sha256',p.sha256);
[reused,cache]=a31nr_reuse_outer_v1(data,job,C,old,origin,cache);
check(reused.actual_new_stagefits==0&&reused.actual_optimizer_updates==0&&reused.new_source_prediction_rows==0,'FULL_REUSE_NO_NEW_OPTIMIZER_OR_FORWARD');
for s=1:3
 check(isequaln(reused.stages{s}.final_state,typedstate(S{s}.final_state))&&reused.stages{s}.fit_reference.aliased,sprintf('FULL_REUSE_STATE_EXACT_s%d',s));
 check(reused.stages{s}.target_cache.teacher_forward_rows==0&&isempty(reused.stages{s}.target_cache.teacher_logits),sprintf('FULL_REUSE_NO_NEW_TEACHER_s%d',s));
end
check(numel(reused.predictions)==numel(P)&&reused.historical_prediction_rows_reused==numel(P),'FULL_REUSE_QUERY_POPULATION');
for i=1:numel(P)
 a=P{i};b=reused.predictions{i};fields={'Z','truth','parentindex','parentrow','eligible','label','gap','tie','valid','failure','outputs','logits','distances','scores'};ok=true;
 for k=1:numel(fields)
  aa=a.(fields{k});bb=b.(fields{k});if isnumeric(aa),ok=ok&&isequaln(double(aa(:)),double(bb(:)));else,ok=ok&&isequaln(aa,bb);end
 end
 check(ok,sprintf('FULL_REUSE_QUERY_PAYLOAD_%d',i));
end
check(rejects(@()a31nr_reuse_outer_v1(data,job,C,old,origin,a31nr_cache_v1('new')),'A31NR:LegacyExactStage'),'FULL_REUSE_MISSING_CACHE_STOP_NO_TRAIN_FALLBACK');
receipt=struct('schema','A31_NR_SOURCE_ADAPTER_CONTROL_RECEIPT_V1','status','PASS_SOURCE_FREE_ADAPTER_CONTROLS', ...
 'complete',true,'checks',checks,'passed_checks',numel(checks),'failed_checks',0, ...
 'source_rows_read',0,'new_source_training',0,'new_source_predictions',0,'new_synthetic_training',0, ...
 'benchmark_state_pin',p,'synthetic_source_format_emulation',true, ...
 'emulation_metadata_change','Only600-update control_only flag true→false and its numerical-job hash serialization change; states/specnumericvalues unchanged. This is an artificial format control, not accepted source evidence.', ...
 'inherited_benchmark_controls_not_repeated',true);
write(fullfile(outDir,'nr_source_adapter_controls_receipt_v1.json'),receipt);
write(fullfile(outDir,'nr_synthetic_outer_reuse_payload_v1.json'),reused);
 function check(ok,id),assert(isscalar(ok)&&logical(ok),'A31NR:AdapterControl','Adapter control failed: %s',id);checks(end+1)=struct('id',id,'pass',true);end
end
function s=typedstate(s),s=struct('theta',double(s.theta(:)),'m',double(s.m(:)),'v',double(s.v(:)),'t',uint64(s.t));end
function c=cells(x),if iscell(x),c=x;elseif isempty(x),c={};else,c=num2cell(x);end,end
function ok=rejects(f,id),ok=false;try,f();catch e,ok=strcmp(e.identifier,id);end,end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function n=dirbytes(p),d=dir(p);n=d.bytes;end
function h=sha(p)
f=fopen(p,'rb');assert(f>=0);c=onCleanup(@()fclose(f));b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));
end
function write(p,r)
assert(~isfile(p));b=unicode2native(jsonencode(r,'ConvertInfAndNaN',true),'UTF-8');assert(numel(b)<10000000);f=fopen(p,'wb');assert(f>=0);c=onCleanup(@()fclose(f));assert(fwrite(f,b,'uint8')==numel(b));
end
