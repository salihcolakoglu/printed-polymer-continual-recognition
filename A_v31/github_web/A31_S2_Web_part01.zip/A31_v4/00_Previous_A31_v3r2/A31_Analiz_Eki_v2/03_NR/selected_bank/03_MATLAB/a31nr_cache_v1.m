function varargout=a31nr_cache_v1(action,varargin)
% Exact numerical-stage cache. No file access, no approximate aliasing.
switch char(action)
 case 'new'
  varargout{1}=struct('records',{{}},'origins',{{}},'new_indices',zeros(0,1), ...
   'map',containers.Map('KeyType','char','ValueType','double'));
 case 'import'
  [varargout{1:nargout}]=import_records(varargin{:});
 case 'resolve'
  [varargout{1:nargout}]=resolve(varargin{:});
 otherwise,error('A31NR:CacheAction','Unknown cache action.');
end
end
function [cache,report]=import_records(cache,records,origin)
if isstruct(records),records=num2cell(records);end
assert(iscell(records)&&numel(records)<=10000,'A31NR:CacheBound','Imported cache exceeds finite record bound.');
accepted=0;duplicate=0;skipped=0;
for i=1:numel(records)
 r=records{i};if r.D~=8,skipped=skipped+1;continue;end
 r=canonical_record(r);h=jobhash(r.fold,r.seed,r.current_parentindex,r.memory_parentindex,r.incoming_state,r.spec);
 assert(strcmp(h,r.job_sha256),'A31NR:ImportedJobHash','Imported numerical job does not exactly round-trip its accepted key.');
 if isKey(cache.map,h)
  k=cache.map(h);same_job(cache.records{k},r);assert(isequaln(cache.records{k}.final_state,r.final_state),'A31NR:ImportedState','Identical accepted jobs disagree.');duplicate=duplicate+1;
 else
  k=numel(cache.records)+1;cache.map(h)=k;cache.records{k}=r;cache.origins{k}=origin;accepted=accepted+1;
 end
end
assert(numel(cache.records)<=10000,'A31NR:CacheBound','Total cache bound exceeded.');
report=struct('records_added',accepted,'duplicates_verified',duplicate,'non_WH8_width_skipped',skipped,'origin',origin);
end
function [state,receipt,cache,ref]=resolve(cache,fold,seed,cur,replay,incoming,spec,origin)
memory=zeros(0,1,'uint64');if ~isempty(replay),memory=replay.parentindex;end
h=jobhash(fold,seed,cur.parentindex,memory,incoming,spec);
r=struct('job_id',0,'fold',fold,'seed',seed,'D',8,'job_sha256',h, ...
 'current_parentindex',cur.parentindex,'memory_parentindex',memory, ...
 'incoming_state',incoming,'final_state',struct(),'spec',spec,'receipt',struct());
aliased=isKey(cache.map,h);
if aliased
 k=cache.map(h);saved=cache.records{k};same_job(saved,r);state=saved.final_state;receipt=saved.receipt;
else
 [state,receipt]=a29cl_stage(incoming,spec);k=numel(cache.records)+1;r.job_id=k; ...
  r.final_state=state;r.receipt=receipt;cache.records{k}=r;cache.origins{k}=origin; ...
  cache.map(h)=k;cache.new_indices(end+1,1)=k;
end
ref=struct('job_sha256',h,'cache_index',k,'aliased',aliased,'origin',cache.origins{k});
end
function h=jobhash(fold,seed,current,memory,incoming,spec)
% This literal field order/type matches the original accepted a29cl_run key.
h=a29cl_data('hash',jsonencode(struct('fold',fold,'seed',seed, ...
 'current_parentindex',current,'memory_parentindex',memory,'incoming',incoming,'spec',spec)));
end
function same_job(a,b)
assert(a.fold==b.fold&&a.seed==b.seed&&a.D==b.D&& ...
 isequal(a.current_parentindex,b.current_parentindex)&& ...
 isequal(a.memory_parentindex,b.memory_parentindex)&& ...
 isequaln(a.incoming_state,b.incoming_state)&&isequaln(a.spec,b.spec), ...
 'A31NR:ExactAlias','Hash equality without exact numeric job equality rejected.');
end
function r=canonical_record(r)
r.current_parentindex=uint64(r.current_parentindex(:));r.memory_parentindex=uint64(r.memory_parentindex(:));
r.incoming_state=state(r.incoming_state);r.final_state=state(r.final_state);
sp=r.spec;ts=sp.terms;if iscell(ts),ts=[ts{:}];end
for j=1:numel(ts)
 ts(j).Z=double(ts(j).Z);ts(j).target=double(ts(j).target);
 if isempty(ts(j).mask),ts(j).mask=[];else,ts(j).mask=double(ts(j).mask(:)');end
 ts(j).T=double(ts(j).T);ts(j).weight=double(ts(j).weight);
end
sp.terms=reshape(ts,1,[]);if isempty(sp.anchors),sp.anchors=struct('theta',{},'F',{});end
sp.D=double(sp.D);sp.updates=double(sp.updates);sp.ewc_lambda=double(sp.ewc_lambda);sp.control_only=logical(sp.control_only);
assert(sp.D==8&&isempty(sp.anchors)&&sp.ewc_lambda==0&& ...
 all(strcmp({sp.terms.kind},'bce')),'A31NR:ImportedMethod','Only coded BCE no-EWC jobs accepted.');
r.spec=sp;
end
function s=state(s)
s=struct('theta',double(s.theta(:)),'m',double(s.m(:)),'v',double(s.v(:)),'t',uint64(s.t));
assert(numel(s.theta)==52&&numel(s.m)==52&&numel(s.v)==52&&all(isfinite([s.theta;s.m;s.v]))&&all(s.v>=0),'A31NR:ImportedState','Invalid imported coded optimizer state.');
end
