function result=a31nr_run_batch_v1(versionRoot,outDir,config)
% Pinned bounded batch; plans/rankings are prepared externally before this call.
% No adaptive candidate choice, DEV feedback, early stopping or hyper-search.
versionRoot=canonical(versionRoot);outDir=canonical(outDir);clock=tic;
assert(startsWith(lower(outDir),lower([versionRoot filesep '04_Results' filesep])), ...
 'A31NR:OutputScope','Source output must be a new version04_Results child.');
assert(strcmp(config.mode,'source')&&isequal(config.source_run_authorized,true)&& ...
 strcmp(config.admission_token,'A31_NR_ADMITTED_SOURCE_BATCH'), ...
 'A31NR:Admission','Explicit independently admitted source batch required.');
assert(config.max_seconds>0&&config.max_seconds<=600&&config.max_total_output_bytes>0&& ...
 config.max_total_output_bytes<=67108864&&config.max_json_bytes>0&& ...
 config.max_json_bytes<=60000000&&config.max_json_bytes<=config.max_total_output_bytes&& ...
 config.max_trajectories>=1&&config.max_trajectories<=40,'A31NR:Budget','Finite phase batch budget required.');
if isfolder(outDir),d=dir(outDir);assert(~any(~ismember({d.name},{'.','..'})),'A31NR:ExistingOutput','Previous attempts/results preserved.');else,mkdir(outDir);end
names={'protocol_pin','input_pin','job_contract_pin','phase_jobs_pin','controls_receipt_pin', ...
 'adapter_controls_receipt_pin','independent_review_pin','resource_review_pin'};
allpins=struct([]);jobs=[];completed={};cache=a31nr_cache_v1('new');results={};
started=times();
try
 for i=1:numel(names),assert(isfield(config,names{i}),'A31NR:RequiredPin','Missing required pin %s',names{i});p=config.(names{i});verify(p);allpins=append(allpins,basicpin(p));end
 assert(isfield(config,'code_pins')&&numel(config.code_pins)>=12,'A31NR:CodePins','Complete code dependency pins required.');
 codes=config.code_pins;if iscell(codes),codes=[codes{:}];end
 addpath(fullfile(versionRoot,'03_MATLAB'));
 for i=1:numel(codes)
  p=codes(i);verify(p);[~,name]=fileparts(p.path);
  assert(strcmp(canonical(which(name)),canonical(p.path)),'A31NR:CodeResolution','Unexpected MATLAB resolution for %s',name);
  allpins=append(allpins,basicpin(p));
 end
 assert(strcmp(canonical([mfilename('fullpath') '.m']),canonical(fullfile(versionRoot,'03_MATLAB','a31nr_run_batch_v1.m'))),'A31NR:SelfPath','Unexpected producer path.');
 protocol=read(config.protocol_pin.path);assert(strcmp(protocol.id,'A31_NR_SENSITIVITY_20261024_V2'),'A31NR:Protocol','Exact reviewed v2protocol required.');
 controls=read(config.controls_receipt_pin.path);assert(controls.complete&&strcmp(controls.status,'PASS_SOURCE_FREE_CONTROLS')&&controls.failed_checks==0&&controls.source_rows_read==0&&controls.source_training==0,'A31NR:Controls','Actual artificial controls required.');
 adapter=read(config.adapter_controls_receipt_pin.path);assert(adapter.complete&& ...
  strcmp(adapter.status,'PASS_SOURCE_FREE_ADAPTER_CONTROLS')&&adapter.failed_checks==0&& ...
  adapter.source_rows_read==0&&adapter.new_source_training==0&&adapter.new_source_predictions==0, ...
  'A31NR:AdapterControls','Actual JSON shape and no-forward outer transfer controls required.');
 IR=read(config.independent_review_pin.path);assert(IR.admitted&&strcmp(IR.mode,'source')&& ...
  strcmp(IR.phase,config.phase)&&strcmp(IR.batch_plan_sha256,config.phase_jobs_pin.sha256), ...
  'A31NR:IndependentReview','Independent review does not bind exact phase batch plan.');
 RR=read(config.resource_review_pin.path);assert(RR.admitted&&strcmp(RR.mode,'source')&& ...
  RR.max_seconds>=config.max_seconds&&RR.max_total_output_bytes>=config.max_total_output_bytes&& ...
  RR.max_trajectories>=config.max_trajectories,'A31NR:ResourceReview','Measured resource admission missing or too small.');
 plan=read(config.phase_jobs_pin.path);assert(strcmp(plan.schema,'A31_NR_EXACT_BATCH_PLAN_V1')&& ...
  strcmp(plan.phase,config.phase)&&strcmp(plan.batch_id,config.batch_id),'A31NR:BatchPlan','Pinned phase/batch identity mismatch.');
 jobs=cells(plan.jobs);assert(~isempty(jobs)&&numel(jobs)<=config.max_trajectories&& ...
  numel(unique(string(cellfun(@(j)j.job_id,jobs,'UniformOutput',false))))==numel(jobs), ...
  'A31NR:BatchJobs','Empty, duplicated or oversized trajectory batch.');
 if isfield(config,'completed_job_ids'),assert(~any(ismember(string(cellfun(@(j)j.job_id,jobs,'UniformOutput',false)),string(config.completed_job_ids))),'A31NR:AlreadyAcceptedJob','Accepted full trajectory must not be repeated.');end
 bundle=a31nr_canonical_bundle_v1(read(config.input_pin.path));contract=read(config.job_contract_pin.path);
 assert(strcmp(contract.input_bundle_pin.sha256,config.input_pin.sha256)&& ...
  strcmp(protocol.input_bundle.sha256,config.input_pin.sha256)&& ...
  strcmp(protocol.job_contract.sha256,config.job_contract_pin.sha256), ...
  'A31NR:InputBinding','Runtime input/contract differs from protocol.');
 C=double(bundle.codebook_WH8);assert(isequal(C,[0 1 0 1 0 1 0 1;0 0 1 1 0 0 1 1;0 1 1 0 0 1 1 0;0 0 0 0 1 1 1 1]),'A31NR:WH8','Fixed accepted WH8 codebook required.');
 splits=cells(bundle.splits);legacy=containers.Map('KeyType','double','ValueType','any');imports={};
 if isfield(config,'cache_inputs')&&~isempty(config.cache_inputs)
  inputs=cells(config.cache_inputs);
  for i=1:numel(inputs)
   budget(clock,config);cp=inputs{i};verify(cp);allpins=append(allpins,basicpin(cp));old=read(cp.path);
   if strcmp(cp.format,'A29_LEGACY_RESULT')
    assert(strcmp(old.schema,'A29_MATCHED_CL_RESULT_V1')&&old.failure_count==0,'A31NR:LegacyResult','Unexpected historical result.');
    [cache,report]=a31nr_cache_v1('import',cache,old.unique_fits,cp.path);
    ff=double(old.folds);assert(isscalar(ff)&&ismember(ff,1:5)&&~isKey(legacy,ff),'A31NR:LegacyFold','One exact historical result per fold.');
    legacy(ff)=struct('result',old,'pin',basicpin(cp));
   elseif strcmp(cp.format,'A31_NR_NEW_CACHE')
    assert(strcmp(old.schema,'A31_NR_EXACT_NEW_CACHE_V1'),'A31NR:CacheSchema','Unexpected prior cache schema.');
    [cache,report]=a31nr_cache_v1('import',cache,old.records,cp.path);
   else,error('A31NR:CacheFormat','Unadmitted cache format.');end
   imports{end+1,1}=struct('pin',basicpin(cp),'format',cp.format,'receipt',report); %#ok<AGROW>
  end
 end
 required=contract.required_job_fields;
 for i=1:numel(jobs)
  budget(clock,config);job=jobs{i};assert(all(isfield(job,required)),'A31NR:JobSchema','Incomplete job.');
  assert(strcmp(job.phase,config.phase)&&job.stages==3&&job.updates_per_stage==600&& ...
   ismember(job.seed,[101 211 307 401 503])&&isscalar(job.replay)&& ...
   ismember(double(job.replay),[0 1])&&numel(job.alpha)==3&&all(isfinite(job.alpha))&& ...
   all(job.alpha>=0&job.alpha<=1),'A31NR:JobBounds','Out-of-protocol job.');
  ix=find(cellfun(@(s)strcmp(s.split_id,job.split_id),splits));assert(isscalar(ix),'A31NR:Split','Unknown split ID.');sp=splits{ix};
  assert(sp.outer_fold==job.outer_fold&&strcmp(sp.inner_design,job.inner_design)&&sp.inner_fold==job.inner_fold,'A31NR:SplitJoin','Job does not match exact split.');
  if strcmp(job.phase,'coarse')
   allowed=cells(contract.coarse_jobs);ix=find(cellfun(@(j)strcmp(j.job_id,job.job_id),allowed));
   assert(isscalar(ix)&&isequaln(orderfields(allowed{ix}),orderfields(job)),'A31NR:CoarseJob','Coarse job differs from frozen contract.');
  end
  if any(strcmp(job.phase,{'coarse','refine'})),assert(strcmp(job.inner_design,'screen2')&&strcmp(job.stream,'ClassIL'),'A31NR:PhaseVisibility','Screen/refine ClassIL inner only.');
  elseif strcmp(job.phase,'confirm'),assert(strcmp(job.inner_design,'confirm3')&&strcmp(job.stream,'ClassIL'),'A31NR:PhaseVisibility','Confirmation ClassIL inner only.');
  elseif strcmp(job.phase,'outer_selected'),assert(strcmp(job.inner_design,'outer'),'A31NR:PhaseVisibility','Final job must use exact outer split.');
  else,error('A31NR:Phase','Unknown phase.');end
  data=a31nr_data_v1(bundle,sp);
  historical=strcmp(job.phase,'outer_selected')&&(isequal(double(job.alpha(:)'),[0 0 0])||isequal(double(job.alpha(:)'),[.5 2/3 .75]));
  if historical
   assert(isKey(legacy,double(job.outer_fold)),'A31NR:LegacyRequired','Exact historical STATIC/legacy outer job must transfer, never rerun.');ll=legacy(double(job.outer_fold));
   [r,cache]=a31nr_reuse_outer_v1(data,job,C,ll.result,ll.pin,cache);
  else
   [r,cache]=a31nr_trajectory_v1(data,job,C,600,false,cache);
   r.historical_full_trajectory_reused=false;r.new_source_prediction_rows=numel(r.predictions);r.historical_prediction_rows_reused=0;
  end
  results{end+1,1}=r;completed{end+1,1}=job.job_id; %#ok<AGROW>
 end
 budget(clock,config);newrecords=cache.records(cache.new_indices);predictions={};
 for i=1:numel(results),predictions=[predictions;results{i}.predictions];end %#ok<AGROW>
 counts=struct('trajectories',numel(results),'logical_stage_instances',3*numel(results), ...
  'actual_new_stagefits',numel(newrecords),'actual_optimizer_updates',600*numel(newrecords), ...
  'logical_prediction_rows',numel(predictions),'new_source_prediction_rows',sum(cellfun(@(r)r.new_source_prediction_rows,results)), ...
  'historical_prediction_rows_reused',sum(cellfun(@(r)r.historical_prediction_rows_reused,results)), ...
  'new_fisher_jobs',0,'physical_validation',0);
 assert(counts.actual_new_stagefits==sum(cellfun(@(r)r.actual_new_stagefits,results)),'A31NR:FitCounts','Actual fit count differs from job references.');
 result=struct('schema','A31_NR_BATCH_RESULT_V1','status','PRODUCER_COMPLETE_PENDING_INDEPENDENT_AUDIT', ...
  'batch_id',config.batch_id,'phase',config.phase,'started',started,'completed',times(), ...
  'config',config,'counts',counts,'cache_imports',{imports},'jobs',{results}, ...
  'source_previously_exposed',true,'new_blind_test',false,'selection_performed',false, ...
  'elapsed_before_serialization_seconds',toc(clock));
 newcache=struct('schema','A31_NR_EXACT_NEW_CACHE_V1','batch_id',config.batch_id,'phase',config.phase, ...
  'status','PENDING_INDEPENDENT_SAVED_AUDIT','records',{newrecords},'count',numel(newrecords), ...
  'inherited_records_not_recopied',numel(cache.records)-numel(newrecords));
 writejson(fullfile(outDir,'nr_batch_result_v1.json'),result,config.max_json_bytes);
 writejson(fullfile(outDir,'nr_batch_new_fit_cache_v1.json'),newcache,config.max_json_bytes);
 writecsv(fullfile(outDir,'nr_batch_predictions_v1.csv'),predictions);
 for i=1:numel(allpins),verify(allpins(i));end
 budget(clock,config);assert(bytes(outDir)<config.max_total_output_bytes,'A31NR:OutputCap','Output budget exceeded.');
 receipt=struct('schema','A31_NR_BATCH_PRODUCER_RECEIPT_V1','status',result.status,'complete',true, ...
  'phase',config.phase,'batch_id',config.batch_id,'completed_job_ids',{completed},'counts',counts, ...
  'elapsed_seconds',toc(clock),'result_pin',pin(fullfile(outDir,'nr_batch_result_v1.json')), ...
  'new_cache_pin',pin(fullfile(outDir,'nr_batch_new_fit_cache_v1.json')), ...
  'predictions_pin',pin(fullfile(outDir,'nr_batch_predictions_v1.csv')),'config',config);
 writejson(fullfile(outDir,'nr_batch_producer_receipt_v1.json'),receipt,min(config.max_json_bytes,1000000));
 assert(bytes(outDir)<=config.max_total_output_bytes,'A31NR:OutputCap','Final output budget exceeded.');
catch err
 failure=struct('schema','A31_NR_FAILED_BATCH_RECEIPT_V1','status','FAILED_ATTEMPT_NOT_ACCEPTED', ...
  'identifier',err.identifier,'message',err.message,'stack',err.stack,'started',started, ...
  'finished',times(),'completed_job_ids',{completed},'complete_trajectories_in_memory',numel(results), ...
  'new_stagefits_in_memory',numel(cache.new_indices),'source_acceptance',false, ...
  'note','No job is silently removed or retried; preserve attempt and require a separate review/repair decision.');
 writejson(fullfile(outDir,'nr_batch_FAILED_receipt_v1.json'),failure,1000000);rethrow(err);
end
end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function s=read(p),s=jsondecode(fileread(p));end
function c=cells(x),if iscell(x),c=x;elseif isempty(x),c={};else,c=num2cell(x);end,end
function p=basicpin(p),p=struct('path',p.path,'bytes',p.bytes,'sha256',p.sha256);end
function a=append(a,r),if isempty(a),a=r;else,a(end+1)=r;end,end
function verify(p)
d=dir(p.path);assert(isscalar(d)&&d.bytes==p.bytes&&strcmp(sha(p.path),p.sha256),'A31NR:Pin','Pinned file changed: %s',p.path);
end
function p=pin(path),d=dir(path);p=struct('path',path,'bytes',d.bytes,'sha256',sha(path));end
function h=sha(path)
f=fopen(path,'rb');assert(f>=0,'A31NR:Read','Cannot read pinned file.');c=onCleanup(@()fclose(f));b=fread(f,Inf,'*uint8');md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));
end
function budget(t,c),assert(toc(t)<=c.max_seconds,'A31NR:TimeCap','Batch time budget exceeded.');end
function n=bytes(path),d=dir(path);n=sum([d(~[d.isdir]).bytes]);end
function t=times()
t=struct('utc',char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSSXXX')), ...
 'istanbul',char(datetime('now','TimeZone','Europe/Istanbul','Format','yyyy-MM-dd''T''HH:mm:ss.SSSXXX')));
end
function writejson(path,value,cap)
assert(~isfile(path),'A31NR:NoOverwrite','Existing output preserved.');b=unicode2native(jsonencode(value,'ConvertInfAndNaN',true),'UTF-8');assert(numel(b)<=cap,'A31NR:JSONCap','Serialized JSON cap exceeded.');f=fopen(path,'wb');assert(f>=0,'A31NR:Write','Cannot create output.');c=onCleanup(@()fclose(f));assert(fwrite(f,b,'uint8')==numel(b),'A31NR:Write','Short write.');
end
function writecsv(path,P)
f=fopen(path,'w','n','UTF-8');assert(f>=0,'A31NR:Write','Cannot create prediction CSV.');c=onCleanup(@()fclose(f));
headers={'job_id','phase','split_id','outer_fold','seed','replay','stream','schedule_id','stage','task','parentindex','parentrow','group_order','truth','eligible1','eligible2','eligible3','eligible4','label','gap','tie','valid','failure','failure_reason','score1','score2','score3','score4','distance1','distance2','distance3','distance4','Z1','Z2','output1','output2','output3','output4','output5','output6','output7','output8','logit1','logit2','logit3','logit4','logit5','logit6','logit7','logit8','fit_sha256','historical_payload_reused'};
fprintf(f,'%s\n',strjoin(headers,','));
for i=1:numel(P)
 r=P{i};v={quote(r.job_id),quote(r.phase),quote(r.split_id),num(r.outer_fold),num(r.seed),num(r.replay),quote(r.stream),quote(r.schedule_id),num(r.stage),num(r.task),num(r.parentindex),quote(r.parentrow),num(r.group_order),num(r.truth)};
 score=nan(1,4);dist=score;score(r.eligible)=r.scores;dist(r.eligible)=r.distances;
 for z=double(ismember(1:4,r.eligible)),v{end+1}=num(z);end %#ok<AGROW>
 v=[v,{num(r.label),num(r.gap),num(r.tie),num(r.valid),num(r.failure),quote(r.failure_reason)}];
 for z=[score dist r.Z r.outputs r.logits],v{end+1}=num(z);end %#ok<AGROW>
 reused=isfield(r,'historical_payload_reused')&&r.historical_payload_reused;v=[v,{quote(r.fit_sha256),num(reused)}];fprintf(f,'%s\n',strjoin(v,','));
end
end
function s=num(x),if isnan(x),s='';else,s=sprintf('%.17g',double(x));end,end
function s=quote(x),s=['"' strrep(char(x),'"','""') '"'];end
