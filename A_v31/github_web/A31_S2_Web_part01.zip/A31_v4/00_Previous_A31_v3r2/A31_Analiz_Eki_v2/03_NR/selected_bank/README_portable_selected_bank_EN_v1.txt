Portable selected NR state bank

100 selected outer jobs (5 outer folds x 2 replay settings x 5 numerical initializations x 2 streams), with 300 saved stage records and 5460 saved stage-query prediction rows. This export copies accepted saved data only: no training, model forward pass, new simulation, scientific selection, or measurement was performed.

selected_models_v1.json retains each saved job, normalizer, initial theta/m/v/t, incoming and final theta/m/v/t for each stage, detached target cache, current/effective-replay and carried replay parent IDs, training spec, stage receipt and fit reference. Historical and new/aliased flags and logical/actual work counters remain distinct. Source JSON array shapes and numeric values are preserved after JSON binary64 roundtrip.

selected_predictions_v1.csv preserves the original 52 field names and every saved cell string in original batch/job/prediction order. Empty cells, historical missing logits/outputs, ties and failures are preserved. saved_prediction_provenance_v1.csv maps every row to its original result, job and prediction position and source CSV row.

Original absolute protocol/configuration paths are omitted. Source descriptors use SHA-256, size, original basename and a content-derived source ID; source_job_field_mapping_v1.json documents each path transformation. The derived JSON/CSV files have new hashes and are not claimed to be byte-identical to source JSONs. Original 13 MATLAB code files are copied unchanged under MIT; the numerical arrays and authored scientific outputs use CC BY 4.0 within the authors rights. Original source and method notices remain applicable. No private PDFs or proprietary runtimes are included.

This is a saved-state bank, not a turnkey retraining environment: original bounded launch/configuration/admission files and runtime are not included. The code files preserve their original scoped interfaces. Use the full accepted protocol/input and phase lineage from the accompanying research package for a faithful retraining workflow. This export adds no new physical or Simulink validation and does not turn previously exposed records into a blind test.
