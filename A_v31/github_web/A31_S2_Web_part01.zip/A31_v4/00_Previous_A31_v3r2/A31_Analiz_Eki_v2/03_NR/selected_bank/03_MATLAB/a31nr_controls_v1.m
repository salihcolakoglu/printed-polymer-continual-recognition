function receipt=a31nr_controls_v1(outDir,config)
% Artificial controls and optional finite600-update/3-stage timing specimen.
if nargin<2,config=struct('synthetic_benchmark',true);end
outDir=char(java.io.File(char(outDir)).getCanonicalPath());root=fileparts(fileparts(mfilename('fullpath')));
assert(startsWith(lower(outDir),lower([root filesep '05_Audit' filesep])), ...
 'A31NR:ControlScope','Controls may write only a new version audit child.');
if isfolder(outDir),dd=dir(outDir);assert(~any(~ismember({dd.name},{'.','..'})),'A31NR:ExistingOutput','Preserve prior outputs.');else,mkdir(outDir);end
checks=struct('id',{},'pass',{});clock=tic;
[bundle,sp]=a31nr_fixture_v1();data=a31nr_data_v1(bundle,sp(1));C=bundle.codebook_WH8;old=a29cl_data('fixture');
for stream={'TaskIL','ClassIL'}
 for s=1:3
  a=data.current(stream{1},s);b=old.current(1,stream{1},s);
  check(isequaln(a,b),sprintf('CF_DATA_%s_s%d',stream{1},s));
  a=data.query(stream{1},s);b=old.query(1,stream{1},s);
  check(isequaln(a,b),sprintf('CF_QUERY_%s_s%d',stream{1},s));
 end
end
cur=data.current('ClassIL',1);state=a29cl_math('init',8,101);
for alpha=[0 .5 1]
 q=a31nr_targets_v1(state.theta,cur,C,alpha);
 check(all(q.q(:)>=0&q.q(:)<=1)&&all(isfinite(q.q),'all'),sprintf('TARGET_BOUNDS_%g',alpha));
 check(isequal(q.current_parentindex,cur.parentindex)&&isequal(q.current_parentrow,cur.parentrow),sprintf('CACHE_CURRENT_IDS_%g',alpha));
 [loss,g]=a29cl_math('bce',state.theta,cur.Z,q.q,8);numeric=zeros(size(g));h=1e-6;
 for p=1:numel(g)
  plus=state.theta;minus=state.theta;plus(p)=plus(p)+h;minus(p)=minus(p)-h;
  lp=a29cl_math('bce',plus,cur.Z,q.q,8);lm=a29cl_math('bce',minus,cur.Z,q.q,8);numeric(p)=(lp-lm)/(2*h);
 end
 check(isfinite(loss)&&max(abs(numeric-g))<5e-8,sprintf('DETACHED_BCE_GRADIENT_%g',alpha));
 frozen=q.q;changed=a29cl_math('step',state,g); %#ok<NASGU>
 check(isequal(q.q,frozen)&&q.recomputed_during_updates==false,sprintf('CACHE_IMMUTABLE_%g',alpha));
 if alpha==0,check(isempty(q.teacher)&&isempty(q.teacher_logits)&&q.teacher_forward_rows==0&&isequal(q.q,C(cur.y,:)),'STATIC_ZERO_NO_TEACHER');end
 if alpha==1
  check(all(g==0),'ALPHA_ONE_INITIAL_DATA_GRADIENT_ZERO');
  term=struct('kind','bce','Z',cur.Z,'target',q.q,'mask',[],'T',1,'weight',1);
  [~,fullg,comp]=a29cl_math('objective',state.theta,term,8,struct('theta',{},'F',{}),0);
  check(any(fullg~=0)&&comp.L2>0,'ALPHA_ONE_L2_REMAINS');
 end
end
for alpha=[-eps 1+eps Inf NaN]
 check(rejects(@()a31nr_targets_v1(state.theta,cur,C,alpha),'A31NR:Alpha'),sprintf('BAD_ALPHA_%g',alpha));
end
bad=cur;bad.kind='EVALUATION_ONLY';check(rejects(@()a31nr_targets_v1(state.theta,bad,C,.5),'A31NR:TargetScope'),'DEV_CACHE_REJECTED');
[fb,fs]=a31nr_fixture_v1(struct('future_shift',1000));fd=a31nr_data_v1(fb,fs(1));
[hb,hs]=a31nr_fixture_v1(struct('heldout_shift',500));hd=a31nr_data_v1(hb,hs(1));
for stream={'TaskIL','ClassIL'}
 for s=1:2
  check(isequaln(data.current(stream{1},s),fd.current(stream{1},s)),sprintf('NO_FUTURE_%s_s%d',stream{1},s));
  check(isequaln(data.current(stream{1},s),hd.current(stream{1},s)),sprintf('NO_HELD_%s_s%d',stream{1},s));
 end
end
q1=a31nr_targets_v1(state.theta,data.current('ClassIL',2),C,.5);q2=a31nr_targets_v1(state.theta,fd.current('ClassIL',2),C,.5);
check(isequaln(q1,q2),'TARGET_NO_FUTURE_CACHE');
q2=a31nr_targets_v1(state.theta,hd.current('ClassIL',2),C,.5);check(isequaln(q1,q2),'TARGET_NO_HELD_CACHE');
legacy=[.5 2/3 .75];parity=struct([]);
for stream={'TaskIL','ClassIL'}
 for replay=[false true]
  job=makejob('CONTROL_LEGACY',1,stream{1},replay,legacy);
  [r,cache]=a31nr_trajectory_v1(data,job,C,3,true,a31nr_cache_v1('new'));
  gold=legacy_literal(old,1,stream{1},replay,C,3);
  for s=1:3
   check(isequaln(r.stages{s}.final_state,gold{s}.state),sprintf('LEGACY_STATE_%s_R%d_s%d',stream{1},replay,s));
   check(isequaln(r.stages{s}.spec,gold{s}.spec),sprintf('LEGACY_SPEC_%s_R%d_s%d',stream{1},replay,s));
   check(isequaln(r.stages{s}.target_cache.q,gold{s}.q),sprintf('LEGACY_TARGET_%s_R%d_s%d',stream{1},replay,s));
  end
  [alias,cache]=a31nr_trajectory_v1(data,job,C,3,true,cache);
  check(all(cellfun(@(x)x.fit_reference.aliased,alias.stages))&&isequaln(alias.stages{3}.final_state,r.stages{3}.final_state),sprintf('FULL_JOB_EXACT_ALIAS_%s_R%d',stream{1},replay));
  decoded=jsondecode(jsonencode(cache.records));c2=a31nr_cache_v1('new');[c2,imp]=a31nr_cache_v1('import',c2,decoded,'ARTIFICIAL_JSON_ROUNDTRIP');
  [roundtrip,~]=a31nr_trajectory_v1(data,job,C,3,true,c2);
  check(imp.records_added==3&&all(cellfun(@(x)x.fit_reference.aliased,roundtrip.stages))&&isequaln(roundtrip.stages{3}.final_state,r.stages{3}.final_state),sprintf('CACHE_ROUNDTRIP_%s_R%d',stream{1},replay));
  parity=append(parity,struct('stream',stream{1},'replay',replay,'stages_compared',3,'updates_per_stage',3,'exact_state_spec_target',true));
 end
end
job=makejob('CONTROL_STATIC',1,'ClassIL',true,[0 0 0]);
[static,~]=a31nr_trajectory_v1(data,job,C,3,true,a31nr_cache_v1('new'));
gold=legacy_static_literal(old,1,'ClassIL',true,C,3);
for s=1:3,check(isequaln(static.stages{s}.final_state,gold{s}.state)&&isequaln(static.stages{s}.spec,gold{s}.spec)&&isempty(static.stages{s}.target_cache.teacher),sprintf('STATIC_PARITY_s%d',s));end
cache=a31nr_cache_v1('new');job=makejob('CONTROL_FIRSTALPHA',1,'ClassIL',false,[.5 .5 .5]);
[r,cache]=a31nr_trajectory_v1(data,job,C,1,true,cache);job.alpha=[.5 2/3 .75];job.job_id='CONTROL_LEGACY_SHARED_FIRST';
[q,~]=a31nr_trajectory_v1(data,job,C,1,true,cache);
check(q.stages{1}.fit_reference.aliased&&isequaln(r.stages{1}.final_state,q.stages{1}.final_state),'SAME_FIRST_ALPHA_EXACT_STAGE_ALIAS');
% New nested split: three disjoint roles (innerTRAIN, innerDEV, outerTEST).
% Counterfactuals are arithmetic fixtures, never the104 published inputs.
ins=sp(1);ins.split_id='ART_O01_screen2_I01';ins.inner_design='screen2';ins.inner_fold=1;
trainGroups=unique([bundle.records(ins.train_indices1).group_order]);devGroups=trainGroups(1:10);
allTrain=ins.train_indices1;ins.dev_indices1=allTrain(ismember([bundle.records(allTrain).group_order],devGroups));
ins.train_indices1=allTrain(~ismember([bundle.records(allTrain).group_order],devGroups));
ins.normalizer_fit_indices1=ins.train_indices1([bundle.records(ins.train_indices1).label]<=2);
id=a31nr_data_v1(bundle,ins);ix=double(ins.normalizer_fit_indices1(:));allX=vertcat(bundle.records.X);
check(isequal(id.normalizer.mean,mean(allX(ix,:),1))&&isequal(id.normalizer.sd,std(allX(ix,:),0,1))&& ...
 isequal(id.normalizer.train_parentindex,uint64(ix))&&~id.normalizer.saved_outer_values_used,'INNER_SCALER_ONLY_INITIAL_TRAIN');
devBundle=bundle;outerBundle=bundle;futureBundle=bundle;
for j=ins.dev_indices1(:)',devBundle.records(j).X=devBundle.records(j).X+[500 700];end
for j=ins.outer_test_indices1(:)',outerBundle.records(j).X=outerBundle.records(j).X+[300 900];end
futureRows=ins.train_indices1([bundle.records(ins.train_indices1).label]==4);
for j=futureRows(:)',futureBundle.records(j).X=futureBundle.records(j).X+[1000 1000];end
dd=a31nr_data_v1(devBundle,ins);od=a31nr_data_v1(outerBundle,ins);ff=a31nr_data_v1(futureBundle,ins);
check(isequaln(id.normalizer,dd.normalizer),'INNER_DEV_CANNOT_CHANGE_SCALER');
ijob=makejob('ART_INNER_COUNTERFACTUAL',1,'ClassIL',true,legacy);ijob.split_id=ins.split_id;ijob.inner_design='screen2';ijob.inner_fold=1;
[ir,~]=a31nr_trajectory_v1(id,ijob,C,3,true,a31nr_cache_v1('new'));
[dr,~]=a31nr_trajectory_v1(dd,ijob,C,3,true,a31nr_cache_v1('new'));
for s=1:3,check(isequaln(id.current('ClassIL',s),dd.current('ClassIL',s))&&same_training(ir.stages{s},dr.stages{s}),sprintf('INNER_DEV_NO_TARGET_REPLAY_OPTIMIZER_s%d',s));end
baseQuery=id.query('ClassIL',3);devQuery=dd.query('ClassIL',3);
check(~isequaln(baseQuery.Z,devQuery.Z),'INNER_DEV_PERTURBATION_REACHES_EVALUATOR');
check(isequaln(id.normalizer,od.normalizer),'OUTER_TEST_CANNOT_CHANGE_INNER_SCALER');
[outerRun,~]=a31nr_trajectory_v1(od,ijob,C,3,true,a31nr_cache_v1('new'));
for s=1:3,check(isequaln(id.current('ClassIL',s),od.current('ClassIL',s))&&same_training(ir.stages{s},outerRun.stages{s}),sprintf('OUTER_TEST_NO_INNER_TARGET_REPLAY_OPTIMIZER_s%d',s));end
check(isequaln(id.query('ClassIL',3),od.query('ClassIL',3)),'OUTER_TEST_ABSENT_FROM_INNER_EVALUATOR');
[fr,~]=a31nr_trajectory_v1(ff,ijob,C,3,true,a31nr_cache_v1('new'));
for s=1:2,check(isequaln(id.current('ClassIL',s),ff.current('ClassIL',s))&&same_training(ir.stages{s},fr.stages{s}),sprintf('INNER_FUTURE_TRAIN_NO_EARLY_CACHE_STATE_s%d',s));end
check(isequaln(id.query('ClassIL',3),ff.query('ClassIL',3)),'FUTURE_TRAIN_NOT_IN_INNER_EVALUATOR');
zeroBundle=bundle;hugeBundle=bundle;
for k=1:numel(ix),j=ix(k);zeroBundle.records(j).X(1)=1;hugeBundle.records(j).X(1)=(-1)^k*1.79e308;end
check(rejects(@()a31nr_data_v1(zeroBundle,ins),'A31NR:ScalerSTOP'),'INNER_ZERO_SD_STOP');
check(rejects(@()a31nr_data_v1(hugeBundle,ins),'A31NR:ScalerSTOP'),'INNER_NONFINITE_SD_STOP');
benchmark=struct('performed',false);benchfiles=struct([]);
if isfield(config,'synthetic_benchmark')&&isequal(config.synthetic_benchmark,true)
 bd=a31nr_data_v1(bundle,sp(2));job=makejob('ARTIFICIAL_600_BENCHMARK',2,'ClassIL',true,legacy);
 bt=tic;[br,bc]=a31nr_trajectory_v1(bd,job,C,600,true,a31nr_cache_v1('new'));compute=toc(bt);
 bt=tic;rb=unicode2native(jsonencode(br,'ConvertInfAndNaN',true),'UTF-8');cb=unicode2native(jsonencode(struct('schema','A31_NR_EXACT_NEW_CACHE_V1','records',{bc.records}),'ConvertInfAndNaN',true),'UTF-8');encode=toc(bt);
 assert(numel(rb)+numel(cb)<25000000,'A31NR:ControlBytes','Artificial serialization exceeds control cap.');
 writebytes(fullfile(outDir,'nr_control_benchmark_result_v1.json'),rb);writebytes(fullfile(outDir,'nr_control_benchmark_cache_v1.json'),cb);
 check(all(cellfun(@(s)s.stage_receipt.updates==600,br.stages))&&br.source_training_stages==0,'BENCHMARK_SYNTHETIC_1800_UPDATES');
 check(all(cellfun(@(p)p.valid,br.predictions)),'BENCHMARK_ALL_QUERY_VALID');
 benchmark=struct('performed',true,'source_rows_read',0,'trajectories',1,'synthetic_stagefits',3, ...
  'synthetic_updates',1800,'outer_groups_train',21,'first_current_rows',42, ...
  'stream','ClassIL','replay',true,'compute_seconds',compute,'serialization_seconds',encode, ...
  'trajectory_json_bytes',numel(rb),'new_fit_cache_json_bytes',numel(cb), ...
  'per_stage_seconds',cellfun(@(s)s.stage_receipt.elapsed_seconds,br.stages), ...
  'resource_meaning','Measured artificial implementation workload, not guaranteed source ETA or physical evidence.');
 benchfiles=struct('result_name','nr_control_benchmark_result_v1.json','cache_name','nr_control_benchmark_cache_v1.json');
end
receipt=struct('schema','A31_NR_SOURCE_FREE_CONTROL_RECEIPT_V1','status','PASS_SOURCE_FREE_CONTROLS', ...
 'complete',true,'checks',checks,'passed_checks',numel(checks),'failed_checks',0, ...
 'source_rows_read',0,'source_training',0,'source_predictions',0,'legacy_literal_parity',parity, ...
 'benchmark',benchmark,'benchmark_files',benchfiles,'elapsed_seconds',toc(clock), ...
 'scope','Artificial math, cache, access, parity and bounded timing only; no source run admitted.');
writebytes(fullfile(outDir,'nr_controls_receipt_v1.json'),unicode2native(jsonencode(receipt,'ConvertInfAndNaN',true),'UTF-8'));
 function check(ok,id)
  assert(isscalar(ok)&&logical(ok),'A31NR:ControlFailure','Control failed: %s',id);checks(end+1)=struct('id',id,'pass',true);
 end
end
function job=makejob(id,f,stream,replay,alpha)
job=struct('job_id',id,'phase','control','split_id',sprintf('ART_O%02d_outer_I00',f),'outer_fold',f, ...
 'inner_design','outer','inner_fold',0,'seed',101,'replay',logical(replay),'stream',stream,'schedule_id',id,'alpha',alpha);
end
function stages=legacy_literal(data,fold,stream,replay,C,u)
stages=literal(data,fold,stream,replay,C,u,true);
end
function stages=legacy_static_literal(data,fold,stream,replay,C,u)
stages=literal(data,fold,stream,replay,C,u,false);
end
function stages=literal(data,fold,stream,replay,C,u,neg)
state=a29cl_math('init',8,101);B=a29cl_data('replay_empty');stages=cell(3,1);aa=[.5 2/3 .75];
for stage=1:3
 cur=data.current(fold,stream,stage);incoming=state;view=a29cl_data('replay_view',B,cur);q=C(cur.y,:);
 if neg
  logits=a29cl_math('forward',incoming.theta,cur.Z,8);p=zeros(size(logits));pos=logits>=0;p(pos)=1./(1+exp(-logits(pos)));e=exp(logits(~pos));p(~pos)=e./(1+e);q=(1-aa(stage))*q+aa(stage)*p;
 end
 terms=struct('kind','bce','Z',cur.Z,'target',q,'mask',[],'T',1,'weight',1);
 if replay&&~isempty(view.y),terms.weight=.5;terms(2)=struct('kind','bce','Z',view.Z,'target',C(view.y,:),'mask',[],'T',1,'weight',.5);end
 spec=struct('D',8,'terms',terms,'anchors',struct('theta',{},'F',{}),'ewc_lambda',0,'updates',u,'control_only',true);
 [state,~]=a29cl_stage(incoming,spec);if replay,p=a29cl_data('replay_commit',B,cur,fold,stage);B=p.buffer;end
 stages{stage}=struct('state',state,'spec',spec,'q',q);
end
end
function ok=rejects(f,id),ok=false;try,f();catch err,ok=strcmp(err.identifier,id);end,end
function ok=same_training(a,b)
fields={'current_parentindex','current_parentrow','incoming_state','final_state', ...
 'target_cache','replay_before','effective_replay','replay_after','replay_admission','spec'};
ok=true;for k=1:numel(fields),ok=ok&&isequaln(a.(fields{k}),b.(fields{k}));end
end
function a=append(a,r),if isempty(a),a=r;else,a(end+1)=r;end,end
function writebytes(path,b)
assert(~isfile(path),'A31NR:NoOverwrite','Preserve previous control outputs.');fid=fopen(path,'wb');assert(fid>=0,'A31NR:Write','Cannot write control output.');cl=onCleanup(@()fclose(fid));assert(fwrite(fid,b,'uint8')==numel(b),'A31NR:Write','Short write.');
end
