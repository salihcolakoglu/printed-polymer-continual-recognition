function receipt=a31fr_reuse_controls_v1(versionRoot,outDir,config)
% Only the newF25 complete-copy path is exercised. No source records or old
%108/89 control rerun. One3stage x3update synthetic trajectory =9updates.
versionRoot=canonical(versionRoot);outDir=canonical(outDir);
assert(startsWith(lower(outDir),lower([versionRoot filesep '05_Audit' filesep])),'A31FR:ControlScope','New audit output required.');
assert(strcmp(config.mode,'control')&&config.source_run_authorized==false,'A31FR:ControlOnly','Source forbidden.');
if isfolder(outDir),d=dir(outDir);assert(~any(~ismember({d.name},{'.','..'})),'A31FR:Existing','Preserve earlier outputs.');else,mkdir(outDir);end
[bundle,splits]=a31nr_fixture_v1();data=a31nr_data_v1(bundle,splits(2));C=bundle.codebook_WH8;
job=struct('job_id','ARTIFICIAL_F25_FULL_RANGE_COPY','phase','full_range_response','split_id',splits(2).split_id,'outer_fold',2,'inner_design','outer','inner_fold',0,'seed',101,'replay',true,'stream','ClassIL','schedule_id','F25','alpha',[.25 .25 .25],'updates_per_stage',600,'stages',3);
checks=struct('id',{},'pass',{});cache=a31nr_cache_v1('new');[saved,cache]=a31nr_trajectory_v1(data,job,C,3,true,cache);
saved.new_source_prediction_rows=0;saved.historical_prediction_rows_reused=0;
saved.synthetic_prediction_rows=numel(saved.predictions);
check(saved.source_free_control&&saved.source_training_stages==0&&saved.actual_optimizer_updates==9,'F25_ONLY_NINE_SYNTHETIC_UPDATES');
key=cellfun(@(s)s.fit_reference.job_sha256,saved.stages,'UniformOutput',false);
entry=struct('job_id',job.job_id,'source_kind','SYNTHETIC_F25_ONLY_CONTROL','source_job_id',job.job_id,'source_fit_SHA256',{key});
roundtrip=jsondecode(jsonencode(saved));before=numel(cache.new_indices);newjob=job;newjob.job_id='ARTIFICIAL_F25_COPY_DESTINATION';
[copied,cache]=a31fr_reuse_full_v1(data,newjob,C,roundtrip,entry,cache,true);
check(numel(cache.new_indices)==before&&copied.actual_new_stagefits==0&&copied.actual_optimizer_updates==0,'COPY_CREATES_ZERO_NEW_FITS_UPDATES');
check(copied.new_source_prediction_rows==0&&copied.copy_work.new_teacher_forward_rows==0&&copied.copy_work.new_query_forward_rows==0,'COPY_CREATES_ZERO_FORWARD_ROWS');
check(copied.source_execution_counts.actual_optimizer_updates==9&&copied.source_execution_counts.source_training_stages==0,'SOURCE_HISTORY_SEPARATE_FROM_CURRENT_ZERO');
for s=1:3
 a=saved.stages{s};b=copied.stages{s};
 check(flat(a.final_state.theta,b.final_state.theta)&&flat(a.final_state.m,b.final_state.m)&&flat(a.final_state.v,b.final_state.v)&&a.final_state.t==b.final_state.t,sprintf('STATE_EXACT_s%d',s));
 check(flat(a.target_cache.q,b.target_cache.q)&&flat(a.target_cache.teacher,b.target_cache.teacher)&&flat(a.target_cache.teacher_logits,b.target_cache.teacher_logits),sprintf('F25_DETACHED_CACHE_EXACT_s%d',s));
 check(b.fit_reference.aliased&&strcmp(b.source_fit_reference.job_sha256,a.fit_reference.job_sha256),sprintf('COPY_REFERENCE_SEPARATE_s%d',s));
end
for i=1:numel(saved.predictions)
 a=saved.predictions{i};b=copied.predictions{i};
 check(flat(a.outputs,b.outputs)&&flat(a.logits,b.logits)&&flat(a.distances,b.distances)&&flat(a.scores,b.scores)&&a.label==b.label&&a.tie==b.tie&&a.gap==b.gap,sprintf('QUERY_PAYLOAD_EXACT_%d',i));
 check(b.source_prediction_index1==i&&strcmp(b.source_job_id,job.job_id)&&strcmp(b.job_id,newjob.job_id),sprintf('QUERY_POSITION_MAP_%d',i));
end
check(rejects(@()a31fr_reuse_full_v1(data,newjob,C,roundtrip,entry,a31nr_cache_v1('new'),true),'A31FR:FullCacheMissing'),'MISSING_CACHE_STOP_NO_FIT');
check(rejects(@()a31fr_reuse_full_v1(data,newjob,C,roundtrip,entry,cache,false),'A31FR:FullUpdates'),'ARTIFICIAL_THREE_UPDATES_REJECTED_IN_SOURCE_MODE');
bad=roundtrip;bad.predictions(1).truth=4;
check(rejects(@()a31fr_reuse_full_v1(data,newjob,C,bad,entry,cache,true),'A31FR:FullQueryIdentity'),'CHANGED_QUERY_TARGET_REJECTED');
bad=roundtrip;bad.normalizer.mean(1)=bad.normalizer.mean(1)+1;
check(rejects(@()a31fr_reuse_full_v1(data,newjob,C,bad,entry,cache,true),'A31FR:FullNormalizer'),'CHANGED_SCALER_REJECTED');
vectors=[0 0 0;.25 .25 .25;.5 .5 .5;.75 .75 .75;.9 .9 .9;1 1 1;0 .5 1;1 .5 0];
for i=1:8
 jj=job;jj.alpha=vectors(i,:);ct=struct('jobs',jj);a31fr_job_gate_v1(jj,ct);check(true,sprintf('LITERAL_CLOSED_VECTOR_%d',i));
end
bad=job;bad.alpha=[1+eps 1 1];check(rejects(@()a31fr_job_gate_v1(bad,struct('jobs',bad)),'A31FR:Vector'),'ALPHA_ABOVE_ONE_REJECTED');
bad=job;bad.alpha=[.1 .1 .1];check(rejects(@()a31fr_job_gate_v1(bad,struct('jobs',bad)),'A31FR:Vector'),'UNDECLARED_INTERIOR_VECTOR_REJECTED');
bad=job;bad.phase='outer_selected';check(rejects(@()a31fr_job_gate_v1(bad,struct('jobs',bad)),'A31FR:FixedScope'),'OLD_SELECTED_PHASE_REJECTED');
bad=job;bad.seed=999;check(rejects(@()a31fr_job_gate_v1(bad,struct('jobs',bad)),'A31FR:FixedScope'),'UNDECLARED_SEED_REJECTED');
bad=job;bad.job_id='NOT_LITERAL';check(rejects(@()a31fr_job_gate_v1(bad,struct('jobs',job)),'A31FR:LiteralJob'),'NONLITERAL_JOB_REJECTED');
receipt=struct('schema','A31_FR_FULL_REUSE_CONTROL_RECEIPT_V1','status','PASS_SOURCE_FREE_FULL_REUSE_CONTROLS','complete',true,'passed_checks',numel(checks),'failed_checks',0,'checks',checks,'source_rows_read',0,'source_training',0,'source_predictions',0,'synthetic_new_trajectories',1,'synthetic_new_stagefits',3,'synthetic_optimizer_updates',9,'copier_new_fits',0,'copier_new_teacher_forward_rows',0,'copier_new_query_forward_rows',0,'old108_89_controls_rerun',false,'alpha_one_old_gradient_proof_retained_not_repeated',true);
write(fullfile(outDir,'fr_full_reuse_controls_receipt_v1.json'),receipt);
write(fullfile(outDir,'fr_synthetic_F25_original_v1.json'),saved);
write(fullfile(outDir,'fr_synthetic_F25_copied_v1.json'),copied);
 function check(ok,id),assert(isscalar(ok)&&logical(ok),'A31FR:ControlFailure','Failed %s',id);checks(end+1)=struct('id',id,'pass',true);end
end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function ok=flat(a,b),ok=isequaln(double(a(:)),double(b(:)));end
function ok=rejects(f,id),ok=false;try,f();catch e,ok=strcmp(e.identifier,id);end,end
function write(p,x)
assert(~isfile(p));b=unicode2native(jsonencode(x,'ConvertInfAndNaN',true),'UTF-8');assert(numel(b)<10000000);f=fopen(p,'wb');assert(f>=0);c=onCleanup(@()fclose(f));assert(fwrite(f,b,'uint8')==numel(b));
end
