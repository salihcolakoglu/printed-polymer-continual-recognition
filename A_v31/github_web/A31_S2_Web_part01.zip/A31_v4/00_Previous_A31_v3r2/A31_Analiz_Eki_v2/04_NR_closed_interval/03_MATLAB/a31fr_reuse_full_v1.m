function [R,cache]=a31fr_reuse_full_v1(data,job,C,saved,entry,cache,control_only)
% Copy an accepted complete trajectory. Never forward/decode/fit a model.
% In source mode updates must be600. A separate explicit control-only branch
% permits the new9-update artificial F25 transfer test and is never source.
assert(isscalar(control_only)&&islogical(control_only),'A31FR:ControlFlag','Explicit logical mode required.');
assert(strcmp(job.phase,'full_range_response')&&strcmp(job.inner_design,'outer')&&job.inner_fold==0, ...
 'A31FR:FullScope','Only exact fixed outer jobs may transfer.');
assert(isequal(double(saved.job.alpha(:)'),double(job.alpha(:)'))&& ...
 saved.job.outer_fold==job.outer_fold&&saved.job.seed==job.seed&& ...
 saved.job.replay==job.replay&&strcmp(saved.job.stream,job.stream), ...
 'A31FR:FullTuple','Saved numerical trajectory differs.');
updates=600;if control_only,updates=3;end
assert(saved.source_free_control==control_only&&saved.all_updates_per_stage==updates, ...
 'A31FR:FullUpdates','Source600 and artificial3-update trajectories cannot mix.');
assert(eqn(saved.normalizer.mean,data.normalizer.mean)&&eqn(saved.normalizer.sd,data.normalizer.sd)&& ...
 saved.normalizer.n==data.normalizer.n&&eqn(saved.normalizer.train_parentindex,data.normalizer.train_parentindex), ...
 'A31FR:FullNormalizer','Saved TRAIN scaler differs.');
S=cells(saved.stages);P=cells(saved.predictions);assert(numel(S)==3,'A31FR:FullStages','Three complete stages required.');
state=typed(saved.initial_state);B=a29cl_data('replay_empty');outS=cell(3,1);newBefore=numel(cache.new_indices);clock=tic;
for s=1:3
 st=S{s};cur=data.current(char(job.stream),s);view=a29cl_data('replay_view',B,cur);memory=[];if job.replay,memory=view;end
 assert(st.stage==s&&st.alpha==job.alpha(s)&&eqn(st.current_parentindex,cur.parentindex)&& ...
  eqn(st.incoming_state,state)&&eqn(st.target_cache.current_parentindex,cur.parentindex), ...
  'A31FR:FullCurrent','Saved current IDs or incoming state differ.');
 q=st.target_cache;assert(q.alpha==job.alpha(s)&&eqn(q.hard_targets,C(cur.y,:))&& ...
  all(isfinite(q.q),'all')&&all(q.q(:)>=0&q.q(:)<=1)&&q.own_stage_start_detached&&~q.recomputed_during_updates, ...
  'A31FR:FullTarget','Saved detached target cache invalid.');
 if st.alpha==0,assert(isempty(q.teacher)&&eqn(q.q,C(cur.y,:)),'A31FR:FullStatic','Static target differs.');else,assert(eqn(q.teacher,state.theta),'A31FR:OwnTeacher','Saved own teacher differs.');end
 terms=struct('kind','bce','Z',cur.Z,'target',double(q.q),'mask',[],'T',1,'weight',1);
 if job.replay&&~isempty(view.y),terms.weight=.5;terms(2)=struct('kind','bce','Z',view.Z,'target',C(view.y,:),'mask',[],'T',1,'weight',.5);end
 spec=struct('D',8,'terms',terms,'anchors',struct('theta',{},'F',{}),'ewc_lambda',0,'updates',updates,'control_only',control_only);
 assert(eqn(st.spec,spec)&&eqn(st.replay_before,B)&&eqn(st.effective_replay,memory),'A31FR:FullSpec','Saved objective or replay differs.');
 mm=zeros(0,1,'uint64');if job.replay,mm=view.parentindex;end
 key=a29cl_data('hash',jsonencode(struct('fold',double(job.outer_fold),'seed',double(job.seed),'current_parentindex',cur.parentindex,'memory_parentindex',mm,'incoming',state,'spec',spec)));
 assert(strcmp(key,st.fit_reference.job_sha256)&&isKey(cache.map,key),'A31FR:FullCacheMissing','Full copy requires existing exact cache; fallback fit forbidden.');
 [next,~,cache,ref]=a31nr_cache_v1('resolve',cache,double(job.outer_fold),double(job.seed),cur,memory,state,spec,char(job.job_id));
 assert(ref.aliased&&eqn(next,st.final_state),'A31FR:FullFinal','Cached final optimizer state differs.');
 if isfield(entry,'source_fit_SHA256'),assert(strcmp(key,entry.source_fit_SHA256{s}),'A31FR:CatalogFit','Catalog stage key differs.');end
 if job.replay,post=a29cl_data('replay_commit',B,cur,double(job.outer_fold),s);B=post.buffer;end
 assert(eqn(st.replay_after,B),'A31FR:FullReplayAfter','Saved replay commitment differs.');
 st.source_fit_reference=st.fit_reference;st.fit_reference=ref;st.complete_payload_reused=true;
 st.copy_work=struct('new_fit',0,'new_optimizer_updates',0,'new_teacher_forward_rows',0,'new_query_forward_rows',0);
 outS{s}=st;state=next;
 query=data.query(char(job.stream),s);tasks=0;if strcmp(job.stream,'TaskIL'),tasks=1:s;end
 expected=0;
 for task=tasks
  rows=(1:numel(query.y))';eligible=1:s+1;if task>0,rows=find(query.task==task);eligible=[1 task+1];end
  for z=1:numel(rows)
   k=rows(z);ix=find(cellfun(@(r)r.stage==s&&r.task==task&&double(r.parentindex)==double(query.parentindex(k)),P));
   assert(isscalar(ix),'A31FR:FullQuery','Saved query missing or repeated.');p=P{ix};expected=expected+1;
   assert(eqn(p.Z,query.Z(k,:))&&eqn(p.eligible,eligible)&&p.truth==query.y(k)&& ...
    strcmp(p.parentrow,query.parentrow{k})&&p.valid&&~p.failure&&strcmp(p.fit_sha256,key), ...
    'A31FR:FullQueryIdentity','Saved query/scaler/candidate/fit differs.');
  end
 end
 assert(sum(cellfun(@(r)r.stage==s,P))==expected,'A31FR:FullQueryCount','Extra saved queries.');
end
assert(numel(cache.new_indices)==newBefore,'A31FR:FullNoFit','Full copy unexpectedly created a fit.');
for i=1:numel(P)
 p=P{i};p.source_prediction_index1=i;p.source_job_id=saved.job.job_id;
 p.job_id=char(job.job_id);p.phase=char(job.phase);p.split_id=char(job.split_id);p.schedule_id=char(job.schedule_id);
 p.historical_payload_reused=true;p.full_trajectory_payload_reused=true;
 fields={'Z','eligible','scores','distances','outputs','logits'};for k=1:numel(fields),v=p.(fields{k});p.(fields{k})=double(v(:))';end
 P{i}=p;
end
R=saved;R.job=job;R.stages=outS;R.predictions=P;R.source_execution_counts=struct('actual_new_stagefits',saved.actual_new_stagefits,'actual_optimizer_updates',saved.actual_optimizer_updates,'source_training_stages',saved.source_training_stages,'source_optimizer_updates',saved.source_optimizer_updates,'new_source_prediction_rows',saved.new_source_prediction_rows,'historical_prediction_rows_reused',saved.historical_prediction_rows_reused);
R.historical_source_elapsed_seconds=saved.elapsed_seconds;R.elapsed_seconds=toc(clock);
R.actual_new_stagefits=0;R.actual_optimizer_updates=0;R.source_training_stages=0;R.source_optimizer_updates=0;R.new_source_prediction_rows=0;R.historical_prediction_rows_reused=numel(P);R.historical_full_trajectory_reused=true;
R.full_trajectory_reuse_source=entry;R.copy_work=struct('complete_trajectory_copied',true,'new_teacher_forward_rows',0,'new_query_forward_rows',0,'new_optimizer_updates',0);
R.copy_scope='All target_cache and stage_receipt values retain historical source meaning; current copy_work is zero. No new teacher/query/fit was performed.';
end
function s=typed(s),s=struct('theta',double(s.theta(:)),'m',double(s.m(:)),'v',double(s.v(:)),'t',uint64(s.t));end
function c=cells(x),if iscell(x),c=x;elseif isempty(x),c={};else,c=num2cell(x);end,end
function ok=eqn(a,b)
if isempty(a)&&isempty(b),ok=true;return;end
if isstruct(a)&&isstruct(b)
 if numel(a)~=numel(b),ok=false;return;end
 fa=sort(fieldnames(a));fb=sort(fieldnames(b));if ~isequal(fa,fb),ok=false;return;end
 ok=true;for j=1:numel(a),for i=1:numel(fa),ok=ok&&eqn(a(j).(fa{i}),b(j).(fa{i}));end,end
elseif iscell(a)||iscell(b)
 if ~iscell(a),a=num2cell(a);end;if ~iscell(b),b=num2cell(b);end
 ok=numel(a)==numel(b);if ok,for i=1:numel(a),ok=ok&&eqn(a{i},b{i});end,end
elseif (isnumeric(a)||islogical(a))&&(isnumeric(b)||islogical(b)),ok=isequaln(double(a(:)),double(b(:)));
else,ok=isequaln(a,b);end
end
