function a31fr_plots_v1(summaryCSV,outDir)
% Saved accepted summaries only. No training, prediction, or selection.
assert(~isfolder(outDir),'A31FR:NoOverwrite','Existing plot attempt preserved.');mkdir(outDir);
T=readtable(summaryCSV,'TextType','string');
assert(height(T)==32&&all(T.seed_count==5),'A31FR:Summary','Expected32allseed summaries.');
if ~islogical(T.replay),T.replay=lower(string(T.replay))=="true";end
colors=[0.12 .34 .65;.85 .32 .12;.23 .55 .35;.55 .30 .68;.55 .46 .20];
seeds=[101 211 307 401 503];
for mode=1:2
 f=figure('Visible','off','Color','w','Position',[100 100 1080 760]);
 lay=tiledlayout(f,2,2,'TileSpacing','compact','Padding','compact');
 for s=1:2
  stream=["TaskIL","ClassIL"];stream=stream(s);
  for replay=0:1
   ax=nexttile(lay,(s-1)*2+replay+1);hold(ax,'on');
   S=T(T.stream==stream&T.replay==logical(replay),:);
   if mode==1
    S=S(S.alpha1==S.alpha2&S.alpha2==S.alpha3,:);S=sortrows(S,'alpha1');
    assert(height(S)==6);x=S.alpha1;xlabel(ax,'Constant NR across all three tasks');
    xticks(ax,[0 .25 .5 .75 .9 1]);xlim(ax,[-.04 1.04]);
   else
    ids=["F00_STATIC","F50","F100_SELF_TARGET","UP_CLOSED_LINEAR","DOWN_CLOSED_LINEAR"];
    SS=S([],:);for id=ids,SS=[SS;S(S.schedule_id==id,:)];end %#ok<AGROW>
    S=SS;assert(height(S)==5);x=(1:5)';
    xticks(ax,1:5);xticklabels(ax,{'0 / 0 / 0','0.5 / 0.5 / 0.5','1 / 1 / 1','0 / 0.5 / 1','1 / 0.5 / 0'});
    xtickangle(ax,18);xlim(ax,[.6 5.4]);xlabel(ax,'NR in tasks 1 / 2 / 3');
   end
   errorbar(ax,x,S.median_percent,S.median_percent-S.min_percent,S.max_percent-S.median_percent, ...
    '-k','LineWidth',1.35,'CapSize',7,'Marker','d','MarkerFaceColor','k','MarkerSize',6,'DisplayName','Median and min–max');
   seednames={'correct_seed_101','correct_seed_211','correct_seed_307','correct_seed_401','correct_seed_503'};
   for j=1:5
    jitter=(j-3)*(.004*(mode==1)+.022*(mode==2));
    scatter(ax,x+jitter,100*S.(seednames{j})./S.N,28,colors(j,:),'filled','DisplayName',sprintf('Seed %d',seeds(j)));
   end
   title(ax,sprintf('%s   Replay %s',stream,string(logical(replay))),'Color','k','FontSize',13);
   ylabel(ax,'Final accuracy (%)');ylim(ax,[0 100]);yticks(ax,0:20:100);grid(ax,'on');box(ax,'on');
   set(ax,'Color','w','XColor','k','YColor','k','FontSize',11,'GridColor',[.76 .76 .76],'GridAlpha',.6);
  end
 end
 title(lay,'Fixed NR response on previously exposed source-average records','Color','k','FontSize',16);
 subtitle(lay,'Five group-based folds pooled per seed. All five numerical initializations are shown.','Color','k','FontSize',11);
 lg=legend(ax,'Location','southoutside','Orientation','horizontal','NumColumns',3,'TextColor','k','Color','w','Box','off');lg.Layout.Tile='south';
 if mode==1,name='NR_constant_closed_interval_v1';else,name='NR_full_direction_comparison_v1';end
 exportgraphics(f,fullfile(outDir,[name '.png']),'Resolution',200,'BackgroundColor','white');
 exportgraphics(f,fullfile(outDir,[name '.pdf']),'ContentType','vector','BackgroundColor','white');
 exportgraphics(f,fullfile(outDir,[name '.svg']),'ContentType','vector','BackgroundColor','white');close(f);
end
end
