function receipt=a31p2_controls_v1(outDir)
% A31P2_CONTROLS_V1 Finite source-free controls. No source inputs or RNG.
% This function is authored separately from any source-run admission.
if nargin>0
 root=char(java.io.File(fileparts(fileparts(mfilename('fullpath')))).getCanonicalPath());
 outDir=char(java.io.File(char(outDir)).getCanonicalPath());
 assert(startsWith(lower(outDir),lower([root filesep '05_Denetim' filesep])), ...
  'A31P2:ControlScope','Control output must be a child of this version audit folder.');
 if isfolder(outDir)
  d=dir(outDir);assert(~any(~ismember({d.name},{'.','..'})), ...
   'A31P2:ExistingOutput','Preserve previous controls; new empty output required.');
 else,mkdir(outDir);end
end
checks=struct('id',{},'passed',{});
ids={'a';'b'};X=[0 0;2 4];n=a31p2_core_v1('fit_normalizer',X,ids);
check(isequal(n.mean,[1 2]) && max(abs(n.sd-[sqrt(2) sqrt(8)]))<1e-15,'SC01_sample_statistics');
Z=a31p2_core_v1('normalize',X,n);
check(max(abs(Z-[-1 -1;1 1]/sqrt(2)),[],'all')<1e-15,'SC02_normalized_coordinates');
n4=a31p2_core_v1('fit_normalizer',[0 0 2 8;2 4 6 12],ids);
check(isequal(n4.mean,[1 2 4 10]) && isequal(n4.mean(1:2),n.mean) && ...
 isequal(n4.sd(1:2),n.sd),'SC03_dimension_extension_statistics');
check(rejects(@()a31p2_core_v1('fit_normalizer',[0 0;1 0],ids),'A31P2:NormalizerSTOP'),'SC04_zero_sd_stop');
check(rejects(@()a31p2_core_v1('fit_normalizer',[0 0;Inf 1],ids),'A31P2:Input'),'SC05_nonfinite_fit_stop');
check(rejects(@()a31p2_core_v1('fit_normalizer',X,{'a';'a'}),'A31P2:NormalizerIDs'),'SC06_duplicate_fit_ids');
check(rejects(@()a31p2_core_v1('fit_normalizer',[0 1],{'a'}),'A31P2:NormalizerCount'),'SC07_one_row_stop');
check(rejects(@()a31p2_core_v1('init_proto',3),'A31P2:Dimension'),'SC08_invalid_dimension_stop');

% Analytic separation between centroid and nearest-reference geometry.
Xp=[-3 0;3 0;1 0;1 0];yp=[1;1;2;2];ip={'p1';'p2';'p3';'p4'};
pr=a31p2_core_v1('admit_proto',a31p2_core_v1('init_proto',2),Xp,yp);
nn=a31p2_core_v1('admit_nn',a31p2_core_v1('init_nn',2),Xp,yp,ip);
op=a31p2_core_v1('predict','proto',pr,[0 0],[1 2]);
on=a31p2_core_v1('predict','nn',nn,[0 0],[1 2]);
check(op.prediction==1 && on.prediction==2 && ...
 isequal(op.distances(1,1:2),[0 1]) && isequal(on.distances(1,1:2),[9 1]),'SC09_distinct_reference_geometry');
check(isequal(pr.sumS(1:2,:),[0 0;2 0]) && ...
 isequal(pr.countn,uint64([2 2 0 0])),'SC10_analytic_sums_counts');
check(rejects(@()a31p2_core_v1('admit_proto',pr,[8 1],1), ...
 'A31P2:RepeatedClass'),'SC11_no_repeated_anchor_admission');
check(rejects(@()a31p2_core_v1('admit_nn',nn,[8 1],3,{'p1'}), ...
 'A31P2:RepeatedRow'),'SC12_no_repeated_parent_admission');

% Exact ties and candidate information are independent of the truth label.
o=a31p2_core_v1('decode',[3 3 NaN NaN],[2 1]);
check(o.prediction==1 && o.tie && o.gap==0,'SC13_global_id_exact_tie');
o=a31p2_core_v1('decode',[0 eps(1) NaN NaN],[1 2]);
check(o.prediction==2 && ~o.tie && o.gap==eps(1),'SC14_no_tolerance_ties');
o=a31p2_core_v1('decode',[99 NaN 2 3],[4 3]);
check(o.prediction==4 && ~o.tie && o.gap==1,'SC15_ineligible_scores_ignored');
o=a31p2_core_v1('decode',[0 NaN 2 3],[1 2]);
check(strcmp(o.status{1},'failure') && isnan(o.prediction),'SC16_eligible_nonfinite_failure');
o=a31p2_core_v1('predict','nn',nn,[0 0;NaN 0;2 0],[1 2]);
check(numel(o.prediction)==3 && strcmp(o.status{1},'valid') && ...
 strcmp(o.status{2},'failure') && strcmp(o.failure{2},'nonfinite_query') && ...
 strcmp(o.status{3},'valid'),'SC17_failure_row_preserved');
o=a31p2_core_v1('predict','proto',pr,[0 0],[1 3]);
check(strcmp(o.status{1},'failure') && ...
 strcmp(o.failure{1},'nonfinite_state_or_missing_candidate'),'SC18_missing_candidate_failure');

% Four-dimensional hand-computable example and coordinate invariance.
X4=[0 0 0 0;2 0 0 0;0 0 4 4];y4=[1;2;4];q4=[1 0 0 0];
nr=a31p2_core_v1('admit_nn',a31p2_core_v1('init_nn',4),X4,y4,{'q1';'q2';'q4'});
o=a31p2_core_v1('predict','nn',nr,q4,[1 2 4]);
check(isequal(o.distances([1 2 4]),[1 1 33]) && o.prediction==1 && o.tie,'SC19_four_coordinate_distances');
o=a31p2_core_v1('predict','nn',nr,q4,[2 4]);
check(o.prediction==2 && ~o.tie && o.gap==32,'SC20_candidate_mask');
shift=[8 -4 2 16];
ns=a31p2_core_v1('admit_nn',a31p2_core_v1('init_nn',4),X4+shift,y4,{'q1';'q2';'q4'});
os=a31p2_core_v1('predict','nn',ns,q4+shift,[1 2 4]);
check(isequaln(os.distances,[1 1 NaN 33]),'SC21_translation_invariance');
perm=[4 2 1 3];
ns=a31p2_core_v1('admit_nn',a31p2_core_v1('init_nn',4),X4(:,perm),y4,{'q1';'q2';'q4'});
os=a31p2_core_v1('predict','nn',ns,q4(:,perm),[1 2 4]);
check(isequaln(os.distances,[1 1 NaN 33]),'SC22_coordinate_permutation');

% Shared process support must be exactly non-discriminative across labels.
P=[0 0;1 0;0 1];A=zeros(12,2);Y=zeros(12,1);ID=cell(12,1);
for g=1:3
 for k=1:4
  i=4*(g-1)+k;A(i,:)=P(g,:);Y(i)=k;ID{i}=sprintf('g%d_c%d',g,k);
 end
end
ps=a31p2_core_v1('init_proto',2);ns=a31p2_core_v1('init_nn',2);
new={[1 2],3,4};pairs={[1 2],[1 3],[1 4]};nQueries=0;
for st=1:3
 ix=ismember(Y,new{st});
 ps=a31p2_core_v1('admit_proto',ps,A(ix,:),Y(ix));
 ns=a31p2_core_v1('admit_nn',ns,A(ix,:),Y(ix),ID(ix));
 view=0;
 for mask=[pairs(1:st),{1:(st+1)}]
  view=view+1;
  for kind={'proto','nn'}
   state=ps;if strcmp(kind{1},'nn'),state=ns;end
   z=a31p2_core_v1('predict',kind{1},state,[.25 .25;2 2],mask{1});
   check(all(z.tie) && all(z.gap==0) && all(z.prediction==min(mask{1})), ...
    sprintf('SC23_shared_support_s%d_view%d_%s',st,view,kind{1}));
   nQueries=nQueries+numel(z.prediction);
  end
 end
end
check(isequal(ps.countn,uint64([3 3 3 3])) && ...
 isequal(ps.sumS,repmat([1 1],4,1)) && size(ns.X,1)==12 && ...
 numel(unique(ns.row_ids))==12,'SC24_unique_class_history');
check(nQueries==36,'SC25_finite_control_query_population');

% With common class-wise process support, PROTO adds the same query constant.
% Integer/quarter inputs make this analytic example exactly representable.
Xm=[0 0;9 0;2 0;8 0];Xp=[10 10;0 0;0 0;10 10];yy=[1;1;2;2];
pr2=a31p2_core_v1('admit_proto',a31p2_core_v1('init_proto',2),Xm,yy);
pr4=a31p2_core_v1('admit_proto',a31p2_core_v1('init_proto',4),[Xm Xp],yy);
b=a31p2_core_v1('predict','proto',pr2,[0 0],[1 2]);
a=a31p2_core_v1('predict','proto',pr4,[0 0 0 0],[1 2]);
check(isequal(b.distances(1,1:2),[20.25 25]) && ...
 isequal(a.distances(1,1:2)-b.distances(1,1:2),[50 50]) && ...
 a.prediction==b.prediction && a.tie==b.tie && a.gap==b.gap, ...
 'SC26_PROTO_shared_process_additive_constant');
% NN1 can change: adding distance acts on individual references before min().
nn2=a31p2_core_v1('admit_nn',a31p2_core_v1('init_nn',2),Xm,yy,ip);
nn4=a31p2_core_v1('admit_nn',a31p2_core_v1('init_nn',4),[Xm Xp],yy,ip);
b=a31p2_core_v1('predict','nn',nn2,[0 0],[1 2]);
a=a31p2_core_v1('predict','nn',nn4,[0 0 0 0],[1 2]);
check(b.prediction==1 && a.prediction==2 && ...
 isequal(a.distances(1,1:2),[81 4]),'SC27_NN1_process_distance_can_reverse');
receipt=struct('schema','A31_P2_SOURCE_FREE_CONTROL_RECEIPT_V1', ...
 'status','PASS_SOURCE_FREE_CONTROLS','complete',true,'checks',checks, ...
 'passed_checks',numel(checks),'failed_checks',0,'source_rows_read',0, ...
 'new_source_predictions',0,'gradient_training',0,'RNG_calls',0, ...
 'scope','Artificial mathematical controls only; no scientific experiment or source admission.');
if nargin>0
 path=fullfile(outDir,'a31p2_controls_receipt_v1.json');
 raw=unicode2native(jsonencode(receipt,'ConvertInfAndNaN',true),'UTF-8');
 f=fopen(path,'wb');assert(f>=0,'A31P2:ControlWrite','Cannot create control receipt.');
 cleaner=onCleanup(@()fclose(f));
 assert(fwrite(f,raw,'uint8')==numel(raw),'A31P2:ControlWrite','Short control receipt write.');
 clear cleaner;
end

 function check(ok,id)
  assert(isscalar(ok) && islogical(ok) && ok,'A31P2:ControlFailure','Control failed: %s',id);
  checks(end+1)=struct('id',id,'passed',true);
 end
end

function yes=rejects(f,id)
yes=false;
try,f();catch err,yes=strcmp(err.identifier,id);end
end
