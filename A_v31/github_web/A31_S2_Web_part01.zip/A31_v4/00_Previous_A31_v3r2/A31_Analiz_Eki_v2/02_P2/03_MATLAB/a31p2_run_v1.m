function result=a31p2_run_v1(versionRoot,outDir,runCfg)
% A31P2_RUN_V1 Frozen deterministic comparison. Do not run during authoring.
timer=tic;versionRoot=canonical(versionRoot);outDir=canonical(outDir);
assert(startsWith(lower(outDir),lower([versionRoot filesep '04_Sonuclar' filesep])), ...
 'A31P2:OutputScope','Source output must be a child of this version results folder.');
assert(isstruct(runCfg) && isfield(runCfg,'source_run_authorized') && ...
 isfield(runCfg,'admission_token') && isequal(runCfg.source_run_authorized,true) && ...
 strcmp(runCfg.admission_token,'A31_P2_ADMITTED_SOURCE_RUN'), ...
 'A31P2:NotAdmitted','Explicit frozen source-run admission required.');
limits=[runCfg.max_seconds,runCfg.max_json_bytes,runCfg.max_total_output_bytes];
assert(all(isfinite(limits)) && all(limits>0) && runCfg.max_seconds<=180 && ...
 runCfg.max_total_output_bytes<=30000000 && runCfg.max_json_bytes<=runCfg.max_total_output_bytes, ...
 'A31P2:Budget','Finite positive budgets required.');
if isfolder(outDir)
 d=dir(outDir);assert(~any(~ismember({d.name},{'.','..'})), ...
  'A31P2:ExistingOutput','Previous output is preserved; use a new empty folder.');
else,mkdir(outDir);end
started=times();preds=struct([]);states=struct([]);norms=struct([]);meta=struct();
try
 names={'protocol_pin','input_pin','source_pin','admission_pin','baseline_result_pin', ...
  'baseline_prediction_pin','core_pin','producer_pin','control_receipt_pin','independent_review_pin', ...
  'math_note_pin','frozen_M2_normalizer_pin'};
 for i=1:numel(names)
  assert(isfield(runCfg,names{i}),'A31P2:MissingPin','Missing required pin %s',names{i});
  pin=runCfg.(names{i});assert(strcmp(hashFile(pin.path),pin.sha256), ...
   'A31P2:PinMismatch','Pinned file changed: %s',names{i});
 end
 assert(strcmp(canonical([mfilename('fullpath') '.m']),canonical(runCfg.producer_pin.path)), ...
  'A31P2:ProducerPath','Unexpected producer location.');
 assert(strcmp(canonical(runCfg.core_pin.path),canonical(fullfile(versionRoot,'03_MATLAB_Kodlari','a31p2_core_v1.m'))), ...
  'A31P2:CorePath','Unexpected core path.');
 P=jsondecode(fileread(runCfg.protocol_pin.path));
 assert(strcmp(P.id,'A31_P2_FIXED_FOLDS_PRINTING_INPUTS_V1') && ...
  P.finite_counts.new_prediction_rows==2184 && P.finite_counts.new_final_rows==1040, ...
  'A31P2:Protocol','Unexpected scientific protocol.');
 MN=jsondecode(fileread(runCfg.math_note_pin.path));
 assert(strcmp(MN.status,'PROSPECTIVE_MATHEMATICAL_EXPECTATION_BEFORE_SOURCE_INFERENCE') && ...
  isequal(MN.source_predictions_already_computed,false), ...
  'A31P2:ProspectiveMath','Pinned prospective process-invariance note required.');
 CR=jsondecode(fileread(runCfg.control_receipt_pin.path));
 assert(strcmp(CR.status,'PASS_SOURCE_FREE_CONTROLS') && CR.complete && CR.failed_checks==0, ...
  'A31P2:ControlGate','Accepted source-free controls required.');
 IR=jsondecode(fileread(runCfg.independent_review_pin.path));
 assert(isequal(IR.admitted,true) && strcmp(IR.mode,'source'), ...
  'A31P2:IndependentGate','Independent prospective source admission required.');
 assert(strcmp(P.inputs.source_csv.sha256,runCfg.source_pin.sha256) && ...
  strcmp(P.inputs.admission_card.sha256,runCfg.admission_pin.sha256) && ...
  strcmp(P.inputs.historical_M2_predictions.sha256,runCfg.baseline_prediction_pin.sha256) && ...
  strcmp(P.inputs.historical_M2_states_and_normalizers.sha256,runCfg.baseline_result_pin.sha256), ...
  'A31P2:ProtocolInputPins','Runtime inputs differ from protocol inputs.');
 addpath(fileparts(runCfg.core_pin.path));
 assert(strcmp(canonical(which('a31p2_core_v1')),canonical(runCfg.core_pin.path)), ...
  'A31P2:CoreResolution','MATLAB path did not resolve the pinned core.');
 T=readtable(runCfg.input_pin.path,'TextType','string','VariableNamingRule','preserve');
 S=readtable(runCfg.source_pin.path,'TextType','string','VariableNamingRule','preserve');
 card=jsondecode(fileread(runCfg.admission_pin.path));validateInput(T,S,card);
 T=sortrows(T,{'group_order','label'});Y=double(T.label);folds=double(T.outer_fold);
 old=jsondecode(fileread(runCfg.baseline_result_pin.path));
 frozen=jsondecode(fileread(runCfg.frozen_M2_normalizer_pin.path));
 assert(strcmp(frozen.schema,'P2_ACCEPTED_M2_SCALERS_COPY_ONLY_V1') && ...
  strcmp(frozen.source_baseline_result_pin.sha256,runCfg.baseline_result_pin.sha256), ...
  'A31P2:FrozenNormalizerSource','Scaler copy source is not the pinned accepted state.');
 H=readtable(runCfg.baseline_prediction_pin.path,'TextType','string','VariableNamingRule','preserve');
 H=H(ismember(H.method,["PROTO","NN1_FULL"]),:);
 assert(height(H)==1092,'A31P2:HistoricalCount','Expected 1092 accepted deterministic views.');
 historical=historicalRows(H);historyIndex=containers.Map('KeyType','char','ValueType','double');
 for i=1:numel(historical)
  k=key(historical(i));assert(~isKey(historyIndex,k),'A31P2:HistoricalKey','Duplicate historical key.');
  historyIndex(k)=i;
 end
 meta=struct('status','RUNNING','started',started,'software',version, ...
  'release',version('-release'),'computer',computer,'pid',feature('getpid'), ...
  'run_config',runCfg,'protocol_id',P.id,'source_previously_exposed',true, ...
  'new_blind_test',false,'new_gradient_training',0,'M2_forward_rerun',false);
 featureIDs={'P2','M2P2'};fields={{'layer_mm','infill_percent'}, ...
  {'E_MPa','Hardness_ShoreD','layer_mm','infill_percent'}};
 pairs={[1 2],[1 3],[1 4]};newClasses={[1 2],3,4};
 for f=1:5
  budget(timer,runCfg);train=folds~=f;held=folds==f;
  first=find(train & ismember(Y,[1 2]));ids=cellstr(T.row_id(first));
  prev=old.normalizers([old.normalizers.fold]==f);
  % jsondecode may orient a JSON vector as a column; preserve scalar values.
  prev.mean=double(prev.mean(:)');prev.sd=double(prev.sd(:)');
  frozenPrev=frozen.normalizers([frozen.normalizers.fold]==f);
  frozenPrev.mean=double(frozenPrev.mean(:)');frozenPrev.sd=double(frozenPrev.sd(:)');
  assert(isequal(prev.mean,frozenPrev.mean) && isequal(prev.sd,frozenPrev.sd) && ...
   isequal(prev.n,frozenPrev.n) && ...
   isequal(cellstr(string(prev.train_row_ids(:))),cellstr(string(frozenPrev.train_row_ids(:)))), ...
   'A31P2:FrozenNormalizerCopy','Frozen M2 copy differs from accepted historical state.');
  assert(isscalar(prev) && prev.n==numel(first) && ...
   isequal(cellstr(string(prev.train_row_ids(:))),ids),'A31P2:LegacyFitIDs','Initial TRAIN identity differs.');
  mech=double([T.E_MPa T.Hardness_ShoreD]);proc=double([T.layer_mm T.infill_percent]);
  verify=a31p2_core_v1('fit_normalizer',mech(first,:),ids);
  assert(isequal(verify.mean,prev.mean) && isequal(verify.sd,prev.sd), ...
   'A31P2:LegacyNormalizer','Recomputed old scaler differs; no silent replacement.');
  pn=a31p2_core_v1('fit_normalizer',proc(first,:),ids);
  for fi=1:2
   n=pn;raw=proc;
   if fi==2,n.mean=[prev.mean pn.mean];n.sd=[prev.sd pn.sd];raw=[mech proc];end
   n.fold=f;n.feature_set=featureIDs{fi};n.ordered_fields=fields{fi};
   norms=append(norms,n);Z=a31p2_core_v1('normalize',raw,n);
   pr=a31p2_core_v1('init_proto',size(Z,2));nn=a31p2_core_v1('init_nn',size(Z,2));admitted=[];
   for st=1:3
    budget(timer,runCfg);ix=find(train & ismember(Y,newClasses{st}));admitted=sort([admitted(:);ix(:)]);
    pr=a31p2_core_v1('admit_proto',pr,Z(ix,:),Y(ix));
    nn=a31p2_core_v1('admit_nn',nn,Z(ix,:),Y(ix),cellstr(T.row_id(ix)));
    [found,pos]=ismember(string(nn.row_ids),T.row_id);assert(all(found),'A31P2:NNIdentity','Unknown memory parent.');
    [~,order]=sort(pos);nn.X=nn.X(order,:);nn.y=nn.y(order);nn.row_ids=nn.row_ids(order);
    seen=1:(st+1);centers=nan(4,size(Z,2));
    for k=seen
     rr=find(train & Y==k);sumv=zeros(1,size(Z,2));
     for j=1:numel(rr),sumv=sumv+Z(rr(j),:);end
     centers(k,:)=sumv/numel(rr);
    end
    pc=pr.sumS(seen,:)./double(pr.countn(seen)');
    assert(isequal(pc,centers(seen,:)),'A31P2:Centroid','Canonical sums differ from batch means.');
    pcols=1:2;if fi==2,pcols=3:4;end
    assert(isequal(pc(:,pcols),repmat(pc(1,pcols),numel(seen),1)), ...
     'A31P2:ProcessSupport','Class process centroids must be exact equal.');
    sid=sprintf('%s_f%d_s%d',featureIDs{fi},f,st);
    state=struct('state_id',sid,'feature_set',featureIDs{fi},'fold',f,'stage',st, ...
     'admitted_row_ids',{cellstr(T.row_id(admitted))},'proto',pr,'nn',nn, ...
     'batch_centroids',centers,'normalizer_index',numel(norms));states=append(states,state);
    for stream={'TIL','CIL'}
     tasks=0;if strcmp(stream{1},'TIL'),tasks=1:st;end
     for task=tasks
      eligible=seen;if task>0,eligible=pairs{task};end
      q=find(held & ismember(Y,eligible));
      for method={'PROTO','NN1_FULL'}
       kind='proto';s=pr;if strcmp(method{1},'NN1_FULL'),kind='nn';s=nn;end
       o=a31p2_core_v1('predict',kind,s,Z(q,:),eligible);
       for j=1:numel(q)
        i=q(j);r=struct('prediction_id',sprintf('A31P2_%05d',numel(preds)+1), ...
         'feature_set',featureIDs{fi},'method',method{1},'fold',f,'stream',stream{1}, ...
         'stage',st,'task',task,'parentrow',char(T.row_id(i)),'group',char(T.condition_group(i)), ...
         'group_order',double(T.group_order(i)),'truth',Y(i),'eligible',eligible, ...
         'scores',o.scores(j,:),'distances',o.distances(j,:),'gap',o.gap(j), ...
         'prediction',o.prediction(j),'tie',o.tie(j),'status',o.status{j}, ...
         'failure',o.failure{j},'state_id',sid,'historical_prediction_id','');
        hk=key(r);assert(isKey(historyIndex,hk),'A31P2:PairedHistoricalKey','Historical paired view missing.');
        h=historical(historyIndex(hk));assert(h.truth==r.truth && isequal(h.eligible,r.eligible), ...
         'A31P2:PairedPopulation','Historical truth or candidate set differs.');
        r.historical_prediction_id=h.prediction_id;preds=append(preds,r);
       end
      end
     end
    end
   end
  end
 end
 assert(numel(preds)==2184 && sum([preds.stage]==3)==1040 && ...
  numel(states)==30 && numel(norms)==10,'A31P2:Counts','Finite design count mismatch.');
 assert(all(strcmp({preds.status},'valid')),'A31P2:FailureHold','Prediction failures retained; source acceptance HOLD.');
 kk=arrayfun(@(r)[r.feature_set '|' key(r)],preds,'UniformOutput',false);
 assert(numel(unique(kk))==numel(kk),'A31P2:DuplicatePrediction','Duplicate new view.');
 pp=preds(strcmp({preds.feature_set},'P2'));
 assert(all([pp.prediction]==1) && all([pp.tie]) && all([pp.gap]==0), ...
  'A31P2:ProcessOnly','Expected exact shared-support ties not obtained.');
 comparisons=[historical(:);preds(:)];summaries=summarize(comparisons);
 invariant=invariance(preds,historical,historyIndex,states,norms,T);
 copyfile(runCfg.baseline_prediction_pin.path,fullfile(outDir,'historical_baseline_predictions_verbatim.csv'));
 assert(strcmp(hashFile(fullfile(outDir,'historical_baseline_predictions_verbatim.csv')), ...
  runCfg.baseline_prediction_pin.sha256),'A31P2:HistoricalCopy','Verbatim historical copy mismatch.');
 meta.status='PRODUCER_COMPLETED_PENDING_INDEPENDENT_REVIEW';meta.completed=times();
 meta.new_prediction_rows=numel(preds);meta.new_final_rows=sum([preds.stage]==3);
 meta.actual_elapsed_before_serialization_seconds=toc(timer);
 result=struct('schema','A31_P2_DETERMINISTIC_RESULT_V1','metadata',meta, ...
  'normalizers',norms,'states',states,'predictions',preds,'summaries',summaries, ...
  'PROTO_invariance_diagnostic',invariant,'historical_M2_pin',runCfg.baseline_prediction_pin);
 writeCSV(fullfile(outDir,'a31p2_predictions_v1.csv'),preds);
 writeCSV(fullfile(outDir,'a31p2_final_comparison_v1.csv'),comparisons([comparisons.stage]==3));
 writeJson(fullfile(outDir,'a31p2_result_v1.json'),result,runCfg.max_json_bytes);
 writeJson(fullfile(outDir,'a31p2_summary_v1.json'),summaries,runCfg.max_json_bytes);
 for i=1:numel(names),pin=runCfg.(names{i});assert(strcmp(hashFile(pin.path),pin.sha256),'A31P2:PostPin','Input changed during run.');end
 budget(timer,runCfg);assert(outputBytes(outDir)<=runCfg.max_total_output_bytes,'A31P2:OutputCap','Output cap exceeded.');
 receipt=struct('schema','A31_P2_PRODUCER_RECEIPT_V1','status',meta.status,'complete',true, ...
  'new_predictions',2184,'new_final_rows',1040,'historical_M2_reused',1092, ...
  'final_comparison_rows',1560,'gradient_training',0,'source_M2_forward_rerun',false, ...
  'started',started,'finished',times(),'elapsed_seconds',toc(timer), ...
  'result_sha256',hashFile(fullfile(outDir,'a31p2_result_v1.json')),'run_config',runCfg);
 writeJson(fullfile(outDir,'a31p2_producer_receipt_v1.json'),receipt,runCfg.max_json_bytes);
 assert(outputBytes(outDir)<=runCfg.max_total_output_bytes,'A31P2:OutputCap','Receipt exceeds output cap.');
catch err
 failure=struct('status','FAILED_PRESERVED','complete',false,'identifier',err.identifier, ...
  'message',err.message,'stack',err.stack,'started',started,'finished',times(), ...
  'new_predictions_returned',numel(preds),'no_scientific_acceptance',true);
 try,writeJson(fullfile(outDir,'a31p2_FAILED_receipt_v1.json'),failure,runCfg.max_json_bytes);catch,disp(failure);end
 rethrow(err);
end
end

function validateInput(T,S,card)
headers={'row_id','condition_group','group_order','outer_fold','native_key_id','legacy_partition', ...
 'label','source_excel_row','E_MPa','Hardness_ShoreD','layer_mm','infill_percent'};
assert(isequal(T.Properties.VariableNames,headers) && height(T)==104 && ...
 numel(unique(T.row_id))==104,'A31P2:InputSchema','Exact 104-parent metadata schema required.');
T=sortrows(T,{'group_order','label'});S=sortrows(S,{'group_order','label'});
assert(height(S)==104 && isequal(T.row_id,S.row_id) && ...
 isequal(T.condition_group,S.condition_group) && isequal(T.native_key_id,S.native_key_id) && ...
 isequal(T.legacy_partition,S.partition),'A31P2:SourceIdentity','Source parent metadata mismatch.');
for field={'group_order','label','source_excel_row','E_MPa','Hardness_ShoreD'}
 assert(isequal(double(T.(field{1})),double(S.(field{1}))), ...
  'A31P2:SourceValue','Source field changed: %s',field{1});
end
X=double([T.E_MPa T.Hardness_ShoreD T.layer_mm T.infill_percent]);
assert(all(isfinite(X),'all') && isequal(unique(double(T.group_order))',0:25) && ...
 all(ismember(double(T.label),1:4)) && numel(unique(T.condition_group))==26, ...
 'A31P2:SourceDomain','Nonfinite data or wrong source group domain.');
assert(isequal(double(T.outer_fold),mod(double(T.group_order),5)+1), ...
 'A31P2:FoldRule','Original fold mapping changed.');
for ai=1:numel(card.whole_group_assignments)
 a=card.whole_group_assignments(ai);
 ix=find(T.condition_group==string(a.condition_group));
 assert(numel(ix)==4 && isequal(double(T.label(ix))',[1 2 3 4]) && ...
  all(double(T.group_order(ix))==a.group_order_source_0based) && ...
  all(double(T.outer_fold(ix))==a.outer_fold),'A31P2:CardGroup','Exact admitted group differs.');
 for k=1:4
  parent=a.parent_records([a.parent_records.label]==k);i=ix(k);
  assert(isscalar(parent) && T.row_id(i)==string(parent.row_id) && ...
   double(T.source_excel_row(i))==parent.source_excel_row,'A31P2:CardParent','Admitted parent differs.');
 end
 assert(all(T.layer_mm(ix)==a.native_conditions_trace_only.layer_mm) && ...
  all(T.infill_percent(ix)==a.native_conditions_trace_only.infill_percent), ...
  'A31P2:MetadataJoin','Printing metadata differs from admitted whole group.');
end
end

function R=historicalRows(H)
R=struct([]);
for i=1:height(H)
 task=double(H.task(i));if isnan(task),task=0;end
 eligible=find(double(H{i,{'eligible1','eligible2','eligible3','eligible4'}}));eligible=eligible(:)';
 r=struct('prediction_id',char(H.prediction_id(i)),'feature_set','M2','method',char(H.method(i)), ...
  'fold',double(H.fold(i)),'stream',char(H.stream(i)),'stage',double(H.stage(i)),'task',task, ...
  'parentrow',char(H.parentrow(i)),'group',char(H.group(i)),'group_order',double(H.group_order(i)), ...
  'truth',double(H.truth(i)),'eligible',eligible,'scores',double(H{i,{'score1','score2','score3','score4'}}), ...
  'distances',double(H{i,{'distance1','distance2','distance3','distance4'}}),'gap',double(H.gap(i)), ...
  'prediction',double(H.prediction(i)),'tie',logical(H.tie(i)),'status',char(H.status(i)), ...
  'failure',optionalText(H.failure(i)),'state_id',char(H.state_id(i)),'historical_prediction_id',char(H.prediction_id(i)));
 R=append(R,r);
end
end

function out=summarize(R)
pop=struct([]);conf=struct([]);pairs=struct([]);F=R([R.stage]==3);
for feature={'M2','P2','M2P2'}
 for method={'PROTO','NN1_FULL'}
  for stream={'TIL','CIL'}
   for stage=1:3
    Q=R(strcmp({R.feature_set},feature{1}) & strcmp({R.method},method{1}) & ...
     strcmp({R.stream},stream{1}) & [R.stage]==stage);
    valid=strcmp({Q.status},'valid');correct=valid & [Q.prediction]==[Q.truth];
    p=struct('feature_set',feature{1},'method',method{1},'stream',stream{1},'stage',stage, ...
     'N',numel(Q),'correct',sum(correct),'failure',sum(~valid),'tie',sum([Q.tie]), ...
     'accuracy',sum(correct)/numel(Q),'unique_parents',numel(unique({Q.parentrow})), ...
     'groups',numel(unique({Q.group})));pop=append(pop,p);
    tasks=0;if strcmp(stream{1},'TIL'),tasks=1:stage;end
    for task=tasks
     q=Q([Q.task]==task);labels=1:(stage+1);if task>0,labels=[1 task+1];end
     M=zeros(numel(labels));fail=zeros(1,numel(labels));
     for j=1:numel(q)
      tr=find(labels==q(j).truth);
      if strcmp(q(j).status,'valid'),pr=find(labels==q(j).prediction);M(tr,pr)=M(tr,pr)+1;
      else,fail(tr)=fail(tr)+1;end
     end
     c=struct('feature_set',feature{1},'method',method{1},'stream',stream{1}, ...
      'stage',stage,'task',task,'labels',labels,'matrix',M,'failure_by_truth',fail);conf=append(conf,c);
    end
   end
   for added={'P2','M2P2'}
    if ~strcmp(feature{1},'M2'),continue;end
    groups=unique({F.group});
    for gi=1:numel(groups)
     q=F(strcmp({F.group},groups{gi}) & strcmp({F.method},method{1}) & strcmp({F.stream},stream{1}));
     left=q(strcmp({q.feature_set},added{1}));right=q(strcmp({q.feature_set},'M2'));
     wins=0;losses=0;same=0;
     for j=1:numel(left)
      k=find(strcmp({right.parentrow},left(j).parentrow) & [right.task]==left(j).task);
      assert(isscalar(k),'A31P2:SummaryPair','Missing or duplicate exact paired query.');
      a=strcmp(left(j).status,'valid') && left(j).prediction==left(j).truth;
      b=strcmp(right(k).status,'valid') && right(k).prediction==right(k).truth;
      wins=wins+(a && ~b);losses=losses+(~a && b);same=same+(a==b);
     end
     z=struct('method',method{1},'stream',stream{1},'group',groups{gi},'added_feature_set',added{1}, ...
      'reference_feature_set','M2','N',numel(left),'gains',wins,'losses',losses, ...
      'unchanged_correctness',same,'net_correct',wins-losses,'accuracy_delta',(wins-losses)/numel(left));pairs=append(pairs,z);
    end
   end
  end
 end
end
[byClass,byFold,perQuery]=pairedDetails(F);
out=struct('population_counts',pop,'confusions',conf,'paired_final_group_changes',pairs, ...
 'paired_final_class_changes',byClass,'paired_final_fold_changes',byFold, ...
 'paired_final_query_changes',perQuery, ...
 'scope','Pooled OOF counts on exposed means; no seed replication, inferential significance or causal process claim.');
end

function [byClass,byFold,perQuery]=pairedDetails(F)
byClass=struct([]);byFold=struct([]);perQuery=struct([]);
for method={'PROTO','NN1_FULL'}
 for stream={'TIL','CIL'}
  for added={'P2','M2P2'}
   selected=F(strcmp({F.method},method{1}) & strcmp({F.stream},stream{1}));
   left=selected(strcmp({selected.feature_set},added{1}));right=selected(strcmp({selected.feature_set},'M2'));
   view=struct([]);
   for j=1:numel(left)
    a=left(j);ki=find(strcmp({right.parentrow},a.parentrow) & [right.task]==a.task);
    assert(isscalar(ki),'A31P2:SummaryPair','Exact final paired query missing.');b=right(ki);
    ac=strcmp(a.status,'valid') && a.prediction==a.truth;
    bc=strcmp(b.status,'valid') && b.prediction==b.truth;
    r=struct('method',method{1},'stream',stream{1},'added_feature_set',added{1}, ...
     'reference_feature_set','M2','fold',a.fold,'group',a.group,'group_order',a.group_order, ...
     'parentrow',a.parentrow,'truth',a.truth,'task',a.task, ...
     'reference_prediction',b.prediction,'added_prediction',a.prediction, ...
     'reference_correct',bc,'added_correct',ac,'gain',ac && ~bc,'loss',~ac && bc, ...
     'prediction_changed',a.prediction~=b.prediction,'reference_tie',b.tie,'added_tie',a.tie);
    view=append(view,r);perQuery=append(perQuery,r);
   end
   for label=1:4
    v=view([view.truth]==label);r=pairedCount(v,method{1},stream{1},added{1});
    r.label=label;byClass=append(byClass,r);
   end
   for fold=1:5
    v=view([view.fold]==fold);r=pairedCount(v,method{1},stream{1},added{1});
    r.fold=fold;byFold=append(byFold,r);
   end
  end
 end
end
assert(numel(byClass)==32 && numel(byFold)==40 && numel(perQuery)==1040, ...
 'A31P2:PairedSummaryCounts','Final class/fold/query paired count mismatch.');
end

function r=pairedCount(v,method,stream,added)
assert(~isempty(v),'A31P2:PairedSummaryEmpty','Every final class/fold must be retained.');
g=sum([v.gain]);l=sum([v.loss]);n=numel(v);
r=struct('method',method,'stream',stream,'added_feature_set',added,'reference_feature_set','M2', ...
 'N',n,'reference_correct',sum([v.reference_correct]),'added_correct',sum([v.added_correct]), ...
 'gains',g,'losses',l,'unchanged_correctness',n-g-l,'net_correct',g-l, ...
 'accuracy_delta',(g-l)/n,'prediction_changes',sum([v.prediction_changed]));
end

function out=invariance(P,H,index,states,norms,T)
R=P(strcmp({P.feature_set},'M2P2') & strcmp({P.method},'PROTO'));
changes=struct([]);maxError=0;
for i=1:numel(R)
 r=R(i);h=H(index(key(r)));s=states(strcmp({states.state_id},r.state_id));n=norms(s.normalizer_index);
 row=find(T.row_id==string(r.parentrow));p=([double(T.layer_mm(row)) double(T.infill_percent(row))]-n.mean(3:4))./n.sd(3:4);
 center=s.proto.sumS(1,3:4)/double(s.proto.countn(1));constant=sum((p-center).^2);
 err=max(abs(r.distances(r.eligible)-(h.distances(r.eligible)+constant)));maxError=max(maxError,err);
 z=struct('prediction_id',r.prediction_id,'historical_prediction_id',h.prediction_id, ...
  'process_constant',constant,'max_additive_distance_error',err, ...
  'prediction_changed',r.prediction~=h.prediction,'tie_changed',r.tie~=h.tie, ...
  'old_gap',h.gap,'new_gap',r.gap);changes=append(changes,z);
end
out=struct('exact_math_expectation','Common process centroid adds a class-independent query constant; order invariant in exact arithmetic.', ...
 'binary64_note','Different addition/cancellation rounding can alter exact ties or tiny margins; preserve all distances, gaps and changes for independent review.', ...
 'rows',changes,'prediction_changes',sum([changes.prediction_changed]), ...
 'tie_changes',sum([changes.tie_changed]),'max_additive_distance_error',maxError);
end

function k=key(r)
k=sprintf('%d|%s|%d|%s|%d|%s',r.fold,r.stream,r.stage,r.method,r.task,r.parentrow);
end
function A=append(A,r)
if isempty(A),A=r;else,assert(isequal(fieldnames(A),fieldnames(r)),'A31P2:StructFields','Record schema mismatch.');A(end+1,1)=r;end
end
function budget(t,c),assert(toc(t)<=c.max_seconds,'A31P2:TimeCap','Elapsed-time cap exceeded.');end
function t=times()
t=struct('utc',char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd''T''HH:mm:ss.SSSXXX')), ...
 'istanbul',char(datetime('now','TimeZone','Europe/Istanbul','Format','yyyy-MM-dd''T''HH:mm:ss.SSSXXX')));
end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'A31P2:PinFile','Cannot read %s',p);c=onCleanup(@()fclose(f));b=fread(f,Inf,'*uint8');
md=java.security.MessageDigest.getInstance('SHA-256');md.update(typecast(b(:),'int8'));h=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));
end
function n=outputBytes(p),d=dir(p);n=sum([d(~[d.isdir]).bytes]);end
function writeJson(p,value,cap)
b=unicode2native(jsonencode(value,'ConvertInfAndNaN',true),'UTF-8');assert(numel(b)<=cap,'A31P2:JSONCap','JSON cap exceeded.');
f=fopen(p,'wb');assert(f>=0,'A31P2:Write','Cannot write %s',p);c=onCleanup(@()fclose(f));assert(fwrite(f,b,'uint8')==numel(b),'A31P2:Write','Short write.');
end
function writeCSV(path,R)
f=fopen(path,'w','n','UTF-8');assert(f>=0,'A31P2:Write','Cannot write CSV.');c=onCleanup(@()fclose(f));
headers={'prediction_id','feature_set','method','fold','stream','stage','task','parentrow','group','group_order','truth', ...
 'eligible1','eligible2','eligible3','eligible4','score1','score2','score3','score4', ...
 'distance1','distance2','distance3','distance4','gap','prediction','tie','status','failure','state_id','historical_prediction_id'};
fprintf(f,'%s\n',strjoin(headers,','));
for ri=1:numel(R)
 r=R(ri);
 v={quote(r.prediction_id),quote(r.feature_set),quote(r.method),num(r.fold),quote(r.stream),num(r.stage),num(r.task), ...
  quote(r.parentrow),quote(r.group),num(r.group_order),num(r.truth)};
 for q=[double(ismember(1:4,r.eligible)),r.scores,r.distances,r.gap,r.prediction,double(r.tie)],v{end+1}=num(q);end %#ok<AGROW>
 v=[v,{quote(r.status),quote(r.failure),quote(r.state_id),quote(r.historical_prediction_id)}];fprintf(f,'%s\n',strjoin(v,','));
end
end
function s=num(x),if isnan(x),s='';else,s=sprintf('%.17g',x);end,end
function s=quote(x),s=['"' strrep(char(x),'"','""') '"'];end
function s=optionalText(v)
% readtable may represent an all-blank CSV text column as missing or NaN.
if iscell(v),v=v{1};end
if isempty(v) || all(ismissing(v),'all'),s='';else,s=char(string(v));end
end
