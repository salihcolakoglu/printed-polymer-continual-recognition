function varargout = a31p2_core_v1(action,varargin)
% A31P2_CORE_V1 Source-free deterministic primitives; authoring is not execution.
% No file access, RNG, learned weights, optimizer, or source-specific metadata.
% Global vocabulary is 1:4; feature dimension is explicitly 2 or 4.
switch lower(char(action))
 case 'fit_normalizer',varargout{1}=fitNormalizer(varargin{:});
 case 'normalize',varargout{1}=normalizeRows(varargin{:});
 case 'init_proto'
  d=dimension(varargin{1});
  varargout{1}=struct('dimension',d,'sumS',zeros(4,d), ...
   'countn',zeros(1,4,'uint64'),'active',false(1,4));
 case 'init_nn'
  d=dimension(varargin{1});
  varargout{1}=struct('dimension',d,'X',zeros(0,d),'y',zeros(0,1), ...
   'row_ids',{{}},'active',false(1,4));
 case 'admit_proto',varargout{1}=admitProto(varargin{:});
 case 'admit_nn',varargout{1}=admitNN(varargin{:});
 case 'predict',varargout{1}=predict(varargin{:});
 case 'decode',varargout{1}=decode(varargin{:});
 otherwise,error('A31P2:Action','Unknown source-free core action: %s',char(action));
end
end

function n=fitNormalizer(X,rowIDs)
validX(X);N=size(X,1);
assert(N>=2,'A31P2:NormalizerCount','At least two first-stage TRAIN rows required.');
ids=cellstr(string(rowIDs(:)));
assert(numel(ids)==N && numel(unique(ids))==N, ...
 'A31P2:NormalizerIDs','Normalizer row IDs must be unique and match rows.');
% Preserve the accepted A29 arithmetic and column-wise sample-SD convention.
mu=sum(X,1)/N;sd=sqrt(sum((X-mu).^2,1)/(N-1));
assert(all(isfinite(mu)) && all(isfinite(sd)) && all(sd>0), ...
 'A31P2:NormalizerSTOP','Nonfinite or nonpositive SD; no replacement allowed.');
n=struct('mean',mu,'sd',sd,'n',N,'train_row_ids',{ids});
end

function Z=normalizeRows(X,n)
validX(X);d=size(X,2);
assert(isequal(size(n.mean),[1 d]) && isequal(size(n.sd),[1 d]) && ...
 all(isfinite(n.mean)) && all(isfinite(n.sd)) && all(n.sd>0), ...
 'A31P2:NormalizerSTOP','Frozen normalizer shape or values invalid.');
Z=(X-n.mean)./n.sd;
assert(all(isfinite(Z),'all'),'A31P2:NormalizeNonfinite','Nonfinite normalized input.');
end

function s=admitProto(s,X,y)
validX(X);d=dimension(s.dimension);y=double(y(:));
assert(size(X,2)==d && size(X,1)==numel(y) && all(ismember(y,1:4)), ...
 'A31P2:Admission','Invalid PROTO feature shape or labels.');
assert(isequal(size(s.sumS),[4 d]) && isequal(size(s.countn),[1 4]) && ...
 isa(s.countn,'uint64') && isequal(size(s.active),[1 4]) && ...
 islogical(s.active) && all(isfinite(s.sumS),'all') && ...
 isequal(s.active,s.countn>0),'A31P2:ProtoState','Invalid PROTO state.');
assert(~any(s.active(unique(y))),'A31P2:RepeatedClass', ...
 'An already admitted class cannot be admitted again.');
% The caller supplies canonical group_order,label order; retain that row order.
for i=1:size(X,1)
 k=y(i);s.sumS(k,:)=s.sumS(k,:)+X(i,:);s.countn(k)=s.countn(k)+uint64(1);
end
s.active=s.countn>0;
assert(all(isfinite(s.sumS),'all'),'A31P2:ProtoNonfinite','Nonfinite accumulated sums.');
end

function s=admitNN(s,X,y,rowIDs)
validX(X);d=dimension(s.dimension);y=double(y(:));ids=cellstr(string(rowIDs(:)));
assert(size(X,2)==d && size(X,1)==numel(y) && numel(y)==numel(ids) && ...
 all(ismember(y,1:4)),'A31P2:Admission','Invalid NN admission shape or labels.');
assert(size(s.X,2)==d && size(s.X,1)==numel(s.y) && ...
 numel(s.row_ids)==numel(s.y) && all(isfinite(s.X),'all') && ...
 isequal(size(s.active),[1 4]) && islogical(s.active), ...
 'A31P2:NNState','Invalid NN state.');
assert(~any(s.active(unique(y))),'A31P2:RepeatedClass', ...
 'An already admitted class cannot be admitted again.');
assert(numel(unique(ids))==numel(ids) && ~any(ismember(ids,s.row_ids)), ...
 'A31P2:RepeatedRow','NN references must be unique admitted parents.');
s.X=[s.X;X];s.y=[s.y;y];s.row_ids=[s.row_ids(:);ids];s.active(unique(y))=true;
end

function out=predict(kind,s,X,eligible)
assert(isa(X,'double') && ismatrix(X) && ismember(size(X,2),[2 4]), ...
 'A31P2:PredictShape','Prediction inputs must be N-by-2 or N-by-4 binary64.');
c=classes(eligible);N=size(X,1);d=size(X,2);
D=nan(N,4);scores=nan(N,4);ok=all(isfinite(X),2);good=false;
switch lower(char(kind))
 case 'proto'
  need={'dimension','sumS','countn','active'};
  if isstruct(s) && isscalar(s) && all(isfield(s,need))
   good=isequal(s.dimension,d) && isequal(size(s.sumS),[4 d]) && ...
    isequal(size(s.countn),[1 4]) && isequal(size(s.active),[1 4]) && ...
    isa(s.countn,'uint64') && islogical(s.active) && ...
    all(s.active(c)) && all(s.countn(c)>0) && all(isfinite(s.sumS),'all');
  end
  if good
   for k=c
    center=s.sumS(k,:)/double(s.countn(k));D(ok,k)=sum((X(ok,:)-center).^2,2);
   end
  end
 case 'nn'
  need={'dimension','X','y','row_ids','active'};
  if isstruct(s) && isscalar(s) && all(isfield(s,need))
   good=isequal(s.dimension,d) && isa(s.X,'double') && ismatrix(s.X) && ...
    size(s.X,2)==d && size(s.X,1)==numel(s.y) && ...
    numel(s.row_ids)==numel(s.y) && isequal(size(s.active),[1 4]) && ...
    islogical(s.active) && all(s.active(c)) && all(ismember(c,s.y)) && ...
    all(isfinite(s.X),'all');
  end
  if good
   q=find(ok)';
   for k=c
    refs=s.X(s.y==k,:);
    for i=q,D(i,k)=min(sum((refs-X(i,:)).^2,2));end
   end
  end
 otherwise,error('A31P2:PredictKind','Only proto and nn are supported.');
end
scores(:,c)=-D(:,c);out=decode(scores,c);
out.scores=scores;out.distances=D;
for i=1:N
 if ~ok(i),out.failure{i}='nonfinite_query';
 elseif ~good,out.failure{i}='nonfinite_state_or_missing_candidate';end
end
end

function out=decode(scores,eligible)
assert(isa(scores,'double') && ismatrix(scores) && size(scores,2)==4, ...
 'A31P2:DecodeShape','Scores must be N-by-4 binary64.');
c=classes(eligible);N=size(scores,1);
out=struct('prediction',nan(N,1),'gap',nan(N,1),'tie',false(N,1), ...
 'status',{repmat({'failure'},N,1)}, ...
 'failure',{repmat({'nonfinite_eligible_score'},N,1)});
for i=1:N
 v=scores(i,c);if any(~isfinite(v)),continue;end
 best=max(v);winners=c(v==best);ranked=sort(v,'descend');
 out.prediction(i)=min(winners);out.tie(i)=numel(winners)>1;
 out.gap(i)=ranked(1)-ranked(2);out.status{i}='valid';out.failure{i}='';
end
end

function c=classes(v)
if islogical(v)
 assert(isequal(size(v),[1 4]),'A31P2:EligibleShape','Logical eligibility must be 1-by-4.');
 c=find(v);
else
 assert(isnumeric(v) && isvector(v),'A31P2:EligibleShape','Eligible global IDs required.');
 c=double(v(:)');assert(numel(unique(c))==numel(c), ...
  'A31P2:EligibleDuplicate','Duplicate eligible IDs are invalid.');c=sort(c);
end
assert(numel(c)>=2 && all(ismember(c,1:4)), ...
 'A31P2:Eligible','Two to four distinct global candidates required.');
end

function d=dimension(d)
assert(isa(d,'double') && isscalar(d) && ismember(d,[2 4]), ...
 'A31P2:Dimension','Feature dimension must be exactly 2 or 4.');
end

function validX(X)
assert(isa(X,'double') && ismatrix(X) && ismember(size(X,2),[2 4]) && ...
 all(isfinite(X),'all'),'A31P2:Input','Finite N-by-2 or N-by-4 binary64 input required.');
end
