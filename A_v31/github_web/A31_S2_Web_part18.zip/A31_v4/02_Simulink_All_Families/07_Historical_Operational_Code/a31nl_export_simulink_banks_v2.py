"""Structural saved-state projection only. No network forward or training.

All three families and every logical request map either to a previously accepted A30 trace row or to
one exact unique new Simulink request. Expected outputs remain outside banks.
"""
from pathlib import Path
import argparse,csv,hashlib,json,math,struct,sys
from collections import Counter

W=Path(r'C:\Springer ve Tübitak Ulakbilim Tr Dizin Çalışmaları')
S=Path(__file__).resolve().parents[1]
PINNED={}

def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve(strict=True);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def verify(ref):
 p=Path(ref['path']).resolve(strict=True);p.relative_to(W)
 k=(str(p),int(ref['bytes']),ref['sha256'])
 if k not in PINNED:
  actual=pin(p);assert actual['bytes']==int(ref['bytes'])and actual['sha256']==ref['sha256'],str(p);PINNED[k]=actual
 return p
def write(p,obj):
 assert not p.exists(),str(p)
 p.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n',encoding='utf-8',newline='\n')
def array(v):return v if isinstance(v,list)else[v]
def finite(v,n):
 assert isinstance(v,list)and len(v)==n and all(isinstance(x,(int,float))and math.isfinite(x)for x in v)
 return [float(x)for x in v]
def bits(v):return b''.join(struct.pack('<d',float(x))for x in v)
def equal(a,b):
 if isinstance(a,list)or isinstance(b,list):return isinstance(a,list)and isinstance(b,list)and len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
 if a is None or b is None:return a is None and b is None
 if isinstance(a,(int,float))and isinstance(b,(int,float)):return bits([a])==bits([b])
 return a==b
def signature(chart,kind,D,book,theta,mean,sd,books,raw,mask):
 """Exact binary64 inference identity, not optimizer/history identity."""
 assert kind in(2,3)and D in(4,8)and (kind,D)in((2,4),(3,8))
 assert (kind==2 and book==0)or(kind==3 and book in(1,2))
 theta=finite(theta,12+5*D);mean=finite(mean,2);sd=finite(sd,2);raw=finite(raw,2)
 assert all(x>0 for x in sd)and len(mask)==4 and set(mask)<={0,1}and sum(mask)>=2
 assert len(books)==8 and all(len(row)==8 and set(row)<={0,1}for row in books)
 blob=(b'A31_NL_FROZEN_INFERENCE_BINARY64_V1\0'+bytes.fromhex(chart)+
       struct.pack('<III',kind,D,book)+bits(theta+mean+sd+[x for row in books for x in row]+raw)+bytes(mask))
 return hashlib.sha256(blob).hexdigest(),blob
def model_signature(chart,kind,D,book,theta,mean,sd,books):
 # Two fixed dummy raw values and all-eligible mask only bind model operands.
 return signature(chart,kind,D,book,theta,mean,sd,books,[0.0,0.0],[1,1,1,1])
def target35(pred):
 D=int(pred['D']);elig=[int(x)for x in array(pred['eligible'])]
 assert elig==sorted(set(elig))and 2<=len(elig)<=4 and set(elig)<={1,2,3,4}
 z=finite(pred['Z'],2);logits=finite(pred['logits'],D)
 outputs=array(pred['outputs']);assert len(outputs)==D
 scores=array(pred['scores']);dist=array(pred['distances']);assert len(scores)==len(dist)==len(elig)
 s=[None]*4;d=[None]*4
 for c,x,y in zip(elig,scores,dist):s[c-1]=x;d[c-1]=y
 assert pred['valid']is True and pred['failure']is False
 return z+logits+[None]*(8-D)+outputs+[None]*(8-D)+s+d+[pred['label'],pred['gap'],int(pred['tie']),1]+[int(c in elig)for c in range(1,5)]+[None]
def ledger(out,result):
 sys.path.insert(0,str(W/'A_ARASTIRMASI/A_v25.0_2026_10_11/08_Inceleme'))
 from a25_log import log
 return log('A31 NL4/OH8/WH8 için tekil Simulink çıkarım bankaları yapısal olarak hazırlandı',
  'Yirmi kabul edilmiş yeni batch, WH700 kabul kataloğu ve eski A30 banka ve trace kanıtları pinlerle okundu. Sayısal durum, ölçek, ham girdi ve aday maskesinin binary64 eşitliğiyle eski örnekler yeniden kullanıldı; yeni tam eşit talepler tek örneğe bağlandı. Beklenen sonuçlar model bankasına konmadı. Eğitim ve ileri model hesabı yapılmadı.',result,
  status='reviewed',type='A31_NL_Simulink_structural_export',objective='Cover all accepted NL4/OH8/WH8 saved inference requests without repeating old A30 cases.',reason='Only previously unverified unique inference operands need a new actual Simulink execution.',evidence=[str(out/'structural_export_receipt_v2.json')],uncertainty='Structural identity and projected expected records are not a completed Simulink validation.',next_step='Independent complete structural-bank review, exact resource freeze and one root-owned Simulink execution.')


WH_NAMES={'F00_STATIC':'F00','F25':'F25','F50':'F50','F75':'F75','F100_SELF_TARGET':'F100','UP_CLOSED_LINEAR':'UP','DOWN_CLOSED_LINEAR':'DOWN'}

def fold_payloads(fold,recs,wh_entries):
 """Yield normalized job metadata but retain each original scientific payload."""
 for record in recs:
  if record['outer_fold']!=fold:continue
  result=load(verify(record['result_pin']));assert result['failure_count']==0 and result['batch_id']==record['batch_id']
  for index1,R in enumerate(array(result['jobs']),1):
   yield record,index1,R,R['job'],None
 groups={}
 for entry in wh_entries:
  if entry['outer_fold']==fold:groups.setdefault(entry['source_result_pin']['sha256'],[]).append(entry)
 for entries in groups.values():
  source=entries[0]['source_result_pin'];result=load(verify(source));saved=array(result['jobs'])
  for entry in entries:
   for name in ['source_result_pin','source_audit_pin','source_producer_pin','source_prediction_CSV_pin']:verify(entry[name])
   audit=load(verify(entry['source_audit_pin']));assert audit['accepted']is True and audit['failed_checks']==0
   assert audit['result_pin']['sha256']==source['sha256']and entry['source_job_id']in audit['completed_job_ids']
   index1=int(entry['source_job_index1']);R=saved[index1-1];original=R['job']
   assert original['job_id']==entry['source_job_id']and original['outer_fold']==fold
   assert original['schedule_id']==entry['profile_id']and original['alpha']==entry['alpha_by_task']
   payload={k:R[k]for k in ['normalizer','initial_state','stages','predictions','metrics']}
   actual=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()
   assert actual==entry['canonical_saved_scientific_payload_SHA256']
   assert len(array(R['predictions']))==entry['saved_prediction_rows']and len(array(R['stages']))==3
   normalized=dict(original);normalized.update({'family':'WH8','D':8,'schedule_id':WH_NAMES[entry['profile_id']]})
   record={'result_pin':source,'audit_pin':entry['source_audit_pin']}
   yield record,index1,R,normalized,entry

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--protocol',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
 out=a.out.resolve();out.relative_to(S/'01_Input');assert not out.exists(),'No overwrite'
 prot=load(a.protocol);assert prot['schema']=='A31_NL_SIMULINK_PROSPECTIVE_PROTOCOL_V2'and prot['id']=='A31_ALL_NR_FROZEN_INFERENCE_PARITY_2026_10_25_V2'
 chartref=prot['A30_chart_pin'];verify(chartref);chart=chartref['sha256']
 progress_path=verify(prot['source_progress_pin']);progress=load(progress_path)
 assert progress['schema']=='A31_NL_PHASE_PROGRESS_V1'and progress['status']=='COMPLETE_ALL_FIXED_BATCHES_INDEPENDENTLY_ACCEPTED'
 recs=progress['accepted_records'];assert len(recs)==20
 co=load(verify(prot['source_coordinator_receipt_pin']));assert co['complete']is True and verify(co['progress_pin'])==progress_path and co['accepted_jobs']==1400
 master=load(verify(co['master_plan_pin']));assert co['master_plan_pin']['sha256']==progress['master_plan_sha256']
 contract=load(verify(master['source_contract']['job_contract_pin']));bundle=load(verify(master['source_contract']['input_pin']))
 assert verify(contract['input_bundle_pin'])==verify(master['source_contract']['input_pin'])
 jobs={j['job_id']:j for j in contract['jobs']};assert len(jobs)==1400
 parents={r['parentrow']:r for r in bundle['records']};assert len(parents)==104
 books=[[int(i==j)for i in range(4)]+[0]*4 for j in range(4)]+bundle['codebook_WH8']
 oldaudit=load(verify(prot['A30_complete_audit_pin']));assert oldaudit['status']=='PASS'and oldaudit['failure_count']==0 and oldaudit['all_five_complete']is True
 oldexport=load(verify(prot['A30_structural_export_pin']));assert len(oldexport['folds'])==5
 for record,batch in zip(recs,master['batches']):
  assert record['batch_id']==batch['batch_id']and record['completed_job_ids']==batch['job_ids']and len(batch['job_ids'])==70
  audit=load(verify(record['audit_pin']));assert audit['accepted']is True and audit['failed_checks']==0 and audit['completed_job_ids']==record['completed_job_ids']
  for rk,ak in [('result_pin','result_pin'),('producer_receipt_pin','producer_receipt_pin'),('new_cache_pin','cache_pin'),('predictions_pin','csv_pin')]:
   assert verify(record[rk])==verify(audit[ak])and record[rk]['sha256']==audit[ak]['sha256']
 assert {x for r in recs for x in r['completed_job_ids']}==set(jobs)
 wh_catalog_path=verify(prot['WH700_catalog_pin']);assert prot['WH700_catalog_pin']['sha256']=='c32bae90dc6294d39939904969df9cbd62afb7b68780f87d23933857c9acc441'
 wh_identity_path=verify(prot['WH700_identity_proof_pin']);assert prot['WH700_identity_proof_pin']['sha256']=='f3e9d050d2afd390fff37ab1afca835ddef72914fb6d74584c76fc912271e315'
 wh_audit_path=verify(prot['WH700_independent_audit_pin']);assert prot['WH700_independent_audit_pin']['sha256']=='54a6544308bd755fecc7f12a7a6cc3d7b09805f4594624912d5149f5268d9eaf'
 wh_identity=load(wh_identity_path);wh_audit=load(wh_audit_path)
 assert wh_identity['status']=='PASS_700_EXISTING_JOB_IDENTITIES_AND38220_SAVED_DECISIONS_NO_NEW_MODEL_CALLS'and verify(wh_identity['catalog_pin'])==wh_catalog_path
 assert wh_audit['accepted']is True and wh_audit['failed_checks']==0 and verify(wh_audit['author_catalog_pin'])==wh_catalog_path
 wh_entries=load(wh_catalog_path)['entries'];assert len(wh_entries)==700
 assert len({e['source_job_id']for e in wh_entries})==700
 out.mkdir(parents=True);foldreceipts=[];global_counts=Counter();seen_jobs=set();F00jobs=set()
 for fold in range(1,6):
  oldfold=next(q for q in oldexport['folds']if q['fold']==fold)
  filepins={Path(q['path']).name:q for q in oldfold['files']}
  bank=load(verify(filepins['bank.json']));oldmap=load(verify(filepins['model_map.json']));oldrefs=load(verify(filepins['reference_predictions.json']))
  assert bank['fold']==fold and len(bank['theta'])==len(oldmap)==522 and equal(bank['books'],books)
  with verify(filepins['inputs.csv']).open(encoding='utf-8-sig',newline='')as fh:oldinputs=[[float(x)for x in row]for row in csv.reader(fh)]
  oldev=next(q for q in oldaudit['per_fold']if q['fold']==fold)
  traces=load(verify(oldev['trace']))['values'];assert len(oldrefs)==len(oldinputs)==len(traces)==oldev['rows']
  for key in ('SLX_pin','semantic_pin'):verify(oldev['saved_model'][key])
  oldlookup={}
  for row1,(u,tr,ref)in enumerate(zip(oldinputs,traces,oldrefs),1):
   mid=int(u[2]);meta=bank['meta'][mid-1];kind,D,book=map(int,meta[:3])
   if kind not in(2,3):continue
   assert int(ref['model_id'])==mid and int(oldmap[mid-1]['model_id'])==mid
   mask=[int(x)for x in u[3:]];theta=bank['theta'][mid-1][:12+5*D]
   digest,blob=signature(chart,kind,D,book,theta,bank['mean'],bank['sd'],books,u[:2],mask)
   evidence={'trace_pin':oldev['trace'],'trace_row1':row1,'source_model_id':mid,'source_model_mapping':oldmap[mid-1],
             'bank_pin':filepins['bank.json'],'model_map_pin':filepins['model_map.json'],'inputs_pin':filepins['inputs.csv'],
             'reference_predictions_pin':filepins['reference_predictions.json'],'SLX_pin':oldev['saved_model']['SLX_pin'],'semantic_pin':oldev['saved_model']['semantic_pin']}
   if digest in oldlookup:
    assert blob==oldlookup[digest][0]and equal(tr[:34],oldlookup[digest][1]['values35_verbatim'][:34]),'Conflicting exact old inference evidence'
   else:oldlookup[digest]=(blob,{'origin':evidence,'values35_verbatim':tr})
  newmodels={};newmodelrows=[];newmodelmeta=[];newmodelmap=[];newlookup={};newinputs=[];newcases=[];logical=[];oldreused={};counts=Counter()
  foldnorm=None
  for record,jobindex1,R,j,wh_entry in fold_payloads(fold,recs,wh_entries):
    if wh_entry is None:assert j==jobs[j['job_id']]
    assert j['job_id']not in seen_jobs;seen_jobs.add(j['job_id'])
    D=int(j['D']);kind=2 if D==4 else 3;book=0 if D==4 else (2 if j['family']=='WH8'else 1)
    assert j['family']in('NL4','OH8','WH8')and D==(4 if j['family']=='NL4'else 8)and j['outer_fold']==fold
    n=R['normalizer'];mean=finite(n['mean'],2);sd=finite(n['sd'],2)
    if foldnorm is None:foldnorm={'mean':mean,'sd':sd}
    assert equal(mean,foldnorm['mean'])and equal(sd,foldnorm['sd'])and equal(mean,bank['mean'])and equal(sd,bank['sd'])
    stages={int(q['stage']):q for q in array(R['stages'])};assert set(stages)=={1,2,3}
    if j['schedule_id']=='F00':F00jobs.add(j['job_id'])
    for predindex1,original_prediction in enumerate(array(R['predictions']),1):
     p=dict(original_prediction);p['D']=D
     assert p['job_id']==j['job_id']and p['valid']is True and p['failure']is False
     rawrec=parents[p['parentrow']];assert rawrec['label']==p['truth']and rawrec['outer_fold']==fold
     raw=finite(rawrec['X'],2);eligible=[int(x)for x in array(p['eligible'])];mask=[int(c in eligible)for c in range(1,5)]
     assert eligible==sorted(set(eligible))and len(eligible)>=2
     theta=finite(stages[int(p['stage'])]['final_state']['theta'],12+5*D)
     digest,blob=signature(chart,kind,D,book,theta,mean,sd,books,raw,mask)
     expected=target35(p)
     origin={'result_pin':record['result_pin'],'audit_pin':record['audit_pin'],'job_index1':jobindex1,'job_id':j['job_id'],
             'prediction_index1':predindex1,'family':j['family'],'D':D,'stream':j['stream'],'replay':j['replay'],
             'profile':j['schedule_id'],'seed':j['seed'],'outer_fold':fold,'stage':p['stage'],'task':p['task'],
             'parentrow':p['parentrow'],'truth':p['truth'],'eligible':eligible,'fit_sha256':p['fit_sha256'],
             'source_family_schema':'ACCEPTED_WH700_CATALOG_ORIGINAL_PAYLOAD'if wh_entry is not None else'ACCEPTED_NL_OH_BATCH_PAYLOAD',
             'WH700_payload_sha256':wh_entry['canonical_saved_scientific_payload_SHA256']if wh_entry is not None else None}
     logicalrow={'logical_index1':len(logical)+1,'signature_sha256':digest,'source':origin,'expected_source_channels35':expected}
     if digest in oldlookup:
      assert blob==oldlookup[digest][0]
      if digest not in oldreused:oldreused[digest]={'signature_sha256':digest,**oldlookup[digest][1]}
      logicalrow.update({'evidence_kind':'ACCEPTED_A30_TRACE_REUSED_NO_FORWARD','old_trace_signature':digest});counts['old_A30_logical_rows_reused']+=1
     else:
      assert j['schedule_id']!='F00','Every F00 request must reuse exact A30 evidence; no fallback simulation'
      if digest in newlookup:
       priorblob,index1=newlookup[digest];assert priorblob==blob
       # Preserve each logical expected payload independently. Matrix batching
       # may alter last-bit saved arithmetic despite identical inference operands;
       # the later auditor compares every logical request at frozen tolerances.
       counts['new_logical_duplicates']+=1
      else:
       md,mb=model_signature(chart,kind,D,book,theta,mean,sd,books)
       if md not in newmodels:
        mid=len(newmodelrows)+1;newmodels[md]=(mb,mid);newmodelrows.append(theta+[0.0]*(52-len(theta)));newmodelmeta.append([kind,D,book,0,0])
        newmodelmap.append({'model_id':mid,'model_signature_sha256':md,'source':origin})
       else:assert newmodels[md][0]==mb
       mid=newmodels[md][1];index1=len(newinputs)+1;newlookup[digest]=(blob,index1)
       newinputs.append(raw+[mid]+mask)
       newcases.append({'new_query_index1':index1,'signature_sha256':digest,'model_id':mid,'source':origin,'expected_source_channels35':expected})
      logicalrow.update({'evidence_kind':'NEW_UNIQUE_SIMULINK_QUERY_PENDING','new_query_index1':index1});counts['new_logical_rows']+=1
     logical.append(logicalrow);counts['logical_rows']+=1
  assert counts['logical_rows']==(26460 if fold==1 else 22050)
  assert len(newinputs)<=counts['logical_rows']and len(newmodelrows)<=1260
  qdir=out/f'fold_{fold}';qdir.mkdir()
  write(qdir/'bank.json',{'schema':'A31_NL_FROZEN_INFERENCE_BANK_V2','fold':fold,'theta':newmodelrows,'meta':newmodelmeta,
        'mean':foldnorm['mean'],'sd':foldnorm['sd'],'refs':[[0.0]*3 for _ in range(252)],'books':books})
  write(qdir/'new_model_map.json',newmodelmap);write(qdir/'new_query_reference.json',newcases)
  write(qdir/'all_logical_mapping.json',logical);write(qdir/'old_reused_trace_evidence.json',list(oldreused.values()))
  with(qdir/'inputs.csv').open('w',encoding='utf-8',newline='')as fh:csv.writer(fh,lineterminator='\n').writerows(newinputs)
  counts.update({'new_unique_models':len(newmodelrows),'new_unique_queries':len(newinputs),'old_unique_trace_rows':len(oldreused)})
  foldreceipts.append({'fold':fold,'counts':dict(counts),'files':[pin(p)for p in sorted(qdir.iterdir())]});global_counts.update(counts)
 assert len(seen_jobs)==2100 and len(F00jobs)==300 and global_counts['logical_rows']==114660
 assert global_counts['old_A30_logical_rows_reused']>=16380 and global_counts['new_unique_queries']<=98280
 receipt={'schema':'A31_NL_SIMULINK_STRUCTURAL_EXPORT_V2','status':'STRUCTURAL_EXPORT_PENDING_INDEPENDENT_BANK_REVIEW',
          'protocol_pin':pin(a.protocol),'chart_pin':chartref,'new_source_progress_pin':pin(progress_path),
          'old_complete_audit_pin':prot['A30_complete_audit_pin'],'old_structural_export_pin':prot['A30_structural_export_pin'],
          'WH700_catalog_pin':prot['WH700_catalog_pin'],'WH700_identity_proof_pin':prot['WH700_identity_proof_pin'],'WH700_independent_audit_pin':prot['WH700_independent_audit_pin'],
          'full_F00_trajectories_required_reuse':300,'logical_jobs':2100,'logical_stages':6300,'counts':dict(global_counts),'folds':foldreceipts,
          'dedup_key':'chartSHA + kind/D/book selector + active theta + mean/sd + complete 8x8 codebooks + raw2 + four eligible bits; all floats little-endian binary64',
          'selector_note':'Old trace35 and its selector are retained verbatim. New model selectors apply only to new unique queries; logical mapping binds the two origins.',
          'optimizer_and_truth_not_model_inputs':True,'expected_outputs_not_in_bank':True,
          'sourcefiles_modified':False,'training_calls':0,'network_forward_calls':0,'Simulink_calls':0,'builder_pin':pin(__file__)}
 write(out/'structural_export_receipt_v2.json',receipt)
 event=ledger(out,receipt);print(json.dumps({'event_id':event,'receipt':pin(out/'structural_export_receipt_v2.json'),'counts':dict(global_counts)},ensure_ascii=False))

if __name__=='__main__':
 sys.stdout.reconfigure(encoding='utf-8');main()
