function a31nl_simulink_run_v2(versionRoot,outDir,cfg)
% Only the root-owned pinned launcher may call this prospective entry point.
% Every actual query is a new exact inference operand; old A30 cases are absent.
assert(strcmp(cfg.mode,'source')&&logical(cfg.source_run_authorized), ...
 'A31NLSLX:Admission','Fresh source admission is required.');
assert(strcmp(cfg.admission_token,'A31_ALL_NR_SIMULINK_ADMITTED_FROZEN_INFERENCE_V2'), ...
 'A31NLSLX:Admission','Wrong admission token.');
assert(isfolder(outDir)&&~isfile(fullfile(outDir,'run_complete.json')));
assert(strcmp(char(cfg.protocol_id),'A31_ALL_NR_FROZEN_INFERENCE_PARITY_2026_10_25_V2'));
assert(numel(cfg.folds)==5&&cfg.expected_total_new_rows<=98280);
cd(outDir);
Simulink.fileGenControl('set','CacheFolder',fullfile(outDir,'cache'), ...
 'CodeGenFolder',fullfile(outDir,'codegen'),'createDir',true);
source=fileread(fullfile(versionRoot,'03_Code','a30_inference_chart_v1.m'));
assert(numel(source)<12000);
summaries=cell(5,1);totalRows=0;
clock=tic;
for f=1:5
 item=cfg.folds(f);assert(item.fold==f&&item.expected_rows>=0&&item.expected_rows<=22680);
 foldOut=fullfile(outDir,sprintf('fold_%d',f));assert(~isfolder(foldOut));mkdir(foldOut);
 bank=jsondecode(fileread(item.bank_path));
 assert(strcmp(bank.schema,'A31_NL_FROZEN_INFERENCE_BANK_V2')&&bank.fold==f);
 theta=double(bank.theta);meta=double(bank.meta);mu=reshape(double(bank.mean),1,2);sd=reshape(double(bank.sd),1,2);
 if item.expected_rows==0&&isempty(theta)&&isempty(meta),theta=zeros(0,52);meta=zeros(0,5);end
 refs=double(bank.refs);books=double(bank.books);Nmodels=size(theta,1);
 assert(Nmodels<=1260&&isequal(size(theta),[Nmodels,52])&&isequal(size(meta),[Nmodels,5]));
 assert(isequal(size(refs),[252,3])&&isequal(size(books),[8,8]));
 assert(all(isfinite(theta),'all')&&all(isfinite(mu))&&all(isfinite(sd))&&all(sd>0));
 assert(all(ismember(books,[0 1]),'all')&&all(ismember(meta(:,1),[2 3])));
 if item.expected_rows==0
  assert(Nmodels==0);summaries{f}=struct('fold',f,'rows',0,'new_model_count',0, ...
   'simulation_executed',false,'reason','All exact inference requests reuse accepted A30 evidence.');
  write_json(fullfile(foldOut,'run_complete.json'),summaries{f},10000);continue;
 end
 assert(Nmodels>=1);
 for m=1:Nmodels
  assert((meta(m,1)==2&&meta(m,2)==4&&meta(m,3)==0)|| ...
   (meta(m,1)==3&&meta(m,2)==8&&ismember(meta(m,3),[1 2])));
 end
 queries=readmatrix(item.inputs_path);assert(isequal(size(queries),[item.expected_rows,7]));
 assert(all(isfinite(queries),'all')&&all(queries(:,3)==floor(queries(:,3)))&& ...
  all(queries(:,3)>=1&queries(:,3)<=Nmodels)&&all(ismember(queries(:,4:7),[0 1]),'all')&&all(sum(queries(:,4:7),2)>=2));
 name=sprintf('a31nl_frozen_inference_f%d',f);assert(~bdIsLoaded(name));
 new_system(name);cleanup=onCleanup(@()close_owned(name)); %#ok<NASGU>
 set_param(name,'SolverType','Fixed-step','Solver','FixedStepDiscrete', ...
  'FixedStep','1','StartTime','0','StopTime','1','ReturnWorkspaceOutputs','on', ...
  'SaveTime','on','TimeSaveName','tout','SignalLogging','off');
 ws=get_param(name,'ModelWorkspace');
 names={'theta','meta','mu','sd','refs','books'};values={theta,meta,mu,sd,refs,books};
 assignin(ws,'queries',timeseries(zeros(2,7),[0;1]));
 add_block('simulink/Sources/From Workspace',[name,'/Raw records and eligibility'], ...
  'VariableName','queries','SampleTime','1','Interpolate','off', ...
  'OutputAfterFinalValue','Holding final value','Position',[25,70,195,110]);
 add_block('simulink/Signal Attributes/Signal Specification',[name,'/Seven channels'], ...
  'Dimensions','7','OutDataTypeStr','double','Position',[225,70,325,110]);
 add_line(name,'Raw records and eligibility/1','Seven channels/1');
 block=[name,'/Normalize and infer'];
 add_block('simulink/User-Defined Functions/MATLAB Function',block,'Position',[470,65,700,360]);
 chart=find(sfroot,'-isa','Stateflow.EMChart','Path',block);
 script=strrep(source,'function y = a30_inference_chart_v1(u,theta,meta,mu,sd,refs,books)', ...
  'function y = fcn(u,theta,meta,mu,sd,refs,books)');chart.Script=script;
 add_line(name,'Seven channels/1','Normalize and infer/1');
 for j=1:6
  assignin(ws,names{j},values{j});
  add_block('simulink/Sources/Constant',[name,'/',names{j}], ...
   'Value',names{j},'Position',[245,150+j*50,355,180+j*50]);
  add_line(name,[names{j},'/1'],['Normalize and infer/',num2str(j+1)]);
 end
 add_block('simulink/Sinks/To Workspace',[name,'/Full numeric trace'], ...
  'VariableName','trace','SaveFormat','Array','MaxDataPoints','inf', ...
  'Decimation','1','SampleTime','1','Position',[770,165,905,205]);
 add_line(name,'Normalize and infer/1','Full numeric trace/1');
 set_param(name,'Description', ...
  'A31 saved NL4/OH8/WH8 inference only. Raw E MPa and Shore D, frozen first-task TRAIN normalizer, saved model, eligible labels. Tick is query index. No truth, expected output, teacher, objective, optimizer or physical dynamics enters inference.');
 modelPath=fullfile(foldOut,[name,'.slx']);save_system(name,modelPath);close_system(name,0);
 % Cold loading is mandatory; runtime inference consumes the saved model.
 load_system(modelPath);ws=get_param(name,'ModelWorkspace');
 for j=1:6,assert(isequaln(evalin(ws,names{j}),values{j}));end
 chart=find(sfroot,'-isa','Stateflow.EMChart','Path',block);assert(isequal(chart.Script,script));
 assignin(ws,'queries',timeseries(queries,(0:size(queries,1)-1)'));
 set_param(name,'StopTime',num2str(size(queries,1)-1));
 simClock=tic;simout=sim(name);simSeconds=toc(simClock);
 trace_raw=simout.get('trace');time=simout.get('tout');raw_trace_size=size(trace_raw);N=size(queries,1);
 if isequal(size(trace_raw),[N,35])
  trace=trace_raw;axes='samples_by_channels';
 elseif isequal(size(trace_raw),[35,1,N])
  trace=permute(trace_raw,[3,1,2]);axes='channels_singleton_samples_permute_312';
 elseif isequal(size(trace_raw),[1,35,N])
  trace=permute(trace_raw,[3,2,1]);axes='singleton_channels_samples_permute_321';
 else,error('A31NLSLX:TraceAxes','Unexpected ToWorkspace trace axes.');end
 assert(isequal(size(trace),[N,35])&&isequal(time(:),(0:N-1)'));
 assert(all(trace(:,30)==1)&&all(ismember(trace(:,27),1:4))&&all(isfinite(trace(:,1:2)),'all'));
 writematrix(trace,fullfile(foldOut,'actual_trace.csv'));
 write_json(fullfile(foldOut,'actual_trace.json'),struct('time',time(:),'values',trace),26000000);
 save(fullfile(foldOut,'actual_trace.mat'),'trace','trace_raw','time','-v7');
 semantic=struct('schema','A31_NL_SAVED_SLX_READBACK_V2','fold',f,'cold_reopened',true, ...
  'model_path',modelPath,'theta',evalin(ws,'theta'),'meta',evalin(ws,'meta'), ...
  'mean',evalin(ws,'mu'),'sd',evalin(ws,'sd'),'refs',evalin(ws,'refs'),'books',evalin(ws,'books'), ...
  'chart_script',chart.Script,'blocks',{find_system(name,'SearchDepth',1,'Type','Block')}, ...
  'lines',{get_param(find_system(name,'FindAll','on','SearchDepth',1,'Type','line'),'Name')}, ...
  'rows',N,'columns',35,'raw_trace_size',raw_trace_size,'trace_axes',axes, ...
  'simulation_seconds',simSeconds,'MATLAB_version',version,'Simulink_version',ver('Simulink'));
 write_json(fullfile(foldOut,'saved_model_semantic_readback.json'),semantic,3000000);
 summaries{f}=struct('fold',f,'rows',N,'new_model_count',Nmodels,'simulation_executed',true, ...
  'cold_reopened',true,'simulation_seconds',simSeconds,'training',false,'physical_validation',false);
 write_json(fullfile(foldOut,'run_complete.json'),summaries{f},10000);
 totalRows=totalRows+N;close_system(name,0);clear cleanup;
end
assert(totalRows==cfg.expected_total_new_rows);
write_json(fullfile(outDir,'run_complete.json'),struct('schema','A31_NL_SIMULINK_RUN_COMPLETE_V2', ...
 'status','COMPLETE_PENDING_INDEPENDENT_SAVED_INFERENCE_AUDIT','folds',{summaries}, ...
 'new_unique_rows',totalRows,'elapsed_seconds',toc(clock),'training',false, ...
 'teacher_forward',false,'optimizer_validation',false,'physical_validation',false),100000);
end
function close_owned(name)
if bdIsLoaded(name),close_system(name,0);end
end
function write_json(path,value,cap)
assert(~isfile(path));
% Bounded shapes above imply <=26 MB trace JSON and <=3 MB semantic JSON.
% The owned guardian separately caps the simultaneous aggregate output tree.
b=unicode2native(jsonencode(value,'ConvertInfAndNaN',true),'UTF-8');assert(numel(b)<=cap);
f=fopen(path,'wb');assert(f>=0);cl=onCleanup(@()fclose(f)); %#ok<NASGU>
assert(fwrite(f,b,'uint8')==numel(b));
end
