function out=a31_public_simulink_v4(packageRoot,fold,mode)
% SPDX-License-Identifier: MIT
% Load one NEW saved native bank from package-relative paths.
% inspect: read embedded bank and input dimensions, then close owned model.
% hydrate: load actual CSV queries into its workspace and leave it open.
% simulate-stored: explicitly simulate one fold; never called by inspect.
% Archived A30 reused-case models are separate historical proof, not in these
% five new banks. Exact native selective gap ordering remains HOLD.
if nargin<3,mode='inspect';end
assert(isscalar(fold)&&ismember(fold,1:5)&&any(strcmp(mode,{'inspect','hydrate','simulate-stored'})), ...
 'A31PublicS:Arguments','A fold1..5 and an explicit supported mode are required.');
addpath(fullfile(packageRoot,'PUBLIC_MATLAB'),'-begin');
rel=sprintf('02_Simulink_All_Families/01_New_Native/fold_%d/',fold);
modelPath=a31_public_path_v4(packageRoot,[rel sprintf('a31nl_frozen_inference_f%d.slx',fold)]);
csvPath=a31_public_path_v4(packageRoot,[rel 'inputs.csv']);
[~,name]=fileparts(modelPath);assert(~bdIsLoaded(name), ...
 'A31PublicS:Ownership','Close the same-named model yourself before this loader; it never attaches to or closes a user model.');
load_system(modelPath);owned=true;cleanup=onCleanup(@finish);
ws=get_param(name,'ModelWorkspace');assert(strcmp(ws.DataSource,'Model File'), ...
 'A31PublicS:Workspace','Expected saved embedded Model File workspace.');
queries=readmatrix(csvPath);
assert(isa(queries,'double')&&size(queries,2)==7&&size(queries,1)>1&&size(queries,1)<=20000&&all(isfinite(queries),'all'), ...
 'A31PublicS:Queries','Stored query matrix must be finite N-by-7 with bounded rows.');
out=struct('schema','A31_PUBLIC_NATIVE_CSV_LOADER_V4','fold',fold,'mode',char(mode), ...
 'model_name',name,'model_member',[rel sprintf('a31nl_frozen_inference_f%d.slx',fold)], ...
 'query_member',[rel 'inputs.csv'],'stored_query_rows',size(queries,1), ...
 'workspace_source','Model File','training_updates',0,'teacher_construction',0, ...
 'simulation_performed',false,'full_native_protocol_accepted',false, ...
 'scope','New unique-case banks only; archived reuse and exact-gap-order HOLD are separately documented.');
if ~strcmp(mode,'inspect')
 assignin(ws,'queries',timeseries(queries,(0:size(queries,1)-1)'));
 set_param(name,'StopTime',num2str(size(queries,1)-1));
 if strcmp(mode,'hydrate')
  owned=false;out.left_open_for_user=true;
 else
  out.simulation=sim(name);out.simulation_performed=true;
 end
end
 function finish
  if owned&&bdIsLoaded(name),close_system(name,0);end
 end
end
