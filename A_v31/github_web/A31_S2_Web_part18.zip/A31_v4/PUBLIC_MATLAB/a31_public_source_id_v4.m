function out=a31_public_source_id_v4(packageRoot,token)
% SPDX-License-Identifier: MIT
% Resolve provenance metadata locally; never fetch an external source.
registry=jsondecode(fileread(a31_public_path_v4(packageRoot,'SOURCE_REGISTRY_v4.json')));
id=char(token);hit=regexp(id,'^source:([^/]+)/','tokens','once');
if ~isempty(hit),id=hit{1};end
entries=registry.entries;if isstruct(entries),entries=num2cell(entries);end
ix=find(cellfun(@(e)strcmp(e.source_id,id),entries));
assert(numel(ix)==1,'A31Public:SourceID','Unknown or ambiguous source ID.');
out=entries{ix};out.external_fetch_performed=false;
% Empty package_members means recorded external provenance, not missing model
% state. The scientific payload is complete in MODEL_MEMBER_INDEX_v4.json.
end
