function out=a31_public_predict_v4(packageRoot,jobId,stage,X,eligible)
% SPDX-License-Identifier: MIT
% Frozen saved-state inference only; no training or teacher-target construction.
% X columns: tensile modulus(MPa), Shore D. TaskIL requires its known pair.
assert(nargin>=4,'A31Public:Arguments','Package root, job ID, stage and raw two-feature rows required.');
if nargin<5,eligible=[];end
assert(isscalar(stage)&&ismember(stage,1:3)&&isa(X,'double')&&isreal(X)&& ...
 ismatrix(X)&&size(X,2)==2&&size(X,1)>=1&&size(X,1)<=104&&all(isfinite(X),'all'), ...
 'A31Public:Input','Use a saved stage and at most104 finite binary64 two-feature rows.');
addpath(fullfile(packageRoot,'01_Matched_NL_OH','01_MATLAB'),'-begin');
index=jsondecode(fileread(a31_public_path_v4(packageRoot,'MODEL_MEMBER_INDEX_v4.json')));
entries=cells(index.entries);k=find(cellfun(@(r)strcmp(r.source_job_id,char(jobId)),entries));
assert(numel(k)==1,'A31Public:Job','Saved job ID missing or ambiguous.');e=entries{k};
bank=jsondecode(fileread(a31_public_path_v4(packageRoot,e.model_member)));
rs=cells(bank.scientific_payload.jobs);R=rs{double(e.job_index1)};
assert(strcmp(R.job.job_id,char(jobId))&& ...
 ((strcmp(e.family,'NL4')&&e.D==4)||(any(strcmp(e.family,{'OH8','WH8'}))&&e.D==8)), ...
 'A31Public:Index','Index ID, family or dimension disagrees with saved data.');
if isfield(R,'family'),assert(strcmp(R.family,e.family)&&R.D==e.D,'A31Public:Index','Family metadata mismatch.');end
stages=cells(R.stages);assert(numel(stages)==3,'A31Public:Stage','Three saved stages required.');
theta=double(stages{stage}.final_state.theta(:));
assert(numel(theta)==12+5*e.D&&all(isfinite(theta)),'A31Public:State','Saved theta width/values invalid.');
stream=char(R.job.stream);
if strcmp(stream,'TaskIL')
 assert(isnumeric(eligible)&&numel(eligible)==2&&all(isfinite(eligible))&&all(eligible==fix(eligible))&&eligible(1)==1&& ...
  eligible(2)>=2&&eligible(2)<=stage+1,'A31Public:Pair','Supply one already introduced known pair [1,k].');
else
 assert(strcmp(stream,'ClassIL'),'A31Public:Stream','Unknown saved stream.');
 if isempty(eligible),eligible=1:stage+1;end
 assert(isequal(double(eligible(:)'),1:stage+1),'A31Public:Mask','ClassIL must use all introduced classes.');
end
D=double(e.D);C=[];
if D==8
 if strcmp(e.family,'OH8'),C=[eye(4),zeros(4,4)];
 elseif strcmp(e.family,'WH8')
  b=jsondecode(fileread(a31_public_path_v4(packageRoot,'01_Matched_NL_OH/02_Input/nl_input_bundle_portable_v1.json')));
  C=double(b.codebook_WH8);
 else,error('A31Public:Family','Unknown coded family.');end
end
mu=reshape(double(R.normalizer.mean),1,2);sd=reshape(double(R.normalizer.sd),1,2);
assert(all(isfinite(mu))&&all(isfinite(sd))&&all(sd>0),'A31Public:Normalizer','Saved normalizer invalid.');
Z=(X-mu)./sd;decoded=a29cl_math('decode',theta,Z,D,double(eligible(:)'),C);
out=struct('schema','A31_PUBLIC_SAVED_INFERENCE_V4','job_id',char(jobId), ...
 'family',char(e.family),'stage',stage,'eligible',eligible,'Z',Z,'decoded',decoded, ...
 'query_rows',size(X,1),'training_updates',0, ...
 'scope','Frozen numerical inference; not independent physical validation or a production guarantee.');
end
function c=cells(v)
if iscell(v),c=v;elseif isstruct(v),c=num2cell(v);else,error('A31Public:Container','Expected object array.');end
end
