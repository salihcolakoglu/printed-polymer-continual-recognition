function p=a31_public_path_v4(packageRoot,member)
% SPDX-License-Identifier: MIT
% Resolve an existing package-relative member; no private workspace fallback.
assert(ischar(packageRoot)||isstring(packageRoot),'A31Public:Root','Package root must be text.');
assert(ischar(member)||isstring(member),'A31Public:Member','Member must be text.');
root=char(java.io.File(char(packageRoot)).getCanonicalPath());
m=char(member);assert(~isempty(m)&&isempty(regexp(m,'^[A-Za-z]:|^[/\\]|(^|[/\\])\.\.([/\\]|$)','once')), ...
 'A31Public:Scope','An ordinary package-relative member is required.');
p=char(java.io.File(fullfile(root,strrep(m,'/',filesep))).getCanonicalPath());
prefix=[root filesep];a=p;b=prefix;if ispc,a=lower(a);b=lower(b);end
assert(startsWith(a,b)&&isfile(p),'A31Public:Scope','Required local member is absent or outside package.');
end
