function out=a31_public_nr_v4(packageRoot,mode,jobId)
% SPDX-License-Identifier: MIT
% Default dry-run inspects all1400 new-family jobs without any model forward.
% 'load-saved' returns the existing scientific payload. 'train-one' explicitly
% starts one fresh1800-update reproduction, with no historical cache import.
% The original private freeze/runtime wrappers are historical provenance only.
if nargin<1||isempty(packageRoot),packageRoot=fileparts(fileparts(mfilename('fullpath')));end
if nargin<2||isempty(mode),mode='dry-run';end
if nargin<3,jobId='';end
mode=char(mode);assert(any(strcmp(mode,{'dry-run','load-saved','train-one'})), ...
 'A31Public:Mode','Use dry-run, load-saved, or explicit train-one.');
addpath(fullfile(packageRoot,'01_Matched_NL_OH','01_MATLAB'),'-begin');
bfile=a31_public_path_v4(packageRoot,'01_Matched_NL_OH/02_Input/nl_input_bundle_portable_v1.json');
jfile=a31_public_path_v4(packageRoot,'01_Matched_NL_OH/00_Protocol/nl_phase_job_contract_portable_v1.json');
bundle=a31nr_canonical_bundle_v1(jsondecode(fileread(bfile)));
contract=jsondecode(fileread(jfile));jobs=cells(contract.jobs);splits=cells(bundle.splits);
assert(numel(jobs)==1400&&contract.job_count==1400&& ...
 numel(unique(cellfun(@(j)char(j.job_id),jobs,'UniformOutput',false)))==1400, ...
 'A31Public:Membership','Expected literal1400-job contract.');
if strcmp(mode,'dry-run')
 families={'NL4','OH8'};streams={'TaskIL','ClassIL'};seeds=[101 211 307 401 503];
 names={'F00','F25','F50','F75','F100','UP','DOWN'};
 vectors=[0 0 0;.25 .25 .25;.5 .5 .5;.75 .75 .75;1 1 1;0 .5 1;1 .5 0];
 for ii=1:numel(jobs)
  j=jobs{ii};pi=find(strcmp(names,j.schedule_id));
  assert(numel(pi)==1&&isequal(double(j.alpha(:)'),vectors(pi,:))&& ...
   ismember(double(j.seed),seeds)&&ismember(double(j.outer_fold),1:5)&& ...
   any(strcmp(j.stream,streams))&&isscalar(j.replay)&&ismember(double(j.replay),[0 1])&& ...
   strcmp(j.split_id,sprintf('O%02d_outer_I00',j.outer_fold)), ...
   'A31Public:Membership','Job profile, start, outer split or evaluation context is invalid.');
 end
 for fi=1:2,for f=1:5,for ri=0:1,for si=1:2,for pi=1:7,for seed=seeds
  key=sprintf('%s_O%02d_R%d_%s_%s_S%d',families{fi},f,ri,names{pi},streams{si},seed);
  assert(sum(cellfun(@(j)strcmp(j.job_id,key),jobs))==1, ...
   'A31Public:Membership','One exact job per Cartesian family/fold/replay/profile/stream/start is required.');
 end,end,end,end,end,end
 checked=0;norms=cell(5,1);membership=cell(5,1);
 for f=1:5
  si=find(cellfun(@(s)double(s.outer_fold)==f&&strcmp(s.inner_design,'outer'),splits));
  assert(numel(si)==1,'A31Public:Split','One admitted outer split per fold required.');
  data=a31nr_data_v1(bundle,splits{si});norms{f}=data.normalizer;records={};
  for stream={'TaskIL','ClassIL'}
   for stage=1:3
    cur=data.current(stream{1},stage);query=data.query(stream{1},stage);
    assert(isempty(intersect(double(cur.parentindex),double(query.parentindex))), ...
     'A31Public:Leakage','Current TRAIN and evaluator overlap.');
    records{end+1}=struct('stream',stream{1},'stage',stage, ...
     'current_parentindex',cur.parentindex,'query_parentindex',query.parentindex); %#ok<AGROW>
   end
  end
  membership{f}=records;
 end
 for i=1:numel(jobs)
  j=jobs{i};assert(any(strcmp(j.family,{'NL4','OH8'}))&&any(j.D==[4 8])&& ...
   (strcmp(j.family,'NL4')&&j.D==4||strcmp(j.family,'OH8')&&j.D==8)&& ...
   j.updates_per_stage==600&&j.stages==3&&strcmp(j.inner_design,'outer')&& ...
   j.inner_fold==0&&all(j.alpha>=0&j.alpha<=1)&&numel(j.alpha)==3, ...
   'A31Public:Job','Job is outside the fixed family/dimension/task membership.');
  checked=checked+1;
 end
 out=struct('schema','A31_PUBLIC_DRY_RUN_V4','mode','dry-run','job_count',checked, ...
  'logical_stage_instances',checked*3,'normalizers',{norms},'membership',{membership}, ...
  'model_forwards',0,'teacher_forwards',0,'optimizer_updates',0, ...
  'note','Membership/data loading only; no evaluation performance was recomputed.');
 return
end
assert(ischar(jobId)||isstring(jobId),'A31Public:Job','An exact job ID is required.');
id=char(jobId);
if strcmp(mode,'load-saved')
 index=jsondecode(fileread(a31_public_path_v4(packageRoot,'MODEL_MEMBER_INDEX_v4.json')));
 entries=cells(index.entries);k=find(cellfun(@(r)strcmp(r.source_job_id,id),entries));
 assert(numel(k)==1,'A31Public:Job','Saved job ID missing or ambiguous.');
 e=entries{k};bank=jsondecode(fileread(a31_public_path_v4(packageRoot,e.model_member)));
 rs=cells(bank.scientific_payload.jobs);R=rs{e.job_index1};
 assert(strcmp(R.job.job_id,id)&& ...
  ((strcmp(e.family,'NL4')&&e.D==4)||(any(strcmp(e.family,{'OH8','WH8'}))&&e.D==8)), ...
  'A31Public:Index','Index ID, family or dimension disagrees with saved data.');
 stages=cells(R.stages);assert(numel(stages)==3&&numel(stages{1}.final_state.theta)==12+5*e.D, ...
  'A31Public:Index','Saved state width disagrees with index.');
 if isfield(R,'family'),assert(strcmp(R.family,e.family)&&R.D==e.D,'A31Public:Index','Family metadata mismatch.');end
 out=R;return
end
ix=find(cellfun(@(j)strcmp(j.job_id,id),jobs));assert(numel(ix)==1, ...
 'A31Public:Job','Fresh reproduction supports one literal NL4/OH8 job only.');
job=jobs{ix};si=find(cellfun(@(s)strcmp(s.split_id,job.split_id),splits));
assert(numel(si)==1,'A31Public:Split','Exact split is missing.');
data=a31nr_data_v1(bundle,splits{si});cache=a31nl_cache_v1('new');
[R,~]=a31nl_trajectory_v1(data,job,600,false,cache);
out=struct('schema','A31_PUBLIC_ONE_JOB_REPRODUCTION_V4','mode','train-one', ...
 'scientific_result',R,'historical_cache_imported',false, ...
 'note','Fresh reproduction. Its actual work differs from the original cached phase; no file written by this entry.');
end
function c=cells(v)
if iscell(v),c=v;elseif isstruct(v),c=num2cell(v);elseif isempty(v),c={}; ...
else,error('A31Public:Container','Expected JSON object array.');end
end
