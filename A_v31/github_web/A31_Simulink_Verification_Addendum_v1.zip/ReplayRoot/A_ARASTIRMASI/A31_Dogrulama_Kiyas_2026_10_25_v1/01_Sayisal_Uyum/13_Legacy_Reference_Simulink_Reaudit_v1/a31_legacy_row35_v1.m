function y = a31_legacy_row35_v1(u,param)
% Desktop MATLAB engine inference. Original decoder remains byte-identical.
% param=[theta32,normalizer_mean2,normalizer_sd2]. No expected values input.
u=reshape(double(u),1,7);param=reshape(double(param),1,36);
y=nan(1,35);y(30)=0;y(31:34)=u(4:7);y(35)=u(3);
if any(~isfinite(u)) || u(3)<1 || u(3)~=floor(u(3)),return;end
if any(~ismember(u(4:7),[0,1])) || sum(u(4:7))<2,return;end
if any(~isfinite(param)) || any(param(35:36)<=0),return;end
for j=1:2,y(j)=(u(j)-param(32+j))/param(34+j);end
eligible=find(u(4:7)==1);
out=a29cl_math('decode',reshape(param(1:32),32,1),y(1:2),4,eligible,[]);
y(3:6)=out.logits;y(11:14)=out.outputs;
y(18+eligible)=out.scores;y(22+eligible)=out.distances;
y(27)=out.label;y(28)=out.gap;y(29)=double(out.tie);y(30)=double(out.valid);
end
