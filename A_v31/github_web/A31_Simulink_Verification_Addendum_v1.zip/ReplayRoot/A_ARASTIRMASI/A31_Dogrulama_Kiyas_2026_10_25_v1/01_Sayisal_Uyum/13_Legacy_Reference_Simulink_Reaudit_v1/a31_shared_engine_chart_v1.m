function y = fcn(u,params)
%#codegen
% Normal-mode desktop simulation requires the MATLAB engine helper.
coder.extrinsic('a31_legacy_row35_v1');
u=reshape(u,1,7);y=nan(1,35);
y(30)=0;y(31:34)=u(4:7);y(35)=u(3);
mid=u(3);
if ~isfinite(mid) || mid<1 || mid~=floor(mid) || mid>size(params,1),return;end
p=zeros(1,36);p(:)=params(mid,:);
y=a31_legacy_row35_v1(u,p);
end
