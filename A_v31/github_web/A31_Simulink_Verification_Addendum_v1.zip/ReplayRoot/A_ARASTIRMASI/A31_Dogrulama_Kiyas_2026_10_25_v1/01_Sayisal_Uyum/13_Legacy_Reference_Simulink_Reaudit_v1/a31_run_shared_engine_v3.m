function a31_run_shared_engine_v3(mode)
assert(ismember(mode,{'pilot','full'}));
root=pwd;here=fullfile(root,'A_ARASTIRMASI','A31_Dogrulama_Kiyas_2026_10_25_v1','01_Sayisal_Uyum','13_Legacy_Reference_Simulink_Reaudit_v1');
addpath(here);addpath(fullfile(here,'source_math'),'-begin');
assert(strcmp(which('a29cl_math'),fullfile(here,'source_math','a29cl_math.m')));
runName=mode;if strcmp(mode,'pilot'),runName='pilot_v3';end
outRoot=fullfile(here,'runtime',runName,'results');assert(~isfolder(outRoot));mkdir(outRoot);
cache=fullfile(outRoot,'c');codegen=fullfile(outRoot,'g');mkdir(cache);mkdir(codegen);
Simulink.fileGenControl('set','CacheFolder',cache,'CodeGenFolder',codegen,'createDir',true);
chart=fileread(fullfile(here,'a31_shared_engine_chart_v1.m'));
if strcmp(mode,'pilot'),copyfile(fullfile(here,'runtime','pilot','results','source_free_fixture_receipt.json'),fullfile(outRoot,'source_free_fixture_receipt.json'));end
if strcmp(mode,'pilot'),folds=4;else,folds=1:5;end
receipt=cell(numel(folds),1);
for fi=1:numel(folds)
 fold=folds(fi);fd=fullfile(here,'prepared',sprintf('fold_%d',fold));od=fullfile(outRoot,sprintf('fold_%d',fold));mkdir(od);
 params=double(jsondecode(fileread(fullfile(fd,'params.json'))));
 if strcmp(mode,'pilot'),U=readmatrix(fullfile(fd,'pilot_inputs.csv'));else,U=readmatrix(fullfile(fd,'inputs.csv'));end
 assert(size(U,2)==7 && size(params,2)==36);n=size(U,1);
 if strcmp(mode,'pilot'),name=sprintf('a31p_f%d',fold);else,name=sprintf('a31f_f%d',fold);end;assert(~bdIsLoaded(name));new_system(name);cleanup=onCleanup(@()closeModel(name));
 set_param(name,'SolverType','Fixed-step','Solver','FixedStepDiscrete','FixedStep','1','StartTime','0','StopTime',num2str(n-1),'ReturnWorkspaceOutputs','on','SimulationMode','normal','SaveTime','on','TimeSaveName','tout');
 ws=get_param(name,'ModelWorkspace');assignin(ws,'params',params);assignin(ws,'queries',timeseries(U,(0:n-1)'));
 add_block('simulink/Sources/From Workspace',[name,'/Frozen raw queries'],'VariableName','queries','Interpolate','off','OutputAfterFinalValue','Holding final value','SampleTime','1','Position',[20,40,180,90]);
 add_block('simulink/User-Defined Functions/MATLAB Function',[name,'/Original MATLAB engine inference'],'Position',[400,50,660,190]);
 ch=find(sfroot,'-isa','Stateflow.EMChart','Path',[name,'/Original MATLAB engine inference']);ch.Script=chart;
 add_block('simulink/Sources/Constant',[name,'/Frozen parameters'],'Value','params','Position',[210,155,350,195]);
 add_block('simulink/Sinks/To Workspace',[name,'/Numeric trace'],'VariableName','trace','SaveFormat','Array','MaxDataPoints','inf','Decimation','1','SampleTime','1','Position',[740,80,880,130]);
 add_line(name,'Frozen raw queries/1','Original MATLAB engine inference/1');add_line(name,'Frozen parameters/1','Original MATLAB engine inference/2');add_line(name,'Original MATLAB engine inference/1','Numeric trace/1');
 model=fullfile(od,[name,'.slx']);save_system(name,model);close_system(name,0);load_system(model);
 ws=get_param(name,'ModelWorkspace');rp=getVariable(ws,'params');rq=getVariable(ws,'queries');assert(isequal(rp,params)&&isequal(rq.Data,U)&&isequal(rq.Time,(0:n-1)'));
 c=find(sfroot,'-isa','Stateflow.EMChart','Path',[name,'/Original MATLAB engine inference']);assert(strcmp(c.Script,chart));
 simout=sim(name);raw=simout.get('trace');time=double(simout.get('tout'));assert(isequal(time,(0:n-1)'));
 if isequal(size(raw),[n,35]),trace=raw;axes='samples_by_channels';elseif isequal(size(raw),[35,1,n]),trace=reshape(permute(raw,[3,1,2]),n,35);axes='channels_singleton_samples_permute_312';elseif isequal(size(raw),[1,35,n]),trace=reshape(permute(raw,[3,2,1]),n,35);axes='singleton_channels_samples_permute_321';else,error('Unexpected trace shape %s',mat2str(size(raw)));end
 assert(isequal(size(trace),[n,35]));save(fullfile(od,'actual_trace.mat'),'trace','time','raw','-v7');
 putjson(fullfile(od,'actual_trace.json'),struct('time',time,'values',trace));writematrix(trace,fullfile(od,'actual_trace.csv'));
 f=fopen(fullfile(od,'trace_hex.csv'),'w');assert(f>=0);fprintf(f,'query_index');for j=1:35,fprintf(f,',ch%d',j);end;fprintf(f,'\n');
 for i=1:n,fprintf(f,'%d',i);for j=1:35,if isnan(trace(i,j)),fprintf(f,',NaN');else,fprintf(f,',%s',num2hex(trace(i,j)));end,end;fprintf(f,'\n');end;fclose(f);
 sem=struct('chart_script',c.Script,'params',rp,'input_values',double(rq.Data),'input_times',double(rq.Time),'input_rows',n,'model_path',model,'simulation_mode','normal','cold_reopened',true,'trace_axes',axes,'trace_raw_size',size(raw),'helper_dependency','a31_legacy_row35_v1.m and byte-identical a29cl_math.m','inference_training',false);
 putjson(fullfile(od,'saved_model_semantic.json'),sem);close_system(name,0);clear cleanup;
 receipt{fi}=struct('fold',fold,'rows',n,'simulation_executed',true,'cold_reopened',true,'training',false);
end
obj=struct('schema','A31_SHARED_ORIGINAL_MATLAB_ENGINE_RUN_V1','mode',mode,'folds',{receipt},'matlab_version',version,'simulink_version',ver('Simulink'),'training',false,'physical_validation',false,'standalone_generated_code',false);
putjson(fullfile(outRoot,'run_complete.json'),obj);disp(jsonencode(obj));
end
function putjson(path,x),f=fopen(path,'w','n','UTF-8');assert(f>=0);fprintf(f,'%s',jsonencode(x));fclose(f);end
function closeModel(name),if bdIsLoaded(name),close_system(name,0);end,end
function receipt=fixtures()
p=[zeros(1,32),0,0,1,1];masks=[1,1,0,0;1,1,1,0;1,1,1,1];raw=[0,0;1,-1;-5,6];passed=0;
for i=1:3,for j=1:3,u=[raw(i,:),1,masks(j,:)];y=a31_legacy_row35_v1(u,p);eligible=find(masks(j,:));assert(all(y(3:6)==0)&&y(27)==1&&y(28)==0&&y(29)==1&&y(30)==1);assert(all(abs(y(10+eligible)-1/numel(eligible))<1e-14));passed=passed+1;end,end
u=[NaN,0,1,1,1,0,0];a=a31_legacy_row35_v1(u,p);assert(a(30)==0&&isnan(a(27)));passed=passed+1;
u=[0,0,1,1,0,0,0];a=a31_legacy_row35_v1(u,p);assert(a(30)==0&&isnan(a(27)));passed=passed+1;
p(35)=0;u=[0,0,1,1,1,0,0];a=a31_legacy_row35_v1(u,p);assert(a(30)==0&&isnan(a(27)));passed=passed+1;
receipt=struct('schema','A31_SHARED_ENGINE_SOURCE_FREE_FIXTURES_V1','cases',12,'passed',passed,'scope','Desktop helper interface only; nine zero-state valid inputs and three malformed inputs; not physical specimens or experimental performance.');
end
