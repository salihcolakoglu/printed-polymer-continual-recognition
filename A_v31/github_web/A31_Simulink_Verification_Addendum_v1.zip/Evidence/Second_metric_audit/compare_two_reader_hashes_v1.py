"""Compare already-computed full-cohort digests; no metric recomputation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
PRIMARY = HERE.parent / "16_Full_Cohort_Audit_v1/REVIEW_FULL_01"
OUT = HERE / "two_reader_digest_agreement_v1.json"
assert not OUT.exists()


def pin(p):
    p = Path(p).resolve()
    return {"path": str(p), "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8-sig"))


def records(p):
    rows = [json.loads(line) for line in Path(p).read_text(encoding="utf-8").splitlines() if line]
    keyed = {tuple(row["population"]): row for row in rows}
    assert len(keyed) == len(rows) == 6300
    return keyed


own_report = HERE / "independent_6300_metric_crosscheck_v1.json"
primary_report = PRIMARY / "independent_full_source_reference_audit_v4.json"
assert load(own_report)["accepted"] is True and load(primary_report)["accepted"] is True
own_file = HERE / "population_metric_hashes_v1.jsonl"
primary_file = PRIMARY / "population_summaries.jsonl"
own, primary = records(own_file), records(primary_file)
assert set(own) == set(primary)
fields = ["member_order_sha256", "actual_gap_blocks_sha256", "source_gap_blocks_sha256",
          "actual_CWAFN_all_cuts_sha256", "source_CWAFN_all_cuts_sha256"]
counts = {field: 0 for field in fields}
differences = []
for key in own:
    a, b = own[key], primary[key]
    assert a["rows"] == b["rows"]
    assert a["exact_gap_blocks"] is True and b["exact_gap_partition"] is True
    assert a["exact_all_CWAFN"] is True and b["exact_CWAFN_all_cuts"] is True
    for field in fields:
        if a[field] == b[field]:
            counts[field] += 1
        else:
            differences.append({"population": list(key), "field": field, "independent": a[field], "primary": b[field]})
report = {"schema": "A31_TWO_INDEPENDENT_READERS_FULL_6300_DIGEST_AGREEMENT_V1",
          "created_at_utc": datetime.now(timezone.utc).isoformat(),
          "accepted": not differences, "populations": 6300, "matching_by_field": counts,
          "difference_count": len(differences), "differences": differences,
          "input_pins": [pin(p) for p in [own_report, own_file, primary_report, primary_file, Path(__file__)]],
          "scope": "Comparison of already computed member-order, confidence-block and all-CWAFN digests only. No numeric inference, metric recomputation, MATLAB, simulation or training."}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"accepted": report["accepted"], "populations": 6300, "matching_by_field": counts,
                  "difference_count": len(differences), "output": str(OUT)}, ensure_ascii=False))
raise SystemExit(0 if report["accepted"] else 2)
