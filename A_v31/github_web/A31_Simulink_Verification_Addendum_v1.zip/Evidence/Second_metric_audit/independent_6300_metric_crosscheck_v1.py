"""Second implementation of the full frozen confidence-block/CWAFN audit.

Only saved traces and source mappings are read. No earlier auditor, inference
function, NumPy arithmetic kernel, MATLAB or Simulink is imported or executed.
NL4 actual values come from the new shared-engine trace. OH8/WH8 actual values
come from the original native trace or its pinned historical actual trace.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import csv
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
W = HERE.parents[3]
A = W / "A_ARASTIRMASI"
OLD = A / "A31_NL_Simulink_Dogrulama_2026_10_25_v1"
SHARED = HERE.parent / "13_Legacy_Reference_Simulink_Reaudit_v1"
OUT = HERE / "independent_6300_metric_crosscheck_v1.json"
POPS = HERE / "population_metric_hashes_v1.jsonl"
PINNED = {}
TRACE_CACHE = {}
FAILURES = []
CHECK_COUNTS = Counter()
FAILURE_COUNTS = Counter()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def pin(path):
    p = Path(path).resolve(strict=True)
    p.relative_to(W)
    key = str(p)
    if key not in PINNED:
        PINNED[key] = {"path": key, "bytes": p.stat().st_size,
                       "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
    return PINNED[key]


def resolve(ref):
    p = Path(ref["path"])
    if not p.exists():
        text = str(ref["path"])
        assert "A_ARASTIRMASI" in text
        p = W / text[text.index("A_ARASTIRMASI"):].replace("\\", "/")
    got = pin(p)
    assert got["bytes"] == int(ref["bytes"]) and got["sha256"] == ref["sha256"], str(p)
    return p


def check(name, condition, detail=None):
    CHECK_COUNTS[name] += 1
    if not condition:
        FAILURE_COUNTS[name] += 1
        if len(FAILURES) < 100:
            FAILURES.append({"check": name, "detail": detail})


def trace(path):
    p = Path(path).resolve()
    pin(p)
    if str(p) not in TRACE_CACHE:
        TRACE_CACHE[str(p)] = load(p)["values"]
    return TRACE_CACHE[str(p)]


def readcsv(path):
    pin(path)
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return [[float(value) for value in row] for row in csv.reader(stream)]


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                   separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def valid(row):
    return row[29] == 1 and row[26] is not None and row[27] is not None and math.isfinite(row[26]) and math.isfinite(row[27])


def same_value(a, b):
    return (a is None and b is None) or a == b


def make_blocks(rows):
    # Stable index sort and adjacent run grouping deliberately differs from
    # the primary reader's unique-value/set scan implementation.
    order = sorted((i for i, row in enumerate(rows) if valid(row)),
                   key=lambda i: (-rows[i][27], i))
    blocks = []
    for index in order:
        if not blocks or rows[index][27] != rows[blocks[-1][0]][27]:
            blocks.append([index])
        else:
            blocks[-1].append(index)
    return blocks


def cut_counts(rows, truths, blocks):
    # Per-row cumulative state, instead of the primary reader's answered set.
    selected = [False] * len(rows)
    counts = []
    for block in [[]] + blocks:
        for index in block:
            selected[index] = True
        c = w = abstain = failed = 0
        for i, row in enumerate(rows):
            if not valid(row):
                failed += 1
            elif not selected[i]:
                abstain += 1
            elif row[26] == truths[i]:
                c += 1
            else:
                w += 1
        n, answered = len(rows), c + w
        counts.append([c, w, abstain, failed, n, answered,
                       answered / n, w / answered if answered else None])
    return counts


def run():
    prior_path = OLD / "05_Independent_Review/NATIVE_DIAGNOSTIC_02/native_collect_all_diagnostic_v2.json"
    structural_path = OLD / "05_Independent_Review/STRUCTURAL_AUDIT_01/structural_independent_audit_v1.json"
    check("old_report_pin", pin(prior_path)["sha256"] == "a0cd7b460c3140e953db1e83340ae0eba9e5b67502b26e2fb8a8d4d11e42102c")
    check("structural_pin", pin(structural_path)["sha256"] == "50aa9e0f285e548588fd5d6211367eb7e9eeb21c3812efc247462e5ddbfcb622")
    prior, structural = load(prior_path), load(structural_path)
    export = load(resolve(structural["detail"]["export_receipt_pin"]))
    check("old_history_preserved", prior["accepted"] is False and prior["detail"]["C11_mismatch_population_count"] == 2)
    manifest_path = SHARED / "prepared/preparation_manifest_v1.json"
    pin(manifest_path)
    manifest = load(manifest_path)
    owner_path = SHARED / "runtime/full/launcher_receipt.json"
    pin(owner_path)
    owner = load(owner_path)
    check("new_full_process_complete", owner["status"] == "COMPLETE" and owner["normal_exit"] is True and owner["job_empty"] is True and owner["actual_parent_exit"] == 0)
    complete_path = SHARED / "runtime/full/results/run_complete.json"
    pin(complete_path)
    complete = load(complete_path)
    check("new_full_scope", complete["mode"] == "full" and complete["training"] is False and [r["fold"] for r in complete["folds"]] == [1, 2, 3, 4, 5])
    totals, family = Counter(), Counter()
    summaries, explicit_two = [], []
    source_keys = set()
    max_gap_delta = 0.0
    for fold in range(1, 6):
        exported = OLD / f"01_Input/EXPORT_RUN_01/results/fold_{fold}"
        prepared = SHARED / f"prepared/fold_{fold}"
        for ref in next(x for x in export["folds"] if x["fold"] == fold)["files"]:
            resolve(ref)
        for ref in next(x for x in manifest["folds"] if x["fold"] == fold)["files"]:
            resolve(ref)
        logical = load(exported / "all_logical_mapping.json")
        shared_map = load(prepared / "logical_mapping.json")
        by_logical = {r["logical_index1"]: r for r in shared_map}
        check("shared_logical_unique", len(by_logical) == len(shared_map))
        check("shared_all_NL4_ids", set(by_logical) == {r["logical_index1"] for r in logical if r["source"]["family"] == "NL4"})
        shared_actual = trace(SHARED / f"runtime/full/results/fold_{fold}/actual_trace.json")
        shared_inputs = readcsv(prepared / "inputs.csv")
        check("shared_unique_query_shape", len(shared_actual) == len(shared_inputs))
        original_actual = trace(OLD / f"06_Runtime/NATIVE_RUN_01/results/fold_{fold}/actual_trace.json")
        original_inputs = readcsv(exported / "inputs.csv")
        proofs = {r["signature_sha256"]: r for r in load(exported / "old_reused_trace_evidence.json")}
        groups = defaultdict(list)
        ids = set()
        for entry in logical:
            source = entry["source"]
            oi = entry["logical_index1"]
            check("logical_id_unique", oi not in ids)
            ids.add(oi)
            unique = (source["family"], fold, source["job_id"], source["prediction_index1"])
            check("source_view_identity_unique", unique not in source_keys, unique)
            source_keys.add(unique)
            if source["family"] == "NL4":
                mapped = by_logical[oi]
                check("NL4_source_identity", source == mapped["source"] and entry["signature_sha256"] == mapped["signature_sha256"])
                check("NL4_original_reference_unchanged", entry["expected_source_channels35"][:34] == mapped["expected_source_channels35"][:34])
                query = int(mapped["query_index1"])
                assert 1 <= query <= len(shared_actual)
                actual = shared_actual[query - 1]
                check("NL4_actual_selector", actual[34] == shared_inputs[query - 1][2])
                totals["new_NL4_views"] += 1
            elif entry["evidence_kind"] == "NEW_UNIQUE_SIMULINK_QUERY_PENDING":
                query = int(entry["new_query_index1"])
                assert 1 <= query <= len(original_actual)
                actual = original_actual[query - 1]
                check("old_native_selector", actual[34] == original_inputs[query - 1][2])
                totals["reused_coded_new_native_views"] += 1
            else:
                assert source["family"] in ["OH8", "WH8"]
                assert entry["evidence_kind"] == "ACCEPTED_A30_TRACE_REUSED_NO_FORWARD"
                proof = proofs[entry["old_trace_signature"]]
                origin = proof["origin"]
                old_actual = trace(resolve(origin["trace_pin"]))
                actual = old_actual[int(origin["trace_row1"]) - 1]
                check("old_verbatim_actual_identity", actual == proof["values35_verbatim"])
                check("old_actual_selector", actual[34] == origin["source_model_id"])
                totals["reused_coded_historical_views"] += 1
            expected = entry["expected_source_channels35"]
            for channel in [26, 28, 29, 30, 31, 32, 33]:
                check("original_discrete", same_value(actual[channel], expected[channel]), [fold, oi, channel + 1])
            if valid(actual) and valid(expected):
                delta = abs(actual[27] - expected[27])
                max_gap_delta = max(max_gap_delta, delta)
                check("original_gap_numeric_tolerance", delta <= 2e-11 + 2e-11 * abs(expected[27]), [fold, oi])
            key = tuple(source[name] for name in ["family", "outer_fold", "stream", "profile", "replay", "seed", "stage"])
            groups[key].append({"actual": actual, "expected": expected, "source": source})
            family[source["family"]] += 1
        check("fold_population_count", len(groups) == 1260, fold)
        for key, records in groups.items():
            actual_rows = [r["actual"] for r in records]
            expected_rows = [r["expected"] for r in records]
            truths = [r["source"]["truth"] for r in records]
            actual_blocks, expected_blocks = make_blocks(actual_rows), make_blocks(expected_rows)
            actual_cuts = cut_counts(actual_rows, truths, actual_blocks)
            expected_cuts = cut_counts(expected_rows, truths, expected_blocks)
            equal_blocks = actual_blocks == expected_blocks
            equal_counts = actual_cuts == expected_cuts
            check("exact_gap_blocks", equal_blocks, key)
            check("exact_all_CWAFN", equal_counts, key)
            check("forced_counts", actual_cuts[-1] == expected_cuts[-1], key)
            check("fixed_denominator", all(sum(x[:4]) == len(records) and x[4] == len(records) and x[5] == x[0] + x[1]
                                            for x in actual_cuts + expected_cuts), key)
            identities = [[r["source"][n] for n in ["job_id", "stage", "task", "parentrow", "prediction_index1"]] for r in records]
            summary = {"population": list(key), "rows": len(records), "exact_gap_blocks": equal_blocks,
                       "exact_all_CWAFN": equal_counts, "member_order_sha256": digest(identities),
                       "actual_gap_blocks_sha256": digest(actual_blocks), "source_gap_blocks_sha256": digest(expected_blocks),
                       "actual_CWAFN_all_cuts_sha256": digest(actual_cuts), "source_CWAFN_all_cuts_sha256": digest(expected_cuts),
                       "actual_forced_counts": actual_cuts[-1][:6], "source_forced_counts": expected_cuts[-1][:6]}
            summaries.append(summary)
            if key[0] == "NL4" and key[1] == 4 and key[2] == "ClassIL" and key[3] == "F25" and key[4] is True and key[5] in [101, 211] and key[6] == 2:
                explicit_two.append(summary | {"member_ids": identities, "actual_blocks": actual_blocks,
                                               "original_blocks": expected_blocks, "actual_CWAFN": actual_cuts,
                                               "original_CWAFN": expected_cuts})
            totals["populations"] += 1
            totals["exact_gap_blocks_populations"] += int(equal_blocks)
            totals["exact_all_CWAFN_populations"] += int(equal_counts)
            totals["logical_views"] += len(records)
    check("complete_6300", totals["populations"] == 6300 and totals["logical_views"] == 114660
          and len(source_keys) == 114660 and family == {"NL4": 38220, "OH8": 38220, "WH8": 38220})
    check("two_affected_included", len(explicit_two) == 2)
    return totals, family, summaries, explicit_two, max_gap_delta


def main():
    assert not OUT.exists() and not POPS.exists(), "Never overwrite a prior check"
    fatal = None
    totals, family, summaries, affected, maximum_gap = Counter(), Counter(), [], [], None
    try:
        totals, family, summaries, affected, maximum_gap = run()
    except Exception as exc:
        fatal = type(exc).__name__ + ": " + str(exc)
        check("fatal_data_boundary", False, fatal)
    POPS.write_text("".join(json.dumps(x, ensure_ascii=False, separators=(",", ":")) + "\n" for x in summaries), encoding="utf-8")
    pin(POPS)
    pin(Path(__file__))
    result = {"schema": "A31_SECOND_IMPLEMENTATION_FULL_6300_METRIC_ONLY_CROSSCHECK_V1",
              "created_at_utc": datetime.now(timezone.utc).isoformat(),
              "accepted": not FAILURE_COUNTS and fatal is None,
              "status": "ACCEPTED_FULL_6300_METRIC_ONLY" if not FAILURE_COUNTS and fatal is None else "HOLD",
              "counts": dict(totals), "per_family_views": dict(family),
              "checks": sum(CHECK_COUNTS.values()), "check_categories": dict(CHECK_COUNTS),
              "failed_checks": sum(FAILURE_COUNTS.values()), "failure_categories": dict(FAILURE_COUNTS),
              "failures": FAILURES, "fatal_error": fatal,
              "maximum_absolute_gap_difference": maximum_gap,
              "two_affected_populations": affected, "population_hashes_pin": pin(POPS),
              "source_pins": list(PINNED.values()),
              "independence": "Second implementation; stable index sorting plus adjacent equality grouping and per-row cumulative selection. Imports no main auditor or inference code; recomputes no network forward, optimizer, teacher or MATLAB call.",
              "interpretation": "Metric-only confirmation of selected new desktop MATLAB-engine NL4 and immutable original compiled OH8/WH8 traces against unchanged original scientific references. Historical compiled NL4 diagnostic remains unchanged; this is not independent generated-C or physical validation.",
              "criteria_changed": False, "original_reference_replaced": False,
              "new_training": False, "new_simulation": False}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"accepted": result["accepted"], "status": result["status"], "counts": result["counts"],
                      "checks": result["checks"], "failed_checks": result["failed_checks"],
                      "fatal_error": fatal, "output": str(OUT)}, ensure_ascii=False))
    return 0 if result["accepted"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
