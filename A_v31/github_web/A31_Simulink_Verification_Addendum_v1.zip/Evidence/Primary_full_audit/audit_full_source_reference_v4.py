"""Independent saved-output audit of A31's source-reference inference parity.

The normal-mode MATLAB-engine NL4 route is evaluated against the ORIGINAL
scientific predictions. Unmodified compiled/native OH8 and WH8 evidence is
restored from its actual trace files. No MATLAB, training, or expected-output
injection is performed by this reader. The first two affected populations have
their full exact gap blocks and every C/W/A/F/N cut explicitly serialized.
"""
from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import importlib.util
import json
import math
import struct
import sys
import time
import zipfile
import zlib
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[3]
ARTICLE = WORKSPACE / "A_ARASTIRMASI"
ORIGINAL = ARTICLE / "A31_NL_Simulink_Dogrulama_2026_10_25_v1"
ORIGINAL_REPORT = ORIGINAL / "05_Independent_Review/NATIVE_DIAGNOSTIC_02/native_collect_all_diagnostic_v2.json"
ORIGINAL_REPORT_SHA = "a0cd7b460c3140e953db1e83340ae0eba9e5b67502b26e2fb8a8d4d11e42102c"
STRUCTURAL = ORIGINAL / "05_Independent_Review/STRUCTURAL_AUDIT_01/structural_independent_audit_v1.json"
STRUCTURAL_SHA = "50aa9e0f285e548588fd5d6211367eb7e9eeb21c3812efc247462e5ddbfcb622"
COMMON = ARTICLE / "A_v30.0_2026_10_19/08_Inceleme/a30_independent_saved_parity_audit_v3.py"
COMMON_SHA = "39d42186611091569138f211d11166a0c33dd91322ce1e7c0cc153d6db2da50f"
ATOL = RTOL = 2e-11
DISCRETE = [26, 28, 29, 30, 31, 32, 33, 34]
KEY_FIELDS = ["family", "outer_fold", "stream", "profile", "replay", "seed", "stage"]
PINS = {}
REBASINGS = []
REBASED_KEYS = set()


def load(p):
    p = Path(p)
    assert p.stat().st_size <= 240_000_000, p
    return json.loads(p.read_text(encoding="utf-8-sig"))


def pin(p):
    p = Path(p).resolve(strict=True)
    p.relative_to(WORKSPACE)
    key = str(p)
    if key not in PINS:
        h = hashlib.sha256()
        with p.open("rb") as f:
            for b in iter(lambda: f.read(1048576), b""):
                h.update(b)
        PINS[key] = {"path": key, "bytes": p.stat().st_size, "sha256": h.hexdigest()}
    return PINS[key]


def resolve_pinned(ref):
    p = Path(ref["path"])
    if not p.exists():
        # Historical JSON paths can contain mojibake in the workspace prefix.
        # A stable relative suffix plus exact SHA and byte count is required.
        text = str(ref["path"])
        assert "A_ARASTIRMASI" in text, text
        p = WORKSPACE / text[text.index("A_ARASTIRMASI"):].replace("\\", "/")
        key = (str(ref["path"]), str(p))
        if key not in REBASED_KEYS:
            REBASED_KEYS.add(key)
            REBASINGS.append({"recorded_path": key[0], "resolved_path": key[1]})
    got = pin(p)
    assert got["bytes"] == int(ref["bytes"]) and got["sha256"] == ref["sha256"], p
    return p


def readcsv(p):
    pin(p)
    with Path(p).open(encoding="utf-8-sig", newline="") as f:
        return np.asarray([[float(x) if x.strip() else np.nan for x in r] for r in csv.reader(f)], dtype=float)


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(obj):
    return hashlib.sha256(canonical(obj)).hexdigest()


def bits(xs):
    return b"".join(struct.pack(">d", float(x)) for x in xs)


def textnorm(s):
    return s.replace("\r\n", "\n").rstrip("\n")


class Audit:
    def __init__(self):
        self.counts = Counter()
        self.failures = []
        self.failure_categories = Counter()
        self.maximum_absolute_error = 0.0
        self.numeric_cells = 0
        self.finite_bit_different_cells = 0

    def check(self, name, ok, detail=None, fatal=True):
        self.counts[name] += 1
        if not bool(ok):
            self.failure_categories[name] += 1
            if len(self.failures) < 128:
                self.failures.append({"category": name, "detail": detail})
            if fatal:
                raise AssertionError(name + (": " + str(detail) if detail is not None else ""))

    def array(self, name, actual, expected, exact=False, detail=None):
        a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
        self.check(name + "_shape", a.shape == b.shape, detail)
        self.numeric_cells += a.size
        self.check(name + "_nan", np.array_equal(np.isnan(a), np.isnan(b)), detail)
        self.check(name + "_infinity", np.array_equal(np.isposinf(a), np.isposinf(b)) and np.array_equal(np.isneginf(a), np.isneginf(b)), detail)
        finite = np.isfinite(b)
        if np.any(finite):
            delta = np.abs(a[finite] - b[finite])
            self.maximum_absolute_error = max(self.maximum_absolute_error, float(np.max(delta)))
            # Diagnostic only; unchanged protocol accepts finite numeric tolerance.
            self.finite_bit_different_cells += int(np.sum(a[finite].view(np.uint64) != b[finite].view(np.uint64)))
            ok = np.array_equal(a[finite], b[finite]) if exact else np.all(delta <= ATOL + RTOL * np.abs(b[finite]))
            self.check(name + ("_exact" if exact else "_numeric"), ok, detail)


def get_common():
    assert pin(COMMON)["sha256"] == COMMON_SHA
    spec = importlib.util.spec_from_file_location("accepted_independent_numpy_and_mat_reader", COMMON)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_shared_mat(path):
    """Bounded independent MAT-v5 little-endian real-double numeric reader.

    Supports exactly MATLAB -v7 trace/time arrays; rejects other classes.
    MATLAB miCOMPRESSED top-level elements are not eight-byte padded.
    """
    data = Path(path).read_bytes()
    assert len(data) >= 128 and data[126:128] == b"IM", "MAT5 little endian only"
    arrays = {}
    def element(blob, pos, top=False):
        first, second = struct.unpack_from("<II", blob, pos)
        if first >> 16:
            size, typ = first >> 16, first & 0xffff
            assert size <= 4
            return typ, blob[pos + 4:pos + 4 + size], pos + 8
        typ, size = first, second
        end = pos + 8 + size
        assert end <= len(blob)
        nxt = end if top and typ == 15 else end + (-size) % 8
        return typ, blob[pos + 8:end], nxt
    def matrix(payload):
        pieces, p = [], 0
        while p < len(payload):
            t, v, p = element(payload, p)
            pieces.append((t, v))
        assert len(pieces) == 4, "Only noncomplex numeric arrays"
        (ft, flags), (dt, dimensions), (nt, name), (vt, values) = pieces
        assert ft == 6 and len(flags) == 8
        flag = struct.unpack_from("<I", flags)[0]
        assert flag & 0xff == 6 and not flag & 0xa00, "Real double only"
        assert dt == 5 and nt in [1, 2]
        dims = struct.unpack("<" + "i" * (len(dimensions) // 4), dimensions)
        assert all(x >= 0 for x in dims)
        key = name.decode("ascii")
        assert key not in arrays and key in ["trace", "raw", "time"]
        assert vt == 9 or key == "time", "Trace arrays require binary64 storage"
        types = {1: "i1", 2: "u1", 3: "<i2", 4: "<u2", 5: "<i4", 6: "<u4", 7: "<f4", 9: "<f8", 12: "<i8", 13: "<u8"}
        assert vt in types
        values = np.frombuffer(values, dtype=types[vt]).astype(float)
        assert values.size == math.prod(dims)
        arrays[key] = values.reshape(dims, order="F").copy()
    pos = 128
    while pos < len(data):
        typ, payload, pos = element(data, pos, top=True)
        if typ == 15:
            d = zlib.decompressobj()
            plain = d.decompress(payload, 67108865)
            assert len(plain) <= 67108864 and not d.unconsumed_tail and d.eof
            t, v, end = element(plain, 0)
            assert t == 14 and end == len(plain)
            matrix(v)
        else:
            assert typ == 14
            matrix(payload)
    assert set(arrays) == {"trace", "raw", "time"}
    return arrays



def read_trace(a, run, n, common):
    docpath, matpath, csvpath, hexpath = (run / x for x in ["actual_trace.json", "actual_trace.mat", "actual_trace.csv", "trace_hex.csv"])
    for p in [docpath, matpath, csvpath, hexpath]:
        pin(p)
    doc = load(docpath)
    actual = np.asarray(doc["values"], dtype=float)
    a.check("shared_trace_shape", actual.shape == (n, 35), str(run))
    a.array("shared_JSON_time", doc["time"], np.arange(n), exact=True)
    mat = load_shared_mat(matpath)
    a.array("shared_MAT_trace", mat["trace"], actual, exact=True)
    a.array("shared_MAT_time", mat["time"].ravel(), np.arange(n), exact=True)
    sem = load(run / "saved_model_semantic.json")
    a.check("shared_raw_shape_receipt", list(mat["raw"].shape) == [int(x) for x in np.asarray(sem["trace_raw_size"]).ravel()])
    raw = mat["raw"]
    if sem["trace_axes"] == "samples_by_channels" and raw.shape == (n, 35):
        remap = raw
    elif sem["trace_axes"] == "channels_singleton_samples_permute_312" and raw.shape == (35, 1, n):
        remap = np.transpose(raw, (2, 0, 1)).reshape(n, 35)
    elif sem["trace_axes"] == "singleton_channels_samples_permute_321" and raw.shape == (1, 35, n):
        remap = np.transpose(raw, (2, 1, 0)).reshape(n, 35)
    else:
        raise AssertionError("Unknown raw trace axes")
    a.array("shared_explicit_raw_axes", remap, actual, exact=True)
    c = readcsv(csvpath)
    a.array("shared_CSV_numeric", c, actual)
    a.array("shared_CSV_discrete", c[:, DISCRETE], actual[:, DISCRETE], exact=True)
    with hexpath.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        a.check("shared_hex_header", reader.fieldnames == ["query_index"] + [f"ch{k}" for k in range(1, 36)])
        hexrows = list(reader)
    a.check("shared_hex_rows", len(hexrows) == n)
    for qi, row in enumerate(hexrows, 1):
        a.check("shared_hex_index", int(row["query_index"]) == qi)
        vals = []
        for ch in range(1, 36):
            word = row[f"ch{ch}"]
            vals.append(math.nan if word == "NaN" else struct.unpack(">d", bytes.fromhex(word))[0])
        a.array("shared_hex_exact", vals, actual[qi - 1], exact=True, detail=qi)
    return actual, sem


def slx_semantic(a, work, run, sem, params, inputs, mode, fold):
    sp = run / "saved_model_semantic.json"
    pin(sp)
    a.check("shared_simulation_mode", sem["simulation_mode"] == "normal" and sem["cold_reopened"] is True)
    a.check("shared_input_row_count", int(sem["input_rows"]) == len(inputs))
    a.array("shared_cold_parameters", sem["params"], params, exact=True)
    a.check("shared_cold_inputs_recorded", "input_values" in sem)
    a.array("shared_cold_inputs", sem["input_values"], inputs, exact=True)
    a.array("shared_cold_input_times", np.asarray(sem["input_times"]).ravel(), np.arange(len(inputs)), exact=True)
    chartp = work / "a31_shared_engine_chart_v1.m"
    script = chartp.read_text(encoding="utf-8-sig")
    pin(chartp)
    a.check("shared_cold_exact_chart", textnorm(sem["chart_script"]) == textnorm(script))
    model = Path(sem["model_path"]).resolve(strict=True)
    a.check("shared_model_scope", model.parent == run.resolve() and model.name == (f"a31p_f{fold}.slx" if mode == "pilot" else f"a31f_f{fold}.slx"))
    pin(model)
    with zipfile.ZipFile(model) as z:
        a.check("shared_SLX_zip_bounds", len(z.infolist()) <= 1000 and sum(x.file_size for x in z.infolist()) <= 67108864)
        a.check("shared_SLX_CRC", z.testzip() is None)
        scripts = []
        for name in z.namelist():
            if name.startswith("simulink/stateflow/") and name.endswith(".xml"):
                e = ET.fromstring(z.read(name))
                scripts.extend(p.text or "" for p in e.iter("P") if p.attrib.get("Name") == "script")
        a.check("shared_SLX_exact_chart", len(scripts) == 1 and textnorm(scripts[0]) == textnorm(script))
        e = ET.fromstring(z.read("simulink/systems/system_root.xml"))
        blocks = {b.attrib["Name"]: b for b in e.findall("Block")}
        expected = {"Frozen raw queries", "Original MATLAB engine inference", "Frozen parameters", "Numeric trace"}
        a.check("shared_SLX_blocks", set(blocks) == expected)
        props = lambda x: {v.attrib.get("Name"): v.text for v in x.findall("P")}
        a.check("shared_SLX_parameter_constant", props(blocks["Frozen parameters"]).get("Value") == "params")
        src = props(blocks["Frozen raw queries"])
        a.check("shared_SLX_query_source", src.get("VariableName") == "queries" and src.get("Interpolate") == "off" and src.get("SampleTime") == "1" and src.get("OutputAfterFinalValue") == "Holding final value")
        a.check("shared_SLX_trace_sink", props(blocks["Numeric trace"]).get("VariableName") == "trace")
        sid = {k: v.attrib["SID"] for k, v in blocks.items()}
        edges = {(props(x).get("Src"), props(x).get("Dst")) for x in e.findall("Line")}
        infer = sid["Original MATLAB engine inference"]
        want = {(sid["Frozen raw queries"] + "#out:1", infer + "#in:1"),
                (sid["Frozen parameters"] + "#out:1", infer + "#in:2"),
                (infer + "#out:1", sid["Numeric trace"] + "#in:1")}
        a.check("shared_SLX_wiring", edges == want)
        conf = ET.fromstring(z.read("simulink/configSet0.xml"))
        cp = {x.attrib.get("Name"): x.text for x in conf.iter("P")}
        a.check("shared_SLX_solver", cp.get("FixedStep") == "1" and cp.get("StartTime") == "0" and "FixedStepDiscrete" in cp.values())
        wp = [x for x in z.namelist() if "modelWorkspace" in x]
        a.check("shared_SLX_workspace", len(wp) == 1)
        return {"SLX": pin(model), "semantic": pin(sp), "workspace_part": wp[0],
                "workspace_bytes": z.getinfo(wp[0]).file_size,
                "workspace_sha256": hashlib.sha256(z.read(wp[0])).hexdigest(),
                "workspace_boundary": "Binary modelWorkspace part hashed; actual cold-reopened params and query matrix compared through semantic readback."}


def exact_blocks(gaps, valid):
    # Match original rule: group by exact native binary64 equality; descending gaps.
    values = sorted(set(float(gaps[i]) for i in range(len(gaps)) if valid[i]), reverse=True)
    return values, [tuple(i for i in range(len(gaps)) if valid[i] and float(gaps[i]) == v) for v in values]


def cells_for_blocks(labels, truth, valid, blocks):
    answered = set()
    out = []
    for block in [()] + blocks:
        answered.update(block)
        c = sum(1 for i in answered if valid[i] and labels[i] == truth[i])
        w = len(answered) - c
        abstain = sum(1 for i in range(len(labels)) if valid[i] and i not in answered)
        failed = sum(1 for v in valid if not v)
        n, answer = len(labels), c + w
        out.append([c, w, abstain, failed, n, answer, answer / n, w / answer if answer else None])
    return out


def population_audit(a, key, rows, detailed=False):
    got = np.asarray([r["actual"] for r in rows], dtype=float)
    exp = np.asarray([r["expected"] for r in rows], dtype=float)
    truth = [r["source"]["truth"] for r in rows]
    av = ((got[:, 29] == 1) & np.isfinite(got[:, 26]) & np.isfinite(got[:, 27])).tolist()
    ev = ((exp[:, 29] == 1) & np.isfinite(exp[:, 26]) & np.isfinite(exp[:, 27])).tolist()
    al, ab = exact_blocks(got[:, 27], av)
    el, eb = exact_blocks(exp[:, 27], ev)
    ac = cells_for_blocks(got[:, 26], truth, av, ab)
    ec = cells_for_blocks(exp[:, 26], truth, ev, eb)
    equal_blocks, equal_cells = ab == eb, ac == ec
    a.check("exact_gap_partition", equal_blocks, list(key), fatal=False)
    a.check("exact_CWAFN_all_cuts", equal_cells, list(key), fatal=False)
    if equal_blocks:
        a.array("gap_thresholds_numeric", al, el, detail=list(key))
    a.check("CWAFN_answer_none", ac[0][-1] is None and ec[0][-1] is None)
    a.check("CWAFN_denominators", all(sum(c[:4]) == len(rows) and c[4] == len(rows) and c[5] == c[0] + c[1] for c in ac + ec))
    member_ids = [[r["source"]["job_id"], r["source"]["stage"], r["source"]["task"],
                   r["source"]["parentrow"], r["source"]["prediction_index1"]] for r in rows]
    result = {"population": list(key), "rows": len(rows),
              "exact_gap_partition": equal_blocks, "exact_CWAFN_all_cuts": equal_cells,
              "actual_blocks": len(ab), "source_blocks": len(eb),
              "actual_cuts": len(ac), "source_cuts": len(ec),
              "member_order_sha256": digest(member_ids),
              "actual_gap_blocks_sha256": digest(ab), "source_gap_blocks_sha256": digest(eb),
              "actual_CWAFN_all_cuts_sha256": digest(ac), "source_CWAFN_all_cuts_sha256": digest(ec)}
    if detailed or not equal_blocks or not equal_cells:
        result.update({"member_ids": member_ids, "truth": truth,
                       "actual_labels": got[:, 26].tolist(), "source_labels": exp[:, 26].tolist(),
                       "actual_gap_hex": [float(x).hex() for x in got[:, 27]],
                       "source_gap_hex": [float(x).hex() for x in exp[:, 27]],
                       "actual_threshold_hex": [float(x).hex() for x in al],
                       "source_threshold_hex": [float(x).hex() for x in el],
                       "actual_gap_blocks": ab, "source_gap_blocks": eb,
                       "actual_CWAFN_all_cuts": ac, "source_CWAFN_all_cuts": ec,
                       "CWAFN_cell_columns": ["C", "W", "A", "F", "N", "answered", "coverage", "risk"]})
    return result


def owned_runtime(a, work, mode, run_name, manifestp):
    parent = work / f"runtime/{run_name}"
    rp, fp = parent / "launcher_receipt.json", parent / "consumed_freeze.json"
    pin(rp); pin(fp)
    receipt, freeze = load(rp), load(fp)
    a.check("owned_normal_exit_empty", receipt["status"] == "COMPLETE" and receipt["normal_exit"] is True and receipt["job_empty"] is True and receipt["job_membership_verified"] is True and receipt["actual_parent_exit"] == 0)
    wall = 240 if mode == "pilot" else 600
    a.check("owned_frozen_caps", receipt["timeout_seconds"] == wall and receipt["output_cap_bytes"] == 268435456 and receipt["job_commit_limit_bytes"] == 4294967296 and receipt["stdout_cap_bytes"] == 2097152)
    a.check("owned_observed_bounds", receipt["elapsed_seconds"] <= wall and receipt["owned_peak_job_commit_bytes"] <= 4294967296 and receipt["observed_output_bytes_after_drain"] <= 268435456)
    a.check("consumed_freeze_scope", freeze["mode"] == mode and freeze["timeout_seconds"] == wall and freeze["COMMIT_bytes"] == 4294967296 and freeze["output_bytes"] == 268435456 and freeze["new_training"] is False)
    a.check("consumed_result_scope", Path(freeze["runtime_output"]).resolve() == (parent / "results").resolve())
    a.check("consumed_manifest_exact", resolve_pinned(freeze["manifest_pin"]) == manifestp.resolve())
    review = load(resolve_pinned(freeze["review_pin"]))
    a.check("independent_static_review", review["accepted"] is True and review["code_pins"] == freeze["code_pins"])
    names = set()
    for ref in freeze["code_pins"]:
        resolved = resolve_pinned(ref)
        names.add(resolved.name)
    a.check("consumed_complete_source_code_set", names == {"a31_run_shared_engine_v3.m", "a31_shared_engine_chart_v1.m", "a31_legacy_row35_v1.m", "a29cl_math.m"})
    if mode == "full":
        pilot = load(resolve_pinned(freeze["pilot_acceptance_pin"]))
        a.check("full_depends_on_accepted_pilot", pilot["accepted"] is True)
    return {"receipt": pin(rp), "consumed_freeze": pin(fp), "review": freeze["review_pin"],
            "observed": {k: receipt[k] for k in ["elapsed_seconds", "owned_peak_job_commit_bytes", "observed_output_bytes_after_drain", "job_empty"]}}


def main_audit(args, a):
    work, out = args.work.resolve(strict=True), args.out.resolve()
    work.relative_to(ARTICLE)
    prior = load(ORIGINAL_REPORT)
    a.check("historical_report_unchanged", pin(ORIGINAL_REPORT)["sha256"] == ORIGINAL_REPORT_SHA)
    a.check("historical_structural_unchanged", pin(STRUCTURAL)["sha256"] == STRUCTURAL_SHA)
    structural = load(STRUCTURAL)
    a.check("historical_structural_accepted", structural["accepted"] is True and structural["failed_checks"] == 0)
    export_receipt_pin = structural["detail"]["export_receipt_pin"]
    export_receipt = load(resolve_pinned(export_receipt_pin))
    a.check("prior_numeric_and_discrete_complete", prior["boolean_axes"]["complete_all_five_saved_scope"] and prior["boolean_axes"]["all_logical_numeric_discrete_missingness_consistency"])
    a.check("prior_OH_WH_exact_complete", all(prior["detail"]["C11_by_family"][k]["partition_pass"] == 2100 and prior["detail"]["C11_by_family"][k]["counts_pass"] == 2100 for k in ["OH8", "WH8"]))
    manifestp = work / "prepared/preparation_manifest_v1.json"
    pin(manifestp)
    manifest = load(manifestp)
    a.check("prepared_union_scope", manifest["NL4_logical_views"] == 38220 and manifest["NL4_populations"] == 2100)
    original_math = resolve_pinned(manifest["original_math_pin"])
    math_copy = resolve_pinned(manifest["source_math_copy_pin"])
    a.check("original_math_copy_exact", pin(original_math)["sha256"] == pin(math_copy)["sha256"])
    # Creation-time code pins in the preparation manifest can precede the
    # independently reviewed runtime readback fixes. The actual consumed
    # freeze below binds and verifies the exact executed source bytes.
    for name in ["a31_legacy_row35_v1.m", "a31_shared_engine_chart_v1.m", "a31_run_shared_engine_v3.m", "prepare_union_banks_v1.py"]:
        pin(work / name)
    owned = owned_runtime(a, work, args.mode, args.run_name, manifestp)
    common = get_common()
    completep = work / f"runtime/{args.run_name}/results/run_complete.json"
    pin(completep)
    complete = load(completep)
    a.check("new_run_complete", complete["mode"] == args.mode and complete["training"] is False and complete["physical_validation"] is False and complete["standalone_generated_code"] is False)
    folds_to_read = [4] if args.mode == "pilot" else list(range(1, 6))
    a.check("new_run_fold_scope", [int(r["fold"]) for r in complete["folds"]] == folds_to_read)
    all_populations, explicit_two, fold_summary = [], [], []
    totals, per_family = Counter(), Counter()
    old_trace_cache, origin_bank_cache, origin_input_cache = {}, {}, {}
    for fold in folds_to_read:
        e = ORIGINAL / f"01_Input/EXPORT_RUN_01/results/fold_{fold}"
        pp = work / f"prepared/fold_{fold}"
        run = work / f"runtime/{args.run_name}/results/fold_{fold}"
        oldfr = next(r for r in export_receipt["folds"] if int(r["fold"]) == fold)
        for ref in oldfr["files"]:
            sourcefile = resolve_pinned(ref)
            a.check("original_export_file_scope", sourcefile.parent.resolve() == e.resolve())
        fr = next(r for r in manifest["folds"] if int(r["fold"]) == fold)
        for r in fr["files"]:
            resolve_pinned(r)
        original_map = load(e / "all_logical_mapping.json")
        pin(e / "all_logical_mapping.json")
        source_refs = {}
        for row in original_map:
            for field in ["result_pin", "audit_pin"]:
                ref = row["source"][field]
                source_refs[(ref["path"], ref["sha256"])] = ref
        for ref in source_refs.values():
            resolve_pinned(ref)
        original_byid = {int(r["logical_index1"]): r for r in original_map}
        a.check("original_logical_unique", len(original_byid) == len(original_map))
        params, modelmap = np.asarray(load(pp / "params.json"), dtype=float), load(pp / "model_map.json")
        pin(pp / "params.json"); pin(pp / "model_map.json")
        inputp = pp / ("pilot_inputs.csv" if args.mode == "pilot" else "inputs.csv")
        mappingp = pp / ("pilot_logical_mapping.json" if args.mode == "pilot" else "logical_mapping.json")
        inputs, mapping = readcsv(inputp), load(mappingp)
        pin(mappingp)
        a.check("prepared_parameter_shape", params.ndim == 2 and params.shape[1] == 36 and len(params) == len(modelmap))
        a.check("prepared_input_shape", inputs.ndim == 2 and inputs.shape[1] == 7)
        a.check("prepared_finite_parameters", np.all(np.isfinite(params)) and np.all(params[:, 34:36] > 0))
        a.check("prepared_exact_masks", np.all(np.isfinite(inputs)) and np.all(np.isin(inputs[:, 3:7], [0, 1])) and np.all(np.sum(inputs[:, 3:7], axis=1) >= 2))
        mmap = {int(r["union_model_id"]): r for r in modelmap}
        a.check("prepared_model_ids", set(mmap) == set(range(1, len(params) + 1)))
        for mid, mm in mmap.items():
            a.check("prepared_params_binary_hash", hashlib.sha256(bits(params[mid - 1])).hexdigest() == mm["parameter_sha256"], [fold, mid])
            origin = mm["origin"]
            bp, up = resolve_pinned(origin["bank_pin"]), resolve_pinned(origin["inputs_pin"])
            if str(bp) not in origin_bank_cache:
                origin_bank_cache[str(bp)] = load(bp)
            if str(up) not in origin_input_cache:
                origin_input_cache[str(up)] = readcsv(up)
            bank, uo = origin_bank_cache[str(bp)], origin_input_cache[str(up)][int(origin["source_query_index1"]) - 1]
            omid = int(origin["source_model_id"])
            a.check("prepared_origin_model_kind", bank["meta"][omid - 1][:3] == [2, 4, 0] and uo[2] == omid)
            expected_params = bank["theta"][omid - 1][:32] + bank["mean"] + bank["sd"]
            a.array("prepared_params_source_bank", params[mid - 1], expected_params, exact=True, detail=[fold, mid])
        actual, sem = read_trace(a, run, len(inputs), common)
        totals["new_shared_unique_queries"] += len(inputs)
        saved = slx_semantic(a, work, run, sem, params, inputs, args.mode, fold)
        a.array("shared_raw_mask_selector", actual[:, 30:35], np.c_[inputs[:, 3:7], inputs[:, 2]], exact=True)
        a.check("shared_all_rows_valid", np.all(actual[:, 29] == 1) and np.all(np.isin(actual[:, 26], [1, 2, 3, 4])))
        a.check("same_fold_normalizer", np.all(params[:, 32:36] == params[0, 32:36]))
        nbank = {"theta": np.pad(params[:, :32], ((0, 0), (0, 20))),
                 "meta": np.tile([2., 4., 0., 0., 0.], (len(params), 1)),
                 "mean": params[0, 32:34], "sd": params[0, 34:36],
                 "refs": np.zeros((252, 3)), "books": np.zeros((8, 8))}
        for qi, u in enumerate(inputs, 1):
            a.check("shared_selector_bounds", u[2] == int(u[2]) and 1 <= int(u[2]) <= len(params), [fold, qi])
            with np.errstate(all="ignore"):
                independent = common.independent_valid_row(nbank, u)
            a.array("shared_independent_NumPy35", actual[qi - 1], independent, detail=[fold, qi])
            a.array("shared_independent_discrete", actual[qi - 1, [26, 28, 29]], independent[[26, 28, 29]], exact=True, detail=[fold, qi])
        groups = defaultdict(list)
        logical_ids = set()
        for row in mapping:
            oi, qi, src = int(row["logical_index1"]), int(row["query_index1"]), row["source"]
            a.check("prepared_logical_id_unique", oi not in logical_ids)
            logical_ids.add(oi)
            original = original_byid[oi]
            a.check("prepared_original_identity", row["signature_sha256"] == original["signature_sha256"] and src == original["source"] and src["family"] == "NL4")
            a.array("prepared_original_reference", row["expected_source_channels35"][:34], original["expected_source_channels35"][:34], exact=True)
            a.check("prepared_query_bounds", 1 <= qi <= len(inputs))
            umid = int(inputs[qi - 1, 2])
            origin = row["origin"]
            bp, up = resolve_pinned(origin["bank_pin"]), resolve_pinned(origin["inputs_pin"])
            if str(bp) not in origin_bank_cache: origin_bank_cache[str(bp)] = load(bp)
            if str(up) not in origin_input_cache: origin_input_cache[str(up)] = readcsv(up)
            bank = origin_bank_cache[str(bp)]
            old_u = origin_input_cache[str(up)][int(origin["source_query_index1"]) - 1]
            a.array("prepared_original_raw_mask", inputs[qi - 1, [0, 1, 3, 4, 5, 6]], old_u[[0, 1, 3, 4, 5, 6]], exact=True)
            a.check("prepared_original_eligibility", inputs[qi - 1, 3:7].tolist() == [int(c in src["eligible"]) for c in range(1, 5)])
            omid = int(origin["source_model_id"])
            a.array("prepared_logical_parameter_identity", params[umid - 1], bank["theta"][omid - 1][:32] + bank["mean"] + bank["sd"], exact=True)
            expected = list(row["expected_source_channels35"])
            a.check("prepared_reference_selector", expected[34] == umid)
            got = actual[qi - 1]
            a.array("new_NL4_original_source35", got, expected, detail=[fold, oi])
            a.array("new_NL4_original_discrete", got[DISCRETE], np.asarray(expected, dtype=float)[DISCRETE], exact=True)
            key = tuple(src[k] for k in KEY_FIELDS)
            groups[key].append({"actual": got, "expected": expected, "source": src})
            totals["new_NL4_logical_views"] += 1
            per_family["NL4"] += 1
        expected_nl4_ids = {int(r["logical_index1"]) for r in original_map if r["source"]["family"] == "NL4"}
        if args.mode == "full":
            a.check("prepared_all_NL4_logical_scope", logical_ids == expected_nl4_ids)
        else:
            a.check("pilot_affected_scope", len(mapping) == 30 and all(k[0] == "NL4" and k[1] == 4 and k[2] == "ClassIL" and k[3] == "F25" and k[4] is True and k[5] in [101, 211] and k[6] == 2 for k in groups))
        if args.mode == "full":
            # Restore OH8/WH8 from ORIGINAL actual evidence, not source expected values.
            original_inputs = readcsv(e / "inputs.csv")
            newrefs = load(e / "new_query_reference.json"); pin(e / "new_query_reference.json")
            oldproofs = load(e / "old_reused_trace_evidence.json"); pin(e / "old_reused_trace_evidence.json")
            oldby = {r["signature_sha256"]: r for r in oldproofs}
            old_fold = next(r for r in prior["detail"]["folds"] if int(r["fold"]) == fold)
            original_trace = np.asarray(load(resolve_pinned(old_fold["actual_trace_pin"]))["values"], dtype=float)
            resolve_pinned(old_fold["actual_MAT_pin"]); resolve_pinned(old_fold["actual_CSV_pin"])
            for field in ["SLX_pin", "semantic_pin"]: resolve_pinned(old_fold["saved_model"][field])
            a.check("original_new_native_scope", original_trace.shape == (len(original_inputs), 35) and len(newrefs) == len(original_inputs))
            for row in original_map:
                src = row["source"]
                if src["family"] not in ["OH8", "WH8"]: continue
                if row["evidence_kind"] == "NEW_UNIQUE_SIMULINK_QUERY_PENDING":
                    qi = int(row["new_query_index1"])
                    a.check("old_native_new_signature", newrefs[qi - 1]["signature_sha256"] == row["signature_sha256"] and int(newrefs[qi - 1]["model_id"]) == int(original_inputs[qi - 1, 2]))
                    got = original_trace[qi - 1]
                    mid = int(original_inputs[qi - 1, 2])
                    totals["reused_original_OH_WH_new_native_views"] += 1
                else:
                    a.check("old_native_historical_kind", row["evidence_kind"] == "ACCEPTED_A30_TRACE_REUSED_NO_FORWARD")
                    proof = oldby[row["old_trace_signature"]]
                    origin = proof["origin"]
                    tp = resolve_pinned(origin["trace_pin"])
                    if str(tp) not in old_trace_cache: old_trace_cache[str(tp)] = np.asarray(load(tp)["values"], dtype=float)
                    got = old_trace_cache[str(tp)][int(origin["trace_row1"]) - 1]
                    a.array("historical_verbatim_actual_trace", proof["values35_verbatim"], got, exact=True)
                    mid = int(origin["source_model_id"])
                    for field in ["bank_pin", "model_map_pin", "inputs_pin", "reference_predictions_pin", "SLX_pin", "semantic_pin"]: resolve_pinned(origin[field])
                    a.check("historical_selector_identity", got[34] == mid)
                    totals["reused_original_OH_WH_historical_views"] += 1
                expected = list(row["expected_source_channels35"]); expected[34] = mid
                a.array("reused_OH_WH_original_source35", got, expected, detail=[fold, row["logical_index1"]])
                a.array("reused_OH_WH_original_discrete", got[DISCRETE], np.asarray(expected, dtype=float)[DISCRETE], exact=True)
                key = tuple(src[k] for k in KEY_FIELDS)
                groups[key].append({"actual": got, "expected": expected, "source": src})
                per_family[src["family"]] += 1
        pop_rows = []
        for key, group in groups.items():
            detail = key[0] == "NL4" and key[1] == 4 and key[2] == "ClassIL" and key[3] == "F25" and key[4] is True and key[5] in [101, 211] and key[6] == 2
            result = population_audit(a, key, group, detailed=detail)
            all_populations.append(result); pop_rows.append(result)
            if detail: explicit_two.append(result)
            totals["populations"] += 1
            totals["exact_gap_partition_populations"] += int(result["exact_gap_partition"])
            totals["exact_CWAFN_all_cuts_populations"] += int(result["exact_CWAFN_all_cuts"])
            totals["restored_logical_views"] += len(group)
        a.check("fold_population_scope", len(groups) == (2 if args.mode == "pilot" else 1260), fold)
        fold_summary.append({"fold": fold, "new_shared_unique_queries": len(inputs), "new_NL4_logical_views": len(mapping),
                             "populations": len(groups), "all_partition_pass": all(x["exact_gap_partition"] for x in pop_rows),
                             "all_CWAFN_pass": all(x["exact_CWAFN_all_cuts"] for x in pop_rows), "saved_model": saved})
        del actual, params, inputs, mapping, groups, original_map
        gc.collect()
    a.check("two_affected_populations_included", len(explicit_two) == 2)
    if args.mode == "full":
        a.check("full_cohort_scope", totals["new_shared_unique_queries"] == 32240 and totals["populations"] == 6300 and totals["restored_logical_views"] == 114660 and totals["new_NL4_logical_views"] == 38220 and per_family == {"NL4": 38220, "OH8": 38220, "WH8": 38220})
    else:
        a.check("pilot_scope", totals["populations"] == 2 and totals["restored_logical_views"] == 30)
    return {"mode": args.mode, "counts": dict(totals), "per_family_logical_views": dict(per_family),
            "folds": fold_summary, "populations": all_populations,
            "two_affected_populations": explicit_two,
            "new_run_complete": pin(completep), "preparation_manifest": pin(manifestp), "owned_runtime": owned,
            "original_export_receipt_pin": export_receipt_pin, "original_structural_audit_pin": pin(STRUCTURAL)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--work", type=Path, required=True)
    p.add_argument("--mode", choices=["pilot", "full"], default="full")
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--run-name", default=None, help="Runtime directory name; e.g. pilot_v3. Default is mode.")
    args = p.parse_args()
    args.run_name = args.run_name or args.mode
    assert args.run_name and all(c.isalnum() or c in "_-" for c in args.run_name), "Invalid run name"
    args.out = args.out.resolve()
    args.out.relative_to(HERE)
    assert not args.out.exists(), "No overwrite"
    args.out.mkdir(parents=True)
    audit, detail, fatal = Audit(), {}, None
    start = time.monotonic()
    try:
        detail = main_audit(args, audit)
    except Exception as exc:
        fatal = type(exc).__name__ + ": " + str(exc)
        if not audit.failures:
            audit.failures.append({"category": "fatal_boundary", "detail": fatal})
            audit.failure_categories["fatal_boundary"] += 1
    accepted = not audit.failure_categories and fatal is None
    populations = detail.pop("populations", [])
    explicit_two = detail.pop("two_affected_populations", [])
    popfile = args.out / "population_summaries.jsonl"
    popfile.write_text("".join(json.dumps(r, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n" for r in populations), encoding="utf-8")
    twofile = args.out / "two_affected_populations_explicit.json"
    twofile.write_text(json.dumps(explicit_two, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    report = {"schema": "A31_INDEPENDENT_ORIGINAL_REFERENCE_SHARED_ENGINE_SAVED_AUDIT_V4",
              "run_name": args.run_name,
              "mode": args.mode,
              "status": ("PASS_TWO_AFFECTED_POPULATIONS_ORIGINAL_REFERENCE" if args.mode == "pilot" else "PASS_FULL_6300_ORIGINAL_REFERENCE_INFERENCE_COHORT") if accepted else "HOLD_SAVED_PARITY_OR_COVERAGE",
              "accepted": accepted, "criteria_changed": False, "old_scientific_reference_replaced": False,
              "checks_count": sum(audit.counts.values()), "category_counts": dict(audit.counts),
              "failed_checks": sum(audit.failure_categories.values()), "failure_categories": dict(audit.failure_categories),
              "failure_examples": audit.failures, "fatal_error": fatal,
              "maximum_absolute_difference": audit.maximum_absolute_error,
              "finite_bit_different_cells_diagnostic_only": audit.finite_bit_different_cells,
              "numeric_cells": audit.numeric_cells,
              "numeric_tolerance": {"atol": ATOL, "rtol": RTOL},
              "detail": detail, "population_summaries_pin": pin(popfile),
              "two_affected_populations_pin": pin(twofile),
              "elapsed_seconds": time.monotonic() - start,
              "source_pins": list(PINS.values()), "verified_path_rebasings": REBASINGS,
              "auditor_pin": pin(Path(__file__)),
              "interpretation": "Frozen-model inference consistency against original saved scientific outputs. NL4 uses normal-mode desktop Simulink calling the original MATLAB decoder; OH8/WH8 reuse immutable compiled native evidence. This does not make the old compiled NL4 near-tie discrepancy disappear and is not independent generated-C validation or physical validation.",
              "new_MATLAB_or_simulation_calls_by_auditor": 0, "new_training": 0,
              "resource_execution_guard_scope": "Owned launcher normal exit, job-empty/membership status, frozen source/review pins, elapsed time, output and commit caps are verified from the execution receipt; numerical success alone does not imply process acceptance.",
              "created_at_utc": datetime.now(timezone.utc).isoformat()}
    rp = args.out / "independent_full_source_reference_audit_v4.json"
    rp.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "accepted": accepted, "checks": report["checks_count"],
                      "failed": report["failed_checks"], "fatal": fatal, "counts": detail.get("counts"), "report": str(rp)}, ensure_ascii=False))
    return 0 if accepted else 1


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    raise SystemExit(main())
