A31 exact confidence and coverage verification addendum

The selected desktop Simulink route reproduces the ORIGINAL frozen MATLAB
reference. All 6,300 stage populations match in exact confidence-gap groups
and every correct/wrong/abstain/failure/denominator count at every cut. The
primary saved-output reader passed 2,230,170 checks; a separately written
metric reader passed 1,378,007 checks and agreed on all population digests.

The new NL4 route executes 32,240 distinct frozen queries, restoring 38,220
logical views. All 35 NL4 source channels match exactly. The complete study
has 114,660 views: this NL4 component plus retained compiled OH8/WH8 traces.
The earlier compiled NL4 route's two near-tie differences remain historical
evidence. No learning, model selection, threshold adjustment or physical
sample experiment was added in this verification.

REPLAY THE NEW NL4 COMPONENT
Use compatible licensed MATLAB/Simulink (tested R2026a Update 5). Extract to
a short fresh writable path such as C:\A31R because Windows generated-code
paths are length-sensitive. Set MATLAB's current folder to ReplayRoot. Run:

 addpath(fullfile(pwd,'A_ARASTIRMASI','A31_Dogrulama_Kiyas_2026_10_25_v1', ...
   '01_Sayisal_Uyum','13_Legacy_Reference_Simulink_Reaudit_v1'));
 a31_run_shared_engine_v3('full');

This creates a NEW runtime/full/results directory beneath that replay tree.
The supplied ReplayRoot has no pre-existing runtime/full output. A second
run must use another fresh copy; accepted evidence is retained in Evidence.
The model explicitly calls a31_legacy_row35_v1.m and its unchanged original
a29cl_math.m through the desktop MATLAB engine. This is normal-mode desktop
simulation with an external helper dependency. It is not a standalone code
generation package. Inputs contain frozen weights/normalizers, the two raw
measurements and eligible-class controls; truth and expected outputs are
confined to independent audit mappings.

Evidence contains five saved SLX models, actual MAT/JSON/CSV and binary64
hex traces, cold model readbacks, execution receipt and both audit results.
The independent full readers bind earlier OH8/WH8 files from the existing
A31 computational package; that historical source package is not duplicated
here. Thus this addendum reproduces the new NL4 component by itself, while
the complete 6,300-population audit uses the accompanying original A31 base.
All published data and method citations and reuse notices remain applicable.
The established v30 DOI does not identify these new local A31 files.
