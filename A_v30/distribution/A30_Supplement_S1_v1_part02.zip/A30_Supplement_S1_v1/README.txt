A30 Supplement S1 — computational materials (package v1)

VERSION AND PURPOSE
A30 packages the accepted A29 five-fold empirical comparison and adds full-bank
Simulink inference verification and public reproduction utilities. Saved learned
weights, predictions, numerical findings and scientific limitations are preserved.
There is no new training or physical validation in this packaging revision.
Authors: Salih Çolakoğlu and Mustafa Onat, Marmara University.
Companion manuscript: Continual Recognition of Printed Polymer Contexts from
Published Average Mechanical Records. A computational deposit is not a claim of
journal publication of that manuscript; the manuscript is not included here.

Exact release: https://github.com/salihcolakoglu/printed-polymer-continual-recognition/releases/tag/v30.0
The version-specific Zenodo DOI is assigned when this release is archived. Use
the actual DOI displayed by the release/Zenodo record once available; no old
version DOI identifies these new results. The all-versions DOI is
https://doi.org/10.5281/zenodo.23289832. The prior v27.0 DOI
https://doi.org/10.5281/zenodo.23293866 identifies the original fixed-allocation
comparison and original two Simulink demonstrations only.

FILE MAP
02_Veriler: the fixed 104-row average-record cohort, modulus MPa and ShoreD.
02_Protokol: scientific contracts, group folds and original run-admission rules.
03_MATLAB_Kodlari: preserved learning kernels, plus independent inference chart
and cold-build/load driver in simulink_parity_v1. public_reproduction_v1 contains
the portable hash-checking MATLAB entrypoint, a30_replay_public_v1.m.
04_Simulink_Modelleri/full_bank_v1/fold_1..5: five actual saved SLX bank models,
frozen numeric banks, raw inputs, logical model maps, authoritative prediction
projections, actual full JSON/MAT traces and cold-runtime semantic readbacks.
07_Sonuclar: preserved simple-reference and matched-learning states, optimizer
moments, predictions and numerical rollups; 2,250 separate matched native curves.
09_Sekiller/manuscript_v2: six supplied PDF/PNG figures and their numeric sources.
table_data: Tables 1–7 and A1; literature Table1 is a design synthesis, not a
same-data performance league table. Citation identities retain23 references.
A30_SIMULINK_PUBLIC_MAP_v1.json: complete bank/query/code/source pin map.
SAVED_MODEL_INDEX_A30.json: current model inventory; the inherited A29 index is
preserved separately for traceability. PUBLIC_COPY_TRANSFORMS.json preserves the
exact historical A29 projection; PUBLIC_COPY_TRANSFORMS_A30.json adds the new
A30 semantic path projections and distinguishes
canonical scientific content from administrative metadata/path projections.
reproducibility_evidence: compact independently accepted implementation,
baseline-inference and actual plotting-reproduction evidence.

VERIFIED INFERENCE
Five saved SLX banks cover all 47,502 logical decision rows and 2,610 populations:
every stage, method, fold, applicable seed and alias. Their 35 channels include
raw-input normalization, logits/activations, eligible scores/distances, decisions,
gaps, ties, validity and control echoes. 1,420,341 independent checks passed;
maximum absolute discrepancy 9.769962616701378e-15. Fixed absolute and relative
tolerances were 2e-11 each; masks/labels/ties/missingness and every ordered native
gap block and C/W/A/F/N count matched exactly. 30 artificial controls also passed.
This is frozen inference consistency, not new algorithmic or physical evidence.

PUBLIC INSPECTION COMMANDS
Run from the extracted package root; write reports outside this sealed directory.
Python standard library:
  python tools/reevaluate_matched_saved_predictions.py
  python tools/public_reproduction_v1/reevaluate_baseline_saved_predictions.py --package-root . --report ../baseline_review.json
The second utility recomputes all 6,552 baseline decisions from raw inputs and
checks source links, 5 TRAIN normalizers, 175 linear jobs, 300 aliases and 15 combined
prototype/nearest-record snapshots. Its first complete run passed 148,612 checks.
Python with NumPy:
  python tools/a30_verify_simulink_saved.py --package-root . --out ../simulink_saved_review.json
This verifies archived traces and model-bank projection without running MATLAB.
See tools/README_SIMULINK_SAVED_AUDIT.txt for exact scope/options.

MATLAB+Simulink replay:
  addpath(fullfile(packageRoot,'03_MATLAB_Kodlari','public_reproduction_v1'));
  a30_replay_public_v1(packageRoot,outputRoot,2,true);  % prepare only, fresh path
Use a different fresh outputRoot and false for actual replay. The entry verifies
hashes, rebuilds the inference SLX from the frozen bank, cold-reopens it and runs
the fixed queries. It does not train. Output directories must be outside this
package. Caller path, working directory and file-generation settings are restored.
The archived five SLX files were themselves cold-reopened and verified in the
recorded source runs; rebuilt replay is separately identified as a new output.

FIGURE REPRODUCTION
  python tools/rebuild_A29_figures_from_saved_results.py
Requires reportlab and pypdf; pdftoppm on PATH additionally creates PNGs. The exact
public adapter was actually run: all six point CSVs were byte-equal, all captions
matched and all six new PNGs passed visual review. It creates a fresh
09_Sekiller/reproduced_from_S1; original accepted figures remain unchanged.
See tools/PLOT_REPRODUCTION_VERIFIED_v1.txt. PDF timestamps may differ.

NEW TRAINING
Training is separate from saved-state inspection. Original producers retain
their source/code/protocol gates. Private process freezes are not redistributed.
A new training environment requires reviewed paths, source admission, dependencies,
finite process/output/memory budgets and fresh outputs. This package does not
claim one-command portable retraining. See DEPENDENCIES.txt and the public guide.

SCOPE, LICENCES AND INTEGRITY
The 104 observations are previously inspected published averages in 26 groups,
not identified independent specimens. Group-heldout views and optimization seeds
are not new physical replicates or a new blind test. No production chronology,
physical response model or universal NN/Walsh superiority is added.
Original code: MIT. Authored figures, documentation, computational outcomes,
learned states and authored SLX/MAT artifacts:CC BY 4.0 within authors rights.
Embedded original code retains MIT; external data/code retain original notices.
No proprietary MathWorks software, private reviews, correspondence, unpublished
manuscript or complete third-party journal articles are redistributed.
Dataset: https://doi.org/10.17632/zd6td6svd6.2 ; source article:
https://doi.org/10.3390/mi17070859 . Retain method/source citations and notices.
Academic software citation is requested without adding a restriction to MIT.
MANIFEST_SHA256.json lists every other file, excluding itself; distribution
receipts identify the manifest, complete ZIP and any independently extractable
ZIP parts. Extract all listed parts into the same new empty directory.
