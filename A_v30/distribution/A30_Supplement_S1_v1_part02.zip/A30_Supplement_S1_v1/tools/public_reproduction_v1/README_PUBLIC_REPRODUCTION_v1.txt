A30 portable saved-output reevaluation: baseline adapter v1

Scope
This adapter independently reconstructs the 6,552 saved baseline predictions.
It does not train a model, resume MATLAB source-mode execution, modify a saved
state, tune a threshold, create an SLX model or establish physical validation.
The original A29 package and its 40,950-prediction matched evaluator are preserved.
This first adapter must pass prospective code review before its first source run.

Inputs and portability
Use a fresh local extraction of A29_Supplement_S1_v5 as PACKAGE_ROOT. The adjacent
PUBLIC_REPRODUCTION_INPUTS_v1.json lists four package-relative runtime paths with
exact byte sizes and SHA-256 pins. No workstation directory is encoded in the
adapter. The adapter can reside outside PACKAGE_ROOT. The sealed source package
is read only; output files must be fresh and outside it. Python's standard library
is sufficient. No NumPy, MATLAB, Simulink or network connection is required.

After review, from this adapter directory (replace the example directory names):
python reevaluate_baseline_saved_predictions.py --package-root PACKAGE_ROOT --report OUTPUT/baseline_review.json --expected-jsonl OUTPUT/baseline_expected.jsonl

Keep the command on one line. The internal JSON read cap is 16 MiB per input and
the optional expected export cap is 16 MiB. Use an external 60-second process
deadline for the first run. Exit 0 and status PASS mean that the declared saved
inference checks passed; a nonzero exit, HOLD or MISMATCH must be retained and
diagnosed. Never modify a saved model or relax a tolerance merely to obtain PASS.
Hash the input map and script with the run report when archiving a release.

What is independently derived
1. The raw CSV has 104 unique source-average rows and 26 complete four-context
   groups. It is linked to the published-source admission card and saved catalog.
2. Outer fold is (original group_order % 5)+1. The legacy partition column is
   audit metadata, not a new split selector. Row ID, group, label and printer or
   process metadata are not numerical classifier inputs.
3. The two ordered raw inputs are E_MPa and Hardness_ShoreD. For each fold the
   mean and sample SD (ddof=1) use only first-stage TRAIN labels 1 and 2. These
   five saved normalizers remain frozen at later stages; no heldout value is used.
4. The 175 unique saved linear fits are linked to 300 logical stream/stage aliases.
   Sequential jobs carry the exact prior optimizer state; joint jobs reset from
   the original initialization. This checks saved lineage and optimizer counters,
   not the training gradients or the historical execution of 600 updates.
5. Fifteen deterministic snapshots are linked to their admitted raw rows. Prototype
   sufficient statistics and nearest-reference stores have exactly the seen TRAIN
   membership. They are deterministic: seed is null, not five independent runs.
6. All 6,552 query keys are generated from folds, streams, stages, methods, seeds,
   prescribed TaskIL pairs or the ClassIL seen set, and heldout source identities.
   The adapter normalizes each raw input and applies the saved linear softmax,
   nearest-centroid or nearest-reference equation independently.
7. Scores, masked logits, class distances and top-two gap use the declared numeric
   tolerance: abs(actual-saved) <= 2e-11 * max(1, abs(saved)). Labels, exact ties,
   status, failure strings, masks, membership and aliases must match exactly.
   Original MATLAB records remain authoritative; binary bitwise identity across
   independent math libraries is not claimed.

Expected-output interface for later Simulink comparison
The optional JSONL has exactly one line per saved prediction identity. Each line
includes fold, stream, stage, method, seed, task (null for ClassIL), parentrow,
truth, eligible classes, state_id, raw_input, normalized_input, scores, logits,
distances, gap, prediction, tie, status and failure. Inactive class entries are
JSON null. Join future SLX output by prediction_id and additionally verify the
complete context key; never join merely by row order. This file is an independent
Python reference for a later separately reviewed SLX run, not evidence that such
a run has already occurred. A Simulink comparison adapter is a separate gate.

Matched-state path (existing tool, unchanged)
The package already contains tools/reevaluate_matched_saved_predictions.py and
SAVED_MODEL_INDEX.json for its 40,950 matched neural predictions. Run that original
tool from an extracted package only when its own review plan calls for it:
python PACKAGE_ROOT/tools/reevaluate_matched_saved_predictions.py
It consumes the saved normalized query vector Z. The new baseline adapter instead
audits raw-to-normalized inputs because baseline prediction rows do not store Z.
Do not add these two query counts as though they were independent physical samples.

Historical canonical versus public pins
The historical canonical baseline result SHA-256 is
65c6327c4567f079268da33361e1c77c3c157335917940c7d5b7dd26bacdff15.
The public metadata-projected result SHA-256 is
5be838634f7ad85f4b44ee5239df11e1b16d8ec9570fd9a3f0861bdb5179faa7.
PUBLIC_COPY_TRANSFORMS.json documents removal of private administrative fields;
its curation accepted the numerical sections as exact-equal. These are distinct
file identities. The adapter pins the actual public file. It does not overwrite
the historical A29_Matched_CL_Input_Links_v1.json or pretend that excluded private
handoff/admission cards are publicly available. Public inference is different from
historical source-mode execution. A fully portable training replay requires its
own reviewed path adapter and is not delivered by this inference-only tool.

Scientific and release limits
The observations are previously inspected published source averages. Grouped
out-of-fold inference and five numerical seeds do not establish specimen-level
independence, unseen operational arrival order, open-set recognition or a new
blind physical test. The adapter uses the recorded class vocabulary and prescribed
candidate information. A PASS does not certify method superiority, journal
acceptance, exhaustive source provenance, or training fidelity. A30 public release,
version DOI, CITATION and manuscript links remain separate pending deliverables.

License
Original adapter code: MIT, under the package's LICENSE_CODE.txt. Source-derived
data and saved scientific artifacts retain their own existing notices and CC BY
4.0 scope. This document creates no broader rights over third-party material.
