A30 saved Simulink audit and optional replay
===========================================

Python saved-output verification
-------------------------------
Requires Python 3.10+ and NumPy. MATLAB is not needed for this check.
From the extracted package folder, run:

  python "tools/a30_verify_simulink_saved.py" --out "../A30_saved_audit.json"

Choose a new report path outside the package. The checker also works from
another folder when invoked with its absolute script path. All input paths
are resolved relative to the package, without the authors' private folders.
Packaged files and earlier reports are preserved.

The default check verifies the complete package SHA256 manifest and public
input map, then all 47,502 saved decisions and 2,610 logical populations.
The bank covers the fixed states saved after every stage of all five folds,
five seeds and declared methods: 1,575 matched learned stage states,
175 linear states, and 30 prototype/nearest-record family states. Logical
aliases remain visible. The older 85-final-state/1,760-view demonstrations
are historical evidence with their own allocation and remain separate.

Checks include raw CSV inputs, frozen TRAIN scalers, source-to-bank state
projection, retained references, both codebooks, all applicable score/logit/
output/distance channels, missingness, masks, decisions and exact ties.
Numeric tolerance is 2e-11 + 2e-11 * abs(reference). Eligible masks, labels,
ties, validity, native equal-gap block order/membership and C/W/A/F/N counts
are checked exactly. Undefined conditional error remains null.

Optional MATLAB replay
----------------------
MATLAB R2026a and Simulink are required for replay. Add this directory to
the MATLAB path:

  addpath(fullfile(packageRoot,'03_MATLAB_Kodlari','public_reproduction_v1'))

Set packageRoot to the extracted package and choose a fresh outRoot outside
it. To rebuild and replay all five frozen banks:

  for fold = 1:5
      a30_replay_public_v1(packageRoot,outRoot,fold,false);
  end

This builds a new model from the frozen bank and chart code, saves the SLX,
cold reopens it and computes inference. Archived source SLX files stay
preserved. Existing fold output directories are refused; use a new outRoot
for another run. prepareOnly=true writes a configuration without simulation;
use a separate output root for that preparation to avoid an existing-fold
collision during an actual replay.

After all five replay folds complete:

  python "tools/a30_verify_simulink_saved.py" --replay-root "../A30_replay" --out "../A30_replay_audit.json"

For one bounded technical check, add --fold 2 and provide that replay root.
A subset report records its requested fold and does not claim all-five
completion. Each requested fold_N directory must contain its generated SLX,
actual_trace.json, actual_trace.mat and saved_model_semantic_readback.json.

Interpretation
--------------
This is the new grouped A29 inference bank. Model ticks index source queries;
they are not physical time or a polymer mechanics simulation. Learning was
performed in MATLAB earlier. These checks and replay do not train a model,
change saved weights or establish new algorithmic performance.

The Python checker reads saved SLX chart, wiring and fixed-step XML and
compares the actual cold-reopened MATLAB workspace readback to the frozen
bank. It hashes modelWorkspace.mxarray; it does not independently decode
that proprietary binary serialization or execute Simulink.

PASS establishes implementation parity in this published average-record
experiment. The 104 records are source averages, not independently identified
specimens. Physical validation, observed industrial chronology and new blind
testing are not added by this technical completion. Source attribution,
licence notices and the original scientific limitations remain applicable.
